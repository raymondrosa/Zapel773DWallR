# Zapel773DWall v1.0.1

## Actualización rev1 (2026-11-27)

- **Revisión del modelo**: auditoría automática con puntaje, hallazgos por tema, filtros, salto al elemento, prueba de estabilidad e informe. Local y sin internet.
- **Crear el modelo con IA**: descripción en texto → especificación validada → modelo editable. Servicio gratuito integrado o proveedor propio; opcional y solo con conexión. El cálculo siempre lo hace Zapel.
- **Robustez**: mensajes claros ante resultados no finitos o estructura inestable.
- Interfaz web, app de escritorio y ZIP portátil regenerados con la misma versión (`src/Zapel773DWall.html` = `desktop/app.html`).

## Destacado

- Interfaz web autocontenida.
- Versión de escritorio Windows con Electron.
- Solver nativo Rust con matriz dispersa y análisis modal espectral.
- ELF, viento ASCE 7-22 / PRBC 2018 y escenario Huracán María.
- Eventos sísmicos: Venezuela 2026, Turquía 2023, Noto 2024, Kaikoura 2016, Tohoku 2011, Maule 2010 y Wenchuan 2008.
- Peso propio de barras, losas y muros, activable o desactivable.
- Contornos de muros, losas y matres.
- Diagramas de barras N, V y M.
- Informes HTML con unidades coherentes.

## Instalación

1. Descargar `Zapel773DWall-Escritorio.zip` desde Releases.
2. Descomprimir.
3. Ejecutar `Zapel773DWall.exe`.

No requiere instalador. Windows puede mostrar SmartScreen por falta de firma digital.
