# Zapel773DWall

Aplicación de análisis estructural 3D para muros, losas, matres y pórticos, con una interfaz web autocontenida y una versión de escritorio Windows con núcleo de cálculo nativo en Rust.

## Contenido

- `src/Zapel773DWall.html`: aplicación web completa en un solo archivo.
- `desktop/`: envoltorio Electron y puente IPC hacia Rust.
- `rust-solver/`: solver disperso en Rust (`zapel_solver`).
- `docs/`: guía rápida y documentos de validación.
- `examples/`: modelo de ejemplo.
- `capturas/`: imágenes de referencia.
- `scripts/`: compilación y empaquetado local.
- `.github/workflows/`: compilación automática en GitHub Actions.

## Inicio rápido

### Versión web

Abre directamente:

```text
src/Zapel773DWall.html
```

No requiere instalación ni servidor. También se puede publicar como GitHub Pages copiando ese archivo como `index.html`.

### Versión de escritorio

1. Instala Node.js 20+, pnpm y Rust estable.
2. Desde `desktop/`:

```powershell
pnpm install
pnpm run package
```

3. El resultado queda en:

```text
desktop/dist/Zapel773DWall-win32-x64/
```

La carpeta es portátil. El ejecutable es `Zapel773DWall.exe` y el solver queda en `resources/zapel_solver.exe`.

En Windows también puedes ejecutar:

```powershell
scripts/build.ps1
```

El script copia la interfaz web a `desktop/app.html`, compila el solver, empaqueta Electron y genera el ZIP portátil.

## Solver Rust

El núcleo usa matriz dispersa CSR, factorización LDLᵀ directa con reordenamiento RCM y PCG como respaldo. Incluye:

- Análisis estático.
- Modal espectral con CQC.
- Fuerza lateral equivalente (ELF).
- Viento ASCE 7-22 y PRBC 2018, incluido el escenario Huracán María.
- Espectros de eventos sísmicos.
- Esfuerzos de muros y membranas de losa.
- Fuerzas de barra para diagramas N, V y M.
- Informes HTML con unidades del modelo.

Compilación manual:

```powershell
cd rust-solver
cargo build --release
```

CLI:

```powershell
zapel_solver.exe modelo.json --out resultado.json
zapel_solver.exe modelo.json --elf --report informe.html
zapel_solver.exe modelo.json --sismo --modes 3
zapel_solver.exe modelo.json --viento
zapel_solver.exe modelo.json --event-json "{\"T\":[...],\"Sa\":[...]}"
```

## Eventos sísmicos

La aplicación incluye espectros de evento para:

- Venezuela 2026.
- Turquía 2023.
- Noto 2024.
- Kaikoura 2016.
- Tohoku 2011.
- Maule 2010.
- Wenchuan 2008.

En la app web están en **Sismo… → Espectro de evento sísmico**. En el selector sísmico propio de Rust se eligen directamente y el método cambia a **Evento sísmico**.

## Peso propio

La opción **Peso propio** incluye el peso de:

- Barras: `γ · A` según material y sección.
- Losas: `peso específico · espesor`.
- Muros: `peso específico · espesor · longitud · altura`.

Se puede desactivar para análisis sin peso propio. Las cargas externas introducidas por el usuario se mantienen.

## Estructura del repositorio

```text
.
├── src/
├── desktop/
├── rust-solver/
├── docs/
├── examples/
├── capturas/
├── scripts/
├── .github/workflows/
└── release/
```

## GitHub Actions

El workflow `build.yml`:

- Compila el solver Rust en Windows.
- Instala dependencias de Electron.
- Empaqueta la aplicación.
- Publica la carpeta compilada como artefacto.

## Release en GitHub

No subas el ZIP portátil al historial del repositorio si supera el límite de archivos. Usa **GitHub Releases**:

```powershell
git tag v1.0.1
git push origin v1.0.1
gh release create v1.0.1 ..\Zapel773DWall-Escritorio.zip --title "Zapel773DWall v1.0.1" --notes-file RELEASE_NOTES.md
```

También puedes adjuntar el ZIP desde la interfaz web de GitHub en **Releases → Draft a new release**.

## Validación

Los documentos de validación están en `docs/`. El modelo de ejemplo está en `examples/modelo-completo.json`.

## Limitaciones

- El solver denso interno de JavaScript está pensado para modelos pequeños y medianos; para modelos grandes usa Rust.
- La versión web no ejecuta Rust: los botones nativos aparecen sólo en escritorio.
- El instalador no está firmado digitalmente; Windows puede mostrar SmartScreen.

## Licencia

El paquete actual declara `UNLICENSED`. Antes de publicar el repositorio, define la licencia que corresponda y actualiza este archivo.
