mod elf;
mod frame;
mod loads;
mod mat;
mod membrane;
mod modal;
mod model;
mod post;
mod report;
mod section;
mod solver;
mod sparse;
mod spectrum;
mod walls;
mod wind;

use serde_json::json;
use std::env;
use std::fs;

#[derive(Debug, Clone)]
struct Options {
    tol: f64,
    max_iter: usize,
    modal: bool,
    seismic: bool,
    modes: usize,
    sds: f64,
    sd1: f64,
    tl: f64,
    r: f64,
    ie: f64,
    f_a: f64,
    ecc: f64,
    cd: f64,
    riesgo: usize,
    wind: bool,
    wind_set: wind::Settings,
    elf: bool,
    elf_ct: f64,
    elf_x: f64,
    self_weight: bool,
    event: Option<spectrum::EventSpectrum>,
}

impl Default for Options {
    fn default() -> Self {
        Options {
            tol: 1e-9,
            max_iter: 50_000,
            modal: false,
            seismic: false,
            modes: 10,
            sds: 0.7333333333333333,
            sd1: 0.4266666666666667,
            tl: 8.0,
            r: 8.0,
            ie: 1.0,
            f_a: 0.25,
            ecc: 5.0,
            cd: 5.5,
            riesgo: 1,
            wind: false,
            wind_set: wind::Settings::default(),
            elf: false,
            elf_ct: 0.0466,
            elf_x: 0.9,
            self_weight: true,
            event: None,
        }
    }
}

fn main() {
    if let Err(e) = run() {
        let out = json!({"ok": false, "error": e});
        println!("{}", serde_json::to_string_pretty(&out).unwrap());
        std::process::exit(1);
    }
}

fn run() -> Result<(), String> {
    let args: Vec<String> = env::args().collect();
    let mut input: Option<String> = None;
    let mut output: Option<String> = None;
    let mut report_path: Option<String> = None;
    let mut o = Options::default();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--out" | "-o" => { i += 1; output = args.get(i).cloned(); }
            "--tol" => { i += 1; if let Some(v)=args.get(i){ o.tol = v.parse().map_err(|_| "Tolerancia invalida")?; } }
            "--max-iter" => { i += 1; if let Some(v)=args.get(i){ o.max_iter = v.parse().map_err(|_| "Maximo de iteraciones invalido")?; } }
            "--modal" => o.modal = true,
            "--sismo" | "--seismic" => o.seismic = true,
            "--modes" => { i += 1; if let Some(v)=args.get(i){ o.modes = v.parse::<usize>().map_err(|_| "Numero de modos invalido")?.clamp(1, 60); } }
            "--sds" => { i += 1; if let Some(v)=args.get(i){ o.sds = v.parse().map_err(|_| "SDS invalido")?; } }
            "--sd1" => { i += 1; if let Some(v)=args.get(i){ o.sd1 = v.parse().map_err(|_| "SD1 invalido")?; } }
            "--tl" => { i += 1; if let Some(v)=args.get(i){ o.tl = v.parse().map_err(|_| "TL invalido")?; } }
            "--r" => { i += 1; if let Some(v)=args.get(i){ o.r = v.parse().map_err(|_| "R invalido")?; } }
            "--ie" => { i += 1; if let Some(v)=args.get(i){ o.ie = v.parse().map_err(|_| "Ie invalido")?; } }
            "--fA" | "--fa" => { i += 1; if let Some(v)=args.get(i){ o.f_a = v.parse::<f64>().map_err(|_| "fA invalido")?.clamp(0.0, 1.0); } }
            "--ecc" => { i += 1; if let Some(v)=args.get(i){ o.ecc = v.parse::<f64>().map_err(|_| "ecc invalido")?.max(5.0); } }
            "--cd" | "--Cd" => { i += 1; if let Some(v)=args.get(i){ o.cd = v.parse().map_err(|_| "Cd invalido")?; } }
            "--riesgo" => { i += 1; if let Some(v)=args.get(i){ o.riesgo = v.parse::<usize>().map_err(|_| "Riesgo invalido")?.clamp(1, 4); } }
            "--report" => { i += 1; if let Some(v)=args.get(i){ report_path = Some(v.clone()); } }
            "--event-json" => {
                i += 1;
                if let Some(v) = args.get(i) {
                    let j: serde_json::Value = serde_json::from_str(v).map_err(|_| "Espectro de evento invalido")?;
                    let t: Vec<f64> = j.get("T").and_then(|x| x.as_array()).map(|a| a.iter().filter_map(|q| q.as_f64()).collect()).unwrap_or_default();
                    let sa: Vec<f64> = j.get("Sa").and_then(|x| x.as_array()).map(|a| a.iter().filter_map(|q| q.as_f64()).collect()).unwrap_or_default();
                    let scale = j.get("scale").and_then(|x| x.as_f64()).unwrap_or(1.0);
                    if t.len() >= 2 && t.len() == sa.len() { o.event = Some(spectrum::EventSpectrum::new(t, sa, scale)); }
                }
            }
            "--elf" => o.elf = true,
            "--ct" => { i += 1; if let Some(v)=args.get(i){ o.elf_ct = v.parse().map_err(|_| "Ct invalido")?; } }
            "--x" => { i += 1; if let Some(v)=args.get(i){ o.elf_x = v.parse().map_err(|_| "x invalido")?; } }
            "--viento" | "--wind" => o.wind = true,
            "--v" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.v = v.parse().map_err(|_| "V invalida")?; } }
            "--exp" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.exp = v.clone(); } }
            "--kzt" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.kzt = v.parse().map_err(|_| "Kzt invalido")?; } }
            "--kd" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.kd = v.parse().map_err(|_| "Kd invalido")?; } }
            "--ke" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.ke = v.parse().map_err(|_| "Ke invalido")?; } }
            "--g" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.g = v.parse().map_err(|_| "G invalido")?; } }
            "--cpw" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.cpw = v.parse().map_err(|_| "Cpw invalido")?; } }
            "--cpl" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.cpl = v.parse().map_err(|_| "Cpl invalido")?; } }
            "--gcpi" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.gcpi = v.parse().map_err(|_| "GCpi invalido")?; } }
            "--no-techo" => o.wind_set.techo = false,
            "--no-self-weight" => o.self_weight = false,
            "--norma" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.norma = v.clone(); } }
            "--evento" => { i += 1; if let Some(v)=args.get(i){ o.wind_set.evento = v.clone(); } }
            "--help" | "-h" => {
                println!("Uso: zapel_solver modelo.json [--out resultado.json] [--report informe.html]");
                println!("     [--modal] [--modes 10] [--sismo] [--sds 0.73] [--sd1 0.43] [--r 8] [--ie 1] [--fA 0.25] [--ecc 5] [--cd 5.5] [--riesgo 1]");
                println!("     [--elf] [--ct 0.0466] [--x 0.9] [--viento] [--v 165] [--exp C] ... [--no-self-weight]");
                return Ok(());
            }
            x if !x.starts_with('-') => input = Some(x.to_string()),
            x => return Err(format!("Opcion desconocida: {}", x)),
        }
        i += 1;
    }
    let input = input.ok_or("Falta el archivo JSON de entrada.")?;
    let text = fs::read_to_string(&input).map_err(|e| format!("No se pudo leer {}: {}", input, e))?;
    let model: model::Model = serde_json::from_str(&text).map_err(|e| format!("JSON invalido: {}", e))?;
    let result = solve_model(&model, &o)?;
    if let Some(path) = report_path {
        fs::write(&path, report::render(&result)).map_err(|e| format!("No se pudo escribir {}: {}", path, e))?;
        eprintln!("Informe escrito en {}", path);
    }
    let result_text = serde_json::to_string_pretty(&result).map_err(|e| e.to_string())?;
    if let Some(path) = output {
        fs::write(&path, &result_text).map_err(|e| format!("No se pudo escribir {}: {}", path, e))?;
        eprintln!("Resultado escrito en {}", path);
    } else {
        println!("{}", result_text);
    }
    Ok(())
}

fn with_self_weight(model: &model::Model, on: bool) -> model::Model {
    let mut m = model.clone();
    if on {
        for bar in &mut m.bars {
            if let Ok(sec) = section::from_bar(bar) {
                let gamma = match bar.mat.as_str() { "A" => 78.5, "O" => 24.0, _ => 24.0 };
                let q = gamma * sec.area;
                bar.wa += q;
                bar.wb += q;
            }
        }
    } else {
        for s in &mut m.slabs { s.gw = 0.0; }
        for w in &mut m.walls { w.gw = 0.0; }
    }
    m
}

struct Assembly {
    coords: Vec<[f64; 3]>,
    fixes: Vec<[bool; 6]>,
    loads: Vec<[f64; 6]>,
    elements: Vec<frame::Element>,
    element_loads: Vec<[f64; 12]>,
    elem_info: Vec<post::ElemLoad>,
    membranes: Vec<membrane::MembraneElement>,
    warnings: Vec<String>,
    added: loads::AddedLoads,
    total_weight: f64,
}

fn assemble(model: &model::Model) -> Result<Assembly, String> {
    let mut warnings: Vec<String> = Vec::new();
    let mut coords: Vec<[f64; 3]> = model.nodes.iter().map(|n| [n.x, n.y, n.z]).collect();
    let mut fixes: Vec<[bool; 6]> = model.nodes.iter().map(|n| {
        let mut f = [false; 6];
        for k in 0..6 { f[k] = n.r[k] != 0.0; }
        f
    }).collect();
    let mut loads: Vec<[f64; 6]> = model.nodes.iter().map(|n| n.f).collect();
    let added = loads::added_line_loads(model, &coords);
    warnings.extend(added.1.clone());
    let mut elements: Vec<frame::Element> = Vec::new();
    let mut element_loads: Vec<[f64; 12]> = Vec::new();
    let mut elem_info: Vec<post::ElemLoad> = Vec::new();
    for (bi, bar) in model.bars.iter().enumerate() {
        let mut effective = bar.clone();
        if bi < added.0.total.len() {
            effective.wa += added.0.total[bi];
            effective.wb += added.0.total[bi];
        }
        let sec = section::from_bar(bar)?;
        let ax = frame::axes(coords[bar.i], coords[bar.j], bar.ang)
            .ok_or_else(|| format!("Barra {}: longitud nula.", bi + 1))?;
        let m = bar.div.max(1);
        let a = coords[bar.i];
        let b = coords[bar.j];
        let mut prev = bar.i;
        for kk in 1..=m {
            let next = if kk == m { bar.j } else {
                coords.push([
                    a[0] + (b[0] - a[0]) * kk as f64 / m as f64,
                    a[1] + (b[1] - a[1]) * kk as f64 / m as f64,
                    a[2] + (b[2] - a[2]) * kk as f64 / m as f64,
                ]);
                fixes.push([false; 6]);
                loads.push([0.0; 6]);
                coords.len() - 1
            };
            let axf = frame::Axes { length: ax.length / m as f64, ex: ax.ex, ey: ax.ey, ez: ax.ez };
            let el = frame::Element {
                i: prev, j: next, length: axf.length, axes: axf, section: sec,
                e: bar.e * 1e6,
                release_start: bar.a1 != 0.0 && kk == 1,
                release_end: bar.a2 != 0.0 && kk == m,
                kz_spring: bar.kz * sec.width,
                ky_spring: bar.ky * sec.depth,
                bar_index: bi,
                wall_index: usize::MAX,
            };
            let eload = frame::equivalent_global(&effective, axf, (kk - 1) as f64 / m as f64, kk as f64 / m as f64, sec, bar.e * 1e6, el.release_start, el.release_end, el.kz_spring, el.ky_spring);
            let info = post::ElemLoad::new(&effective, &axf, (kk - 1) as f64 / m as f64, kk as f64 / m as f64);
            elements.push(el);
            element_loads.push(eload);
            elem_info.push(info);
            prev = next;
        }
    }
    walls::add_rigid_walls(&model, &mut coords, &mut fixes, &mut loads, &mut elements, &mut element_loads, &mut elem_info, &mut warnings);
    let mut membranes: Vec<membrane::MembraneElement> = Vec::new();
    membrane::add_membranes(&model, &mut coords, &mut fixes, &mut loads, &mut membranes, &mut warnings);
    // Solo se fijan los nudos originales del modelo que no participan en
    // ningun elemento. Los nudos añadidos (subdivisiones, muros, membranas)
    // deben quedar libres, como en la app.
    let mut used = vec![false; coords.len()];
    for el in &elements { used[el.i] = true; used[el.j] = true; }
    for (i, u) in used.iter().enumerate() {
        if i < model.nodes.len() && !u {
            for k in 0..6 { fixes[i][k] = true; }
        }
    }
    let total_weight: f64 = modal::nodal_weights(model, &coords, &vec![0.0; model.bars.len()]).iter().sum();
    Ok(Assembly { coords, fixes, loads, elements, element_loads, elem_info, membranes, warnings, added: added.0, total_weight })
}

fn build_csr(a: &Assembly) -> sparse::Csr {
    let n = a.coords.len() * 6;
    let mut triplets: Vec<(u32, u32, f64)> = Vec::new();
    for el in &a.elements {
        let kg = frame::global_stiffness(el);
        let d = frame::dofs(el);
        for i in 0..12 {
            for j in 0..12 {
                let v = kg[i][j];
                if v.abs() > 1e-14 { triplets.push((d[i] as u32, d[j] as u32, v)); }
            }
        }
    }
    for m in &a.membranes {
        for i in 0..9 {
            for j in 0..9 {
                let v = m.k[i][j];
                if v.abs() > 1e-14 { triplets.push((m.dof[i] as u32, m.dof[j] as u32, v)); }
            }
        }
    }
    // Estabilizacion diagonal: los GDL sin rigidez (rotaciones y traslacion
    // fuera del plano de los nudos de membrana) reciben una rigidez minima
    // relativa a la rigidez TIPICA del modelo. No se usa el maximo global
    // porque muros muy cortos o brazos rigidos pueden dar maximos enormes y
    // esa regularizacion alteraria el diafragma y el equilibrio.
    let mut diag = vec![0.0f64; n];
    for &(i, j, v) in &triplets {
        if i == j { diag[i as usize] += v; }
    }
    let mut mx = 0.0f64;
    for d in &diag { mx = mx.max(d.abs()); }
    let mut positive: Vec<f64> = diag.iter().copied().filter(|v| *v > 1e-12 * mx).collect();
    positive.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let typical = if positive.is_empty() { 1.0 } else { positive[positive.len() / 2] };
    let eps = (1e-9 * typical).max(1e-9);
    let threshold = (1e-9 * typical).max(1e-9 * mx);
    for d in 0..n {
        if diag[d].abs() < threshold {
            triplets.push((d as u32, d as u32, eps));
        }
    }
    sparse::Csr::from_triplets(n, triplets)
}

fn flat_original(u: &[f64], nodes: usize) -> Vec<f64> {
    (0..nodes).flat_map(|ni| u[6 * ni..6 * ni + 6].iter().copied()).collect()
}

struct BarPost {
    smp: Vec<Vec<serde_json::Value>>,
    wsm: Vec<Vec<[f64; 6]>>,
    dmax: f64,
}

fn post_bars(model: &model::Model, a: &Assembly, u: &[f64]) -> BarPost {
    let ctx = post::PostCtx { coords: &a.coords, elements: &a.elements, loads: &a.elem_info };
    let mut smp: Vec<Vec<serde_json::Value>> = vec![Vec::new(); model.bars.len()];
    let mut wsm: Vec<Vec<[f64; 6]>> = vec![Vec::new(); model.walls.len()];
    let mut dmax = 1e-12f64;
    for (ei, el) in a.elements.iter().enumerate() {
        let stations = ctx.stations(ei, u);
        for st in &stations {
            let d = (st.d[0] * st.d[0] + st.d[1] * st.d[1] + st.d[2] * st.d[2]).sqrt();
            if d > dmax { dmax = d; }
        }
        if el.bar_index < smp.len() {
            for st in stations {
                smp[el.bar_index].push(json!({
                    "P": st.p, "d": st.d, "N": st.n, "Vy": st.vy, "Vz": st.vz,
                    "T": st.t, "My": st.my, "Mz": st.mz, "Sy": st.sy, "Sz": st.sz
                }));
            }
        } else if el.wall_index < wsm.len() {
            for st in stations {
                wsm[el.wall_index].push([st.n, st.vy, st.vz, st.t, st.my, st.mz]);
            }
        }
    }
    BarPost { smp, wsm, dmax }
}

fn wall_stresses(model: &model::Model, a: &Assembly, pb: &BarPost) -> Vec<Vec<f64>> {
    let mut out: Vec<Vec<f64>> = vec![Vec::new(); model.walls.len()];
    for (wi, w) in model.walls.iter().enumerate() {
        if w.rig == 0.0 || w.n.len() < 4 { continue; }
        let p0 = a.coords[w.n[0]];
        let p1 = a.coords[w.n[1]];
        let p2 = a.coords[w.n[2]];
        let p3 = a.coords[w.n[3]];
        let l0 = ((p1[0]-p0[0]).powi(2)+(p1[1]-p0[1]).powi(2)+(p1[2]-p0[2]).powi(2)).sqrt();
        let l1 = ((p2[0]-p3[0]).powi(2)+(p2[1]-p3[1]).powi(2)+(p2[2]-p3[2]).powi(2)).sqrt();
        let l = ((l0 + l1) / 2.0).max(1e-6);
        let t = w.t.abs().max(1e-6);
        let recs = &pb.wsm[wi];
        if recs.is_empty() { continue; }
        let mut vals = Vec::with_capacity(recs.len() * 9);
        for r in recs {
            for u in 0..=8 {
                let uu = u as f64 / 8.0;
                vals.push(r[0] / (t * l) - 12.0 * r[4] * (uu - 0.5) / (t * l * l));
            }
        }
        out[wi] = vals;
    }
    out
}

fn slab_stresses(model: &model::Model, a: &Assembly, u: &[f64]) -> Vec<Vec<serde_json::Value>> {
    let mut slab_stress: Vec<Vec<serde_json::Value>> = vec![Vec::new(); model.slabs.len()];
    for m in &a.membranes {
        let mut ul = [0.0f64; 6];
        for node in 0..3 {
            let ni = m.dof[3 * node] / 6;
            let g = [u[6 * ni], u[6 * ni + 1], u[6 * ni + 2]];
            ul[2 * node] = g[0] * m.ex[0] + g[1] * m.ex[1] + g[2] * m.ex[2];
            ul[2 * node + 1] = g[0] * m.ey[0] + g[1] * m.ey[1] + g[2] * m.ey[2];
        }
        let mut st = [0.0f64; 3];
        for r in 0..3 {
            for c in 0..6 {
                st[r] += m.bd[r][c] * ul[c];
            }
        }
        let (sx, sy, txy) = (st[0], st[1], st[2]);
        let avg = (sx + sy) / 2.0;
        let rad = (((sx - sy) / 2.0).powi(2) + txy * txy).sqrt();
        if m.slab < slab_stress.len() {
            slab_stress[m.slab].push(json!({"p": m.centroid, "s1": avg + rad, "s2": avg - rad}));
        }
    }
    slab_stress
}

fn bar_forces(model: &model::Model, pb: &BarPost) -> Vec<serde_json::Value> {
    let mut out = Vec::new();
    for (bi, recs) in pb.smp.iter().enumerate() {
        if recs.is_empty() { continue; }
        let n = recs.len();
        let mut xs = Vec::with_capacity(n);
        let mut nn = Vec::with_capacity(n);
        let mut vy = Vec::with_capacity(n);
        let mut vz = Vec::with_capacity(n);
        let mut my = Vec::with_capacity(n);
        let mut mz = Vec::with_capacity(n);
        for (i, r) in recs.iter().enumerate() {
            xs.push(i as f64 / (n.max(2) - 1) as f64);
            let f = |k: &str| r.get(k).and_then(|v| v.as_f64()).unwrap_or(0.0);
            nn.push(f("N")); vy.push(f("Vy")); vz.push(f("Vz")); my.push(f("My")); mz.push(f("Mz"));
        }
        out.push(json!({"bar": bi, "x": xs, "N": nn, "Vy": vy, "Vz": vz, "My": my, "Mz": mz}));
    }
    let _ = model;
    out
}

/// Masa sismica por barra: peso propio de losa + fA*cargas de area + muros
/// sin rigidez. Las barras ya incluyen su peso propio en wa/wb.
fn mass_line(a: &Assembly, f_a: f64) -> Vec<f64> {
    (0..a.added.total.len())
        .map(|i| a.added.surface[i] + f_a * a.added.area[i] + a.added.wall[i])
        .collect()
}

fn solve_model(original: &model::Model, o: &Options) -> Result<serde_json::Value, String> {
    let use_self_weight = o.self_weight && original.self_weight != Some(false);
    let model = with_self_weight(original, use_self_weight);
    model.validate()?;
    let a = assemble(&model)?;
    let n = a.coords.len() * 6;
    let mut f = vec![0.0f64; n];
    for (ni, l) in a.loads.iter().enumerate() {
        for k in 0..6 { f[6 * ni + k] += l[k]; }
    }
    for (el, eload) in a.elements.iter().zip(a.element_loads.iter()) {
        let d = frame::dofs(el);
        for k in 0..12 { f[d[k]] += eload[k]; }
    }
    let k = build_csr(&a);
    let fixed: Vec<bool> = {
        let mut ff = vec![false; n];
        for i in 0..n { ff[i] = a.fixes[i / 6][i % 6]; }
        ff
    };
    let mass = mass_line(&a, o.f_a);
    let peso_sismico: f64 = modal::nodal_weights(&model, &a.coords, &mass).iter().sum();
    let input = json!({"nodes": model.nodes.len(), "bars": model.bars.len(), "units": model.units,
        "app": model.app, "version": model.version, "self_weight": use_self_weight, "fA": o.f_a});

    if o.wind {
        return solve_wind(&model, &a, &k, &fixed, &f, o, input);
    }
    if o.elf {
        return solve_elf(&model, &a, &k, &fixed, &f, &mass, o, input);
    }
    if o.modal && !o.seismic {
        let mr = modal::modal_analysis(&k, &fixed, &model, &a.coords, &mass, o.modes, o.tol, o.max_iter)?;
        let modes: Vec<serde_json::Value> = mr.modes.iter().map(|m| json!({
            "T": m.period, "f": m.frequency, "lambda": m.lambda
        })).collect();
        return Ok(json!({"ok": true, "solver": "sparse-modal", "input": input,
            "analysis": {"nodes_total": a.coords.len(), "dof": n, "elements": a.elements.len(),
                "nnz": k.nnz(), "total_weight": mr.total_weight, "dynamic_dofs": mr.dynamic_dofs,
                "modes": mr.modes.len()},
            "modal": {"modes": modes}, "warnings": a.warnings}));
    }
    if o.seismic {
        return solve_spectral(&model, &a, &k, &fixed, &f, &mass, o, input);
    }

    // ---------------- estatico ----------------
    let cg = solver::solve_static(&k, &f, &fixed, o.tol, o.max_iter)?;
    let mut ku = vec![0.0f64; n];
    k.matvec(&cg.u, &mut ku);
    let mut reactions = vec![0.0f64; n];
    for d in 0..n { reactions[d] = ku[d] - f[d]; }
    let mut rmax = 0.0f64;
    for d in 0..n {
        if !fixed[d] {
            let r = ku[d] - f[d];
            if r.abs() > rmax { rmax = r.abs(); }
        }
    }
    let pb = post_bars(&model, &a, &cg.u);
    let wall_stress = wall_stresses(&model, &a, &pb);
    let slab_stress = slab_stresses(&model, &a, &cg.u);
    let mats = mat::analyze_plateas(&model, &reactions, &mut Vec::new(), use_self_weight);
    let contour_disp: Vec<f64> = (0..model.nodes.len())
        .map(|i| (cg.u[6*i].powi(2)+cg.u[6*i+1].powi(2)+cg.u[6*i+2].powi(2)).sqrt())
        .collect();
    Ok(json!({"ok": true, "solver": "sparse-direct-ldl", "input": input,
        "analysis": {"nodes_total": a.coords.len(), "dof": n, "elements": a.elements.len(),
            "nnz": k.nnz(), "iterations": cg.iterations, "residual_relative": cg.residual_relative,
            "dmax": pb.dmax, "total_weight": peso_sismico,
            "residual_free_max": rmax, "fixed_count": fixed.iter().filter(|v| **v).count()},
        "warnings": a.warnings, "u": flat_original(&cg.u, model.nodes.len()), "u_all": cg.u,
        "reactions": reactions, "smp": pb.smp, "contours": {"disp": contour_disp},
        "wall_stress": wall_stress, "slab_stress": slab_stress, "mats": mats,
        "cargas": {
            "losas": a.added.surface.iter().sum::<f64>(),
            "areas": a.added.area.iter().sum::<f64>(),
            "muros": a.added.wall.iter().sum::<f64>(),
            "f_z": f.iter().skip(2).step_by(6).sum::<f64>(),
            "f_x": f.iter().step_by(6).sum::<f64>(),
        },
        "bar_forces": bar_forces(&model, &pb),
        "wall_count": wall_stress.iter().filter(|a| !a.is_empty()).count()}))
}

fn solve_wind(
    model: &model::Model,
    a: &Assembly,
    k: &sparse::Csr,
    fixed: &[bool],
    f: &[f64],
    o: &Options,
    input: serde_json::Value,
) -> Result<serde_json::Value, String> {
    let prep = wind::prepare(model, &o.wind_set)?;
    let mut cases = Vec::new();
    let mut env = 0.0f64;
    let mut env_drift = vec![0.0f64; prep.levels.len()];
    let mut env_dir = vec!['X'; prep.levels.len()];
    for (dir, sign) in [('X',1.0),('X',-1.0),('Y',1.0),('Y',-1.0)] {
        let mut fc = f.to_vec();
        let meta = wind::apply_case(model, &prep, dir, sign, &mut fc);
        let cg = solver::solve_static(k, &fc, fixed, o.tol, o.max_iter)?;
        let pb = post_bars(model, a, &cg.u);
        let dmax = pb.dmax;
        let ws = wall_stresses(model, a, &pb);
        let ss = slab_stresses(model, a, &cg.u);
        let axis = if dir == 'X' { 0 } else { 1 };
        // Derivas de entrepiso: diferencia de desplazamiento medio en la
        // direccion del caso (la app incluye el primer entrepiso desde la base).
        let mut drifts = Vec::new();
        for i in 0..prep.levels.len() {
            let av = |lv: &wind::Level| -> f64 {
                lv.nodes.iter().map(|&x| cg.u[6*x + axis]).sum::<f64>() / lv.nodes.len().max(1) as f64
            };
            let a_disp = av(&prep.levels[i]);
            let b_disp = if i > 0 { av(&prep.levels[i - 1]) } else { 0.0 };
            let d = (a_disp - b_disp).abs();
            if i < env_drift.len() && d > env_drift[i] { env_drift[i] = d; env_dir[i] = dir; }
            drifts.push(d);
        }
        env = env.max(dmax);
        cases.push(json!({
            "dir": dir.to_string(), "sign": sign, "base_shear": meta.base_shear.abs(), "dmax": dmax,
            "drifts": drifts,
            "u": flat_original(&cg.u, model.nodes.len()),
            "wall_stress": ws, "slab_stress": ss, "bar_forces": bar_forces(model, &pb)
        }));
    }
    let summary = wind::summary(&prep);
    let tab: Vec<serde_json::Value> = (0..prep.levels.len()).map(|i| {
        let z = prep.levels[i].z;
        let prev = if i > 0 { prep.levels[i - 1].z } else { prep.base };
        let dz = (z - prev).max(1e-9);
        let dr = env_drift[i];
        json!({"z": z, "dz": dz, "dr": dr, "da": dz / 400.0,
            "dir": env_dir[i].to_string(), "ok": dr <= dz / 400.0 + 1e-12})
    }).collect();
    Ok(json!({"ok": true, "solver": "sparse-wind-asce", "input": input,
        "analysis": {"nodes_total": a.coords.len(), "dof": k.n, "elements": a.elements.len(), "nnz": k.nnz(), "dmax": env},
        "wind": summary, "cases": cases, "envelope_drifts": env_drift, "tab": tab,
        "drift_levels": prep.levels.iter().map(|l| l.z).collect::<Vec<_>>(),
        "warnings": a.warnings}))
}

fn solve_elf(
    model: &model::Model,
    a: &Assembly,
    k: &sparse::Csr,
    fixed: &[bool],
    f: &[f64],
    mass: &[f64],
    o: &Options,
    input: serde_json::Value,
) -> Result<serde_json::Value, String> {
    let ctx = post::PostCtx { coords: &a.coords, elements: &a.elements, loads: &a.elem_info };
    let es = elf::Settings { sds: o.sds, sd1: o.sd1, tl: o.tl, r: o.r, ie: o.ie, ct: o.elf_ct, x: o.elf_x, ecc: o.ecc, cd: o.cd, riesgo: o.riesgo };
    let er = elf::analyze(model, &a.coords, k, fixed, f, mass, &es, &ctx)?;
    Ok(json!({"ok": true, "solver": "sparse-elf-asce", "input": input,
        "analysis": {"nodes_total": a.coords.len(), "dof": k.n, "elements": a.elements.len(), "nnz": k.nnz(), "dmax": er["dmax"]},
        "elf": er, "warnings": a.warnings}))
}

fn solve_spectral(
    model: &model::Model,
    a: &Assembly,
    k: &sparse::Csr,
    fixed: &[bool],
    f: &[f64],
    mass: &[f64],
    o: &Options,
    input: serde_json::Value,
) -> Result<serde_json::Value, String> {
    let mr = modal::modal_analysis(k, fixed, model, &a.coords, mass, o.modes, o.tol, o.max_iter)?;
    let sp = if let Some(e) = &o.event {
        spectrum::Spectrum::event(e.t.clone(), e.sa.clone(), e.scale, o.tl)
    } else {
        spectrum::Spectrum::new(o.sds, o.sd1, o.tl, o.r, o.ie)
    };
    let ctx = post::PostCtx { coords: &a.coords, elements: &a.elements, loads: &a.elem_info };
    let elf_v = if o.event.is_none() {
        let es = elf::Settings { sds: o.sds, sd1: o.sd1, tl: o.tl, r: o.r, ie: o.ie, ct: o.elf_ct, x: o.elf_x, ecc: o.ecc, cd: o.cd, riesgo: o.riesgo };
        match elf::analyze(model, &a.coords, k, fixed, f, mass, &es, &ctx) {
            Ok(v) => v.get("V").and_then(|q| q.as_f64()).unwrap_or(0.0),
            Err(_) => 0.0,
        }
    } else { 0.0 };
    let sr = spectrum::spectral_analysis(k, fixed, model, &a.coords, &mr.modes, mass, &sp, f, o.ecc, elf_v, o.cd, o.riesgo, &ctx)?;
    let orig = |v: &[f64]| flat_original(v, model.nodes.len());
    let dir_json = |d: &spectrum::DirectionResult| {
        let pb = post_bars(model, a, &d.u);
        let ws = wall_stresses(model, a, &pb);
        let ss = slab_stresses(model, a, &d.u);
        json!({
            "base_shear": d.base_shear, "dmax": d.dmax, "kesc": d.kesc, "meff": d.meff,
            "u": orig(&d.u), "reactions": orig(&d.reactions),
            "wall_stress": ws, "slab_stress": ss, "bar_forces": bar_forces(model, &pb),
            "drifts": d.drifts
        })
    };
    let dmax = sr.x.dmax.max(sr.y.dmax);
    let mut warnings = a.warnings.clone();
    let kesc_max = sr.x.kesc.max(sr.y.kesc);
    if kesc_max > 2.0 {
        warnings.push(format!(
            "Participacion modal insuficiente: el cortante modal se escala por {:.2} para alcanzar el 85% del ELF (ASCE 12.9.4.2). Aumente el numero de modos o use fuerza lateral equivalente (ELF) para el diseno.",
            kesc_max
        ));
    }
    let meff_min = sr.x.meff.min(sr.y.meff);
    if meff_min < 0.75 {
        warnings.push(format!(
            "Masa modal efectiva baja ({:.0}% en la direccion mas desfavorable). El analisis modal con {} modos no captura toda la masa; revise el numero de modos.",
            meff_min * 100.0, mr.modes.len()
        ));
    }
    Ok(json!({"ok": true, "solver": "sparse-modal-spectrum-cqc", "input": input,
        "spectrum": {"sds": sp.sds, "sd1": sp.sd1, "t0": sp.t0(), "ts": sp.ts(), "tl": sp.tl,
            "r": sp.r, "ie": sp.ie, "event": o.event.is_some(), "cd": o.cd, "riesgo": o.riesgo,
            "ecc": o.ecc, "fA": o.f_a},
        "analysis": {"nodes_total": a.coords.len(), "dof": k.n, "elements": a.elements.len(),
            "nnz": k.nnz(), "dynamic_dofs": mr.dynamic_dofs, "total_weight": sr.total_weight,
            "modes": mr.modes.len(), "dmax": dmax, "kesc": kesc_max,
            "meff": meff_min,
            "dmax_unscaled": if kesc_max > 0.0 { dmax / kesc_max } else { dmax },
            "modal_periods": mr.modes.iter().map(|m| m.period).collect::<Vec<f64>>()},
        "directions": {"X": dir_json(&sr.x), "Y": dir_json(&sr.y)}, "warnings": warnings}))
}
