use serde_json::Value;

fn f(v: &Value, k: &str) -> String {
    match v.get(k) {
        Some(Value::Number(n)) => {
            let x = n.as_f64().unwrap_or(0.0);
            if x.abs() >= 1e5 || (x != 0.0 && x.abs() < 1e-3) {
                format!("{:.4e}", x)
            } else if (x - x.round()).abs() < 1e-9 {
                format!("{:.0}", x)
            } else {
                format!("{:.4}", x)
            }
        }
        Some(Value::String(s)) => s.clone(),
        Some(Value::Bool(b)) => b.to_string(),
        _ => "-".into(),
    }
}

fn num(x: f64, scale: f64) -> String {
    let x = x * scale;
    if x.abs() >= 1e5 || (x != 0.0 && x.abs() < 1e-3) {
        format!("{:.4e}", x)
    } else if (x - x.round()).abs() < 1e-9 {
        format!("{:.0}", x)
    } else {
        format!("{:.4}", x)
    }
}

fn scaled(v: &Value, k: &str, scale: f64) -> String {
    match v.get(k) {
        Some(Value::Number(n)) => {
            let x = n.as_f64().unwrap_or(0.0) * scale;
            if x.abs() >= 1e5 || (x != 0.0 && x.abs() < 1e-3) {
                format!("{:.4e}", x)
            } else {
                format!("{:.4}", x)
            }
        }
        _ => "-".into(),
    }
}

#[derive(Clone, Copy)]
struct Units {
    len: f64,
    force: f64,
    moment: f64,
    press: f64,
    disp: f64,
    ll: &'static str,
    fl: &'static str,
    ml: &'static str,
    pl: &'static str,
    dl: &'static str,
}

fn units_for(result: &Value) -> Units {
    let im = result
        .get("input")
        .and_then(|i| i.get("units"))
        .and_then(|u| u.as_str())
        .map(|u| u == "IM")
        .unwrap_or(false);
    if im {
        Units {
            len: 3.28084,
            force: 0.224809,
            moment: 0.737562,
            press: 0.0208854,
            disp: 39.3701,
            ll: "ft",
            fl: "kip",
            ml: "kip·ft",
            pl: "ksf",
            dl: "in",
        }
    } else {
        Units {
            len: 1.0,
            force: 1.0,
            moment: 1.0,
            press: 1.0,
            disp: 1000.0,
            ll: "m",
            fl: "kN",
            ml: "kN·m",
            pl: "kN/m²",
            dl: "mm",
        }
    }
}

fn table(headers: &[&str], rows: &[Vec<String>]) -> String {
    let mut h = String::from("<table><thead><tr>");
    for q in headers {
        h.push_str(&format!("<th>{}</th>", q));
    }
    h.push_str("</tr></thead><tbody>");
    for r in rows {
        h.push_str("<tr>");
        for c in r {
            h.push_str(&format!("<td>{}</td>", c));
        }
        h.push_str("</tr>");
    }
    h.push_str("</tbody></table>");
    h
}

fn ok_cell(v: Option<&Value>) -> String {
    match v.and_then(|q| q.as_bool()) {
        Some(true) => "<span style=\"color:#166534\">cumple</span>".into(),
        Some(false) => "<span style=\"color:#b91c1c\">revisar</span>".into(),
        None => "-".into(),
    }
}

pub fn render(result: &Value) -> String {
    let u = units_for(result);
    let mut s = String::from(
        "<!doctype html><html lang=\"es\"><head><meta charset=\"utf-8\"><title>Zapel773DWall · Informe Rust</title><style>\
         body{font:13px system-ui,Segoe UI,sans-serif;color:#17202a;margin:24px;max-width:1100px}h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:22px 0 6px;border-bottom:1px solid #ccd;padding-bottom:3px}\
         table{border-collapse:collapse;width:100%;margin:6px 0 12px}td,th{border-bottom:1px solid #dde;padding:3px 5px;text-align:right}th{background:#f4f6f8;text-align:left}td:first-child,th:first-child{text-align:left}\
         .m{color:#667;font-size:11px}.box{background:#f7f9fb;border:1px solid #dde;padding:8px;border-radius:6px}</style></head><body>\
         <h1>Zapel773DWall · Informe nativo Rust</h1><div class=\"m\">Generado por zapel_solver (matriz dispersa LDLᵀ + RCM)</div>",
    );
    if let Some(i) = result.get("input") {
        s.push_str("<div class=\"box\"><b>Modelo</b><br>");
        s.push_str(&format!(
            "Nudos: {} · Barras: {} · Unidades del modelo: {} · App: {}<br>",
            f(i, "nodes"),
            f(i, "bars"),
            f(i, "units"),
            f(i, "app")
        ));
        s.push_str(&format!(
            "Peso propio incluido: <b>{}</b> · Fracción de carga de área para masa sísmica fA: <b>{}</b><br>",
            if i.get("self_weight").and_then(|v| v.as_bool()).unwrap_or(true) { "sí" } else { "no" },
            f(i, "fA")
        ));
        s.push_str(&format!(
            "Resultados presentados en <b>{}</b> para longitud, <b>{}</b> para fuerza, <b>{}</b> para momento, <b>{}</b> para presión y <b>{}</b> para desplazamiento.<br>",
            u.ll, u.fl, u.ml, u.pl, u.dl
        ));
        s.push_str("</div>");
    }
    if let Some(a) = result.get("analysis") {
        s.push_str("<h2>Análisis</h2>");
        let dmax = a.get("dmax").and_then(|v| v.as_f64());
        let weight = a.get("total_weight").and_then(|v| v.as_f64());
        s.push_str(&table(
            &["Concepto", "Valor"],
            &[
                vec!["GDL".into(), f(a, "dof")],
                vec!["Elementos".into(), f(a, "elements")],
                vec!["No-cero".into(), f(a, "nnz")],
                vec![format!("dmax ({})", u.dl), dmax.map(|x| num(x, u.disp)).unwrap_or_else(|| "-".into())],
                vec![format!("Peso sísmico ({})", u.fl), weight.map(|x| num(x, u.force)).unwrap_or_else(|| "-".into())],
            ],
        ));
    }
    if let Some(d) = result.get("directions") {
        s.push_str("<h2>Sismo modal espectral</h2>");
        let mut rows = Vec::new();
        for key in ["X", "Y"] {
            if let Some(q) = d.get(key) {
                rows.push(vec![
                    key.into(),
                    format!("{} {}", scaled(q, "base_shear", u.force), u.fl),
                    format!("{} {}", scaled(q, "dmax", u.disp), u.dl),
                    format!("{}", f(q, "kesc")),
                ]);
            }
        }
        s.push_str(&table(&["Dirección", "Cortante basal", "dmax", "factor 85% ELF"], &rows));
        if let Some(a) = result.get("analysis") {
            if let Some(k) = a.get("kesc").and_then(|v| v.as_f64()) {
                if k > 2.0 {
                    s.push_str(&format!(
                        "<div class=\"box\" style=\"border-color:#f59e0b;background:#fffbeb\"><b>Atención: participación modal insuficiente.</b><br>\
                         El cortante modal se escala por <b>{:.2}</b> para cumplir ASCE 7-16 12.9.4.2 y la masa modal efectiva es <b>{}</b>. \
                         Los desplazamientos y derivas escalados no son representativos; use el método de <b>fuerza lateral equivalente (ELF)</b> \
                         o aumente el número de modos para el diseño de este modelo.<br>\
                         dmax sin escalar (referencia): {} {}</div>",
                        k,
                        a.get("meff").map(|m| format!("{:.0}%", m.as_f64().unwrap_or(0.0) * 100.0)).unwrap_or_else(|| "-".into()),
                        scaled(a, "dmax_unscaled", u.disp), u.dl
                    ));
                }
            }
        }
        if let Some(sp) = result.get("spectrum") {
            s.push_str(&format!(
                "<div class=\"m\">SDS = {} · SD1 = {} · T0 = {} s · Ts = {} s · R = {} · Ie = {} · Cd = {} · Evento = {} · fA = {} · excentricidad = {}%</div>",
                f(sp, "sds"), f(sp, "sd1"), f(sp, "t0"), f(sp, "ts"),
                f(sp, "r"), f(sp, "ie"), f(sp, "cd"), f(sp, "event"),
                f(sp, "fA"), f(sp, "ecc")
            ));
        }
        for key in ["X", "Y"] {
            if let Some(q) = d.get(key) {
                if let Some(t) = q.get("drifts").and_then(|v| v.as_array()) {
                    if !t.is_empty() {
                        s.push_str(&format!("<b>Derivas sísmicas · dirección {}</b>", key));
                        let rows: Vec<Vec<String>> = t.iter().map(|r| vec![
                            format!("{} {}", scaled(r, "z", u.len), u.ll),
                            format!("{}", f(r, "dr")),
                            format!("{}", f(r, "dd")),
                            format!("{}", f(r, "da")),
                            format!("{}", f(r, "theta")),
                            ok_cell(r.get("ok")),
                            ok_cell(r.get("ok2")),
                        ]).collect();
                        s.push_str(&table(&["Nivel (cota)", "dr", "dd (Cd/Ie)", "da", "θ", "deriva", "θ ≤ 0.1"], &rows));
                    }
                }
            }
        }
    }
    if let Some(e) = result.get("elf") {
        s.push_str("<h2>Fuerza lateral equivalente</h2>");
        s.push_str(&table(
            &["Concepto", "Valor"],
            &[
                vec!["T (s)".into(), f(e, "T")],
                vec!["Ta (s)".into(), f(e, "Ta")],
                vec!["Cu".into(), f(e, "Cu")],
                vec!["T1 (Rayleigh, s)".into(), f(e, "T1")],
                vec!["Tcalc (s)".into(), f(e, "Tcalc")],
                vec!["k".into(), f(e, "k")],
                vec!["Cs".into(), f(e, "Cs")],
                vec![format!("V ({})", u.fl), scaled(e, "V", u.force)],
                vec![format!("W ({})", u.fl), scaled(e, "W", u.force)],
                vec![format!("hn ({})", u.ll), scaled(e, "hn", u.len)],
                vec!["Cd".into(), f(e, "Cd")],
                vec!["Categoría de riesgo".into(), f(e, "riesgo")],
            ],
        ));
        if let Some(t) = e.get("table").and_then(|q| q.as_array()) {
            let rows: Vec<Vec<String>> = t.iter().map(|q| vec![
                format!("{} {}", scaled(q, "z", u.len), u.ll),
                format!("{} {}", scaled(q, "V", u.force), u.fl),
                f(q, "dr"),
                f(q, "dd"),
                f(q, "da"),
                f(q, "theta"),
                ok_cell(q.get("ok")),
                ok_cell(q.get("ok2")),
            ]).collect();
            s.push_str("<b>Derivas de entrepiso</b>");
            s.push_str(&table(&["Nivel (cota)", "V nivel", "dr", "dd (Cd/Ie)", "da", "θ", "deriva", "θ ≤ 0.1"], &rows));
        }
    }
    if let Some(w) = result.get("wind") {
        s.push_str("<h2>Viento</h2>");
        s.push_str(&format!(
            "<div class=\"m\">{} · {} · V = {} mph · exposición {} · qh = {} psf · Vbase = {} {} · Mbase = {} {}</div>",
            f(w, "norma"), f(w, "evento"), f(w, "V"), f(w, "exposure"), f(w, "qh"),
            scaled(w, "Vbase", u.force), u.fl, scaled(w, "Mbase", u.moment), u.ml
        ));
        if let Some(ls) = w.get("levels").and_then(|q| q.as_array()) {
            let rows: Vec<Vec<String>> = ls.iter().map(|q| vec![
                format!("{} {}", scaled(q, "z", u.len), u.ll),
                f(q, "kz"),
                format!("{} psf", f(q, "pN")),
                format!("{} {}", scaled(q, "FX", u.force), u.fl),
                format!("{} {}", scaled(q, "FY", u.force), u.fl),
            ]).collect();
            s.push_str(&table(&["Nivel z", "Kz", "pN", "FX", "FY"], &rows));
        }
        if let Some(dv) = result.get("envelope_drifts").and_then(|q| q.as_array()) {
            if !dv.is_empty() {
                let zs = result.get("drift_levels").and_then(|q| q.as_array()).cloned().unwrap_or_default();
                let rows: Vec<Vec<String>> = dv.iter().enumerate().map(|(i, q)| vec![
                    zs.get(i).map(|z| format!("{} {}", num(z.as_f64().unwrap_or(0.0), u.len), u.ll)).unwrap_or_else(|| "-".into()),
                    format!("{}", q.as_f64().unwrap_or(0.0)),
                ]).collect();
                s.push_str("<b>Derivas de viento (envolvente, H/400)</b>");
                s.push_str(&table(&["Nivel (cota)", "Δ entrepiso"], &rows));
            }
        }
    }
    if let Some(c) = result.get("cases").and_then(|q| q.as_array()) {
        s.push_str("<h2>Casos de viento</h2>");
        let rows: Vec<Vec<String>> = c.iter().map(|q| vec![
            format!("{}{}", f(q, "dir"),
                if q.get("sign").and_then(|x| x.as_f64()).unwrap_or(0.0) > 0.0 { "+" } else { "-" }),
            format!("{} {}", scaled(q, "base_shear", u.force), u.fl),
            format!("{} {}", scaled(q, "dmax", u.disp), u.dl),
        ]).collect();
        s.push_str(&table(&["Caso", "Cortante", "dmax"], &rows));
    }
    if let Some(m) = result.get("mats").and_then(|q| q.as_array()) {
        if !m.is_empty() {
            s.push_str("<h2>Matres</h2>");
            let rows: Vec<Vec<String>> = m.iter().map(|q| vec![
                f(q, "index"),
                format!("{} {}", scaled(q, "a", u.len), u.ll),
                format!("{} {}", scaled(q, "b", u.len), u.ll),
                format!("{} {}", scaled(q, "qmax", u.press), u.pl),
                format!("{} {}", scaled(q, "qmin", u.press), u.pl),
            ]).collect();
            s.push_str(&table(&["#", "a", "b", "qmax", "qmin"], &rows));
        }
    }
    if let Some(w) = result.get("warnings").and_then(|q| q.as_array()) {
        if !w.is_empty() {
            s.push_str("<h2>Advertencias</h2><ul>");
            for q in w {
                if let Some(x) = q.as_str() {
                    s.push_str(&format!("<li>{}</li>", x));
                }
            }
            s.push_str("</ul>");
        }
    }
    s.push_str("<hr><div class=\"m\">Informe nativo generado por el núcleo Rust. Verifique los resultados contra la app y la memoria de cálculo.</div></body></html>");
    s
}
