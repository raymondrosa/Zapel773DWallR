use crate::model::Bar;

#[derive(Debug, Clone, Copy)]
pub struct Section {
    pub area: f64,
    pub iy: f64,
    pub iz: f64,
    pub j: f64,
    pub width: f64,
    pub depth: f64,
}

#[derive(Debug, Clone, Copy)]
struct PolyProps {
    area: f64,
    cx: f64,
    cy: f64,
    ix: f64,
    iy: f64,
}

fn poly_props(p: &[[f64; 2]]) -> PolyProps {
    let mut area = 0.0;
    let mut sx = 0.0;
    let mut sy = 0.0;
    let mut ix = 0.0;
    let mut iy = 0.0;
    for i in 0..p.len() {
        let a = p[i];
        let b = p[(i + 1) % p.len()];
        let cr = a[0] * b[1] - b[0] * a[1];
        area += cr / 2.0;
        sx += (a[0] + b[0]) * cr / 6.0;
        sy += (a[1] + b[1]) * cr / 6.0;
        ix += cr * (a[1] * a[1] + a[1] * b[1] + b[1] * b[1]) / 12.0;
        iy += cr * (a[0] * a[0] + a[0] * b[0] + b[0] * b[0]) / 12.0;
    }
    let sign = if area < 0.0 { -1.0 } else { 1.0 };
    let abs = sign * area;
    PolyProps {
        area: abs,
        cx: if abs > 1e-300 { sx / area } else { 0.0 },
        cy: if abs > 1e-300 { sy / area } else { 0.0 },
        ix: sign * ix,
        iy: sign * iy,
    }
}

fn circle(radius: f64, n: usize) -> Vec<[f64; 2]> {
    (0..n)
        .map(|i| {
            let a = 2.0 * std::f64::consts::PI * i as f64 / n as f64;
            [radius * a.cos(), radius * a.sin()]
        })
        .collect()
}

fn rings(bar: &Bar) -> Vec<(Vec<[f64; 2]>, f64)> {
    let b = bar.b;
    let h = bar.h;
    match bar.ty.as_str() {
        "T" => {
            let x = (bar.bf - bar.bw) / 2.0;
            let y = h - bar.hf;
            vec![(
                vec![
                    [x, 0.0],
                    [x + bar.bw, 0.0],
                    [x + bar.bw, y],
                    [bar.bf, y],
                    [bar.bf, h],
                    [0.0, h],
                    [0.0, y],
                    [x, y],
                ],
                1.0,
            )]
        }
        "circ" => vec![(circle(bar.dm / 2.0, 28), 1.0)],
        "I" => {
            let x = (bar.bf - bar.tw) / 2.0;
            let d = bar.d;
            let t = bar.tf;
            vec![(
                vec![
                    [0.0, 0.0],
                    [bar.bf, 0.0],
                    [bar.bf, t],
                    [x + bar.tw, t],
                    [x + bar.tw, d - t],
                    [bar.bf, d - t],
                    [bar.bf, d],
                    [0.0, d],
                    [0.0, d - t],
                    [x, d - t],
                    [x, t],
                    [0.0, t],
                ],
                1.0,
            )]
        }
        "tubR" => {
            let t = bar.tt;
            vec![
                (vec![[0.0, 0.0], [b, 0.0], [b, h], [0.0, h]], 1.0),
                (vec![[t, t], [b - t, t], [b - t, h - t], [t, h - t]], -1.0),
            ]
        }
        "tubC" => vec![
            (circle(bar.dm / 2.0, 28), 1.0),
            (circle((bar.dm / 2.0 - bar.tt).max(1e-6), 28), -1.0),
        ],
        "poly" => vec![(bar.pts.clone(), 1.0)],
        _ => vec![(vec![[0.0, 0.0], [b, 0.0], [b, h], [0.0, h]], 1.0)],
    }
}

fn rc(a: f64, b: f64) -> f64 {
    let big = a.max(b);
    let small = a.min(b);
    big * small.powi(3)
        * (1.0 / 3.0 - 0.21 * small / big * (1.0 - small.powi(4) / (12.0 * big.powi(4))))
}

pub fn from_bar(bar: &Bar) -> Result<Section, String> {
    let rr = rings(bar);
    if rr.is_empty() {
        return Err("Seccion sin geometria.".into());
    }
    let mut area = 0.0;
    let mut sx = 0.0;
    let mut sy = 0.0;
    let mut io = 0.0;
    let mut iyo = 0.0;
    for (pts, sign) in &rr {
        if pts.len() < 3 {
            return Err("Poligono de seccion con menos de 3 vertices.".into());
        }
        let q = poly_props(pts);
        area += sign * q.area;
        sx += sign * q.area * q.cx;
        sy += sign * q.area * q.cy;
        io += sign * q.ix;
        iyo += sign * q.iy;
    }
    if !(area.abs() > 1e-12) {
        return Err(format!("Seccion '{}' con area nula o invalida.", bar.ty));
    }
    let cx = sx / area;
    let cy = sy / area;
    let mut x0 = f64::INFINITY;
    let mut x1 = f64::NEG_INFINITY;
    let mut y0 = f64::INFINITY;
    let mut y1 = f64::NEG_INFINITY;
    for (pts, sign) in &rr {
        if *sign > 0.0 {
            for p in pts {
                x0 = x0.min(p[0]);
                x1 = x1.max(p[0]);
                y0 = y0.min(p[1]);
                y1 = y1.max(p[1]);
            }
        }
    }
    let width = (x1 - x0).max(1e-12);
    let depth = (y1 - y0).max(1e-12);
    let mut i = io - area * cy * cy;
    let mut iz = iyo - area * cx * cx;
    let j = match bar.ty.as_str() {
        "rect" => rc(bar.b, bar.h),
        "T" => rc(bar.bf, bar.hf) + rc(bar.bw, bar.h - bar.hf),
        "I" => 2.0 * rc(bar.bf, bar.tf) + (bar.d - 2.0 * bar.tf) * bar.tw.powi(3) / 3.0,
        "circ" => {
            let a = std::f64::consts::PI * bar.dm.powi(2) / 4.0;
            area = a;
            i = std::f64::consts::PI * bar.dm.powi(4) / 64.0;
            iz = i;
            2.0 * i
        }
        "tubC" => {
            let di = bar.dm - 2.0 * bar.tt;
            area = std::f64::consts::PI / 4.0 * (bar.dm.powi(2) - di.powi(2));
            i = std::f64::consts::PI / 64.0 * (bar.dm.powi(4) - di.powi(4));
            iz = i;
            2.0 * i
        }
        "tubR" => {
            let t = bar.tt;
            let am = (bar.b - t) * (bar.h - t);
            let pm = 2.0 * ((bar.b - t) + (bar.h - t));
            if pm > 0.0 {
                4.0 * am * am * t / pm
            } else {
                1e-12
            }
        }
        _ => area.powi(2) / (40.0 * (i + iz).max(1e-12)),
    };
    Ok(Section { area, iy: i, iz, j, width, depth })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Bar;

    fn rect_bar(b: f64, h: f64) -> Bar {
        Bar {
            i: 0,
            j: 1,
            ty: "rect".into(),
            b,
            h,
            bf: 0.0,
            hf: 0.0,
            bw: 0.0,
            dm: 0.0,
            d: 0.0,
            tf: 0.0,
            tw: 0.0,
            tt: 0.0,
            pts: vec![],
            e: 25.0,
            ang: 0.0,
            div: 1,
            a1: 0.0,
            a2: 0.0,
            wa: 0.0,
            wb: 0.0,
            xa: 0.0,
            xb: 0.0,
            ya: 0.0,
            yb: 0.0,
            pza: 0.0,
            pzb: 0.0,
            pya: 0.0,
            pyb: 0.0,
            kz: 0.0,
            ky: 0.0,
            mat: "H".into(),
            auto_sw: false,
        }
    }

    #[test]
    fn rectangular_section_properties() {
        let s = from_bar(&rect_bar(0.3, 0.5)).unwrap();
        assert!((s.area - 0.15).abs() < 1e-12);
        assert!((s.iy - 0.3 * 0.5f64.powi(3) / 12.0).abs() < 1e-12);
        assert!((s.iz - 0.5 * 0.3f64.powi(3) / 12.0).abs() < 1e-12);
    }

    #[test]
    fn circular_section_properties() {
        let mut b = rect_bar(0.3, 0.5);
        b.ty = "circ".into();
        b.dm = 0.4;
        let s = from_bar(&b).unwrap();
        let area = std::f64::consts::PI * 0.4f64.powi(2) / 4.0;
        let inertia = std::f64::consts::PI * 0.4f64.powi(4) / 64.0;
        assert!((s.area - area).abs() < 1e-12);
        assert!((s.iy - inertia).abs() < 1e-12);
        assert!((s.j - 2.0 * inertia).abs() < 1e-12);
    }

    #[test]
    fn i_section_properties() {
        let mut b = rect_bar(0.3, 0.5);
        b.ty = "I".into();
        b.d = 0.4;
        b.bf = 0.2;
        b.tf = 0.012;
        b.tw = 0.008;
        let s = from_bar(&b).unwrap();
        let d = 0.4f64;
        let bf = 0.2f64;
        let tf = 0.012f64;
        let tw = 0.008f64;
        let area = 2.0 * bf * tf + (d - 2.0 * tf) * tw;
        let iy = bf * d.powi(3) / 12.0 - (bf - tw) * (d - 2.0 * tf).powi(3) / 12.0;
        let iz = 2.0 * tf * bf.powi(3) / 12.0 + (d - 2.0 * tf) * tw.powi(3) / 12.0;
        assert!((s.area - area).abs() < 1e-12);
        assert!((s.iy - iy).abs() < 1e-10);
        assert!((s.iz - iz).abs() < 1e-10);
    }
}
