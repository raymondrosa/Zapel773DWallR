use crate::model::Model;
use crate::sparse::Csr;
use crate::solver::DirectSolver;

#[derive(Debug, Clone)]
pub struct Mode {
    pub period: f64,
    pub frequency: f64,
    pub shape: Vec<f64>,
    pub lambda: f64,
}

pub struct ModalResult {
    pub modes: Vec<Mode>,
    pub total_weight: f64,
    pub dynamic_dofs: usize,
    pub iterations: Vec<usize>,
}

pub fn nodal_weights(model: &Model, coords: &[[f64; 3]], mass_line: &[f64]) -> Vec<f64> {
    let mut w = vec![0.0f64; coords.len()];
    for (bi, bar) in model.bars.iter().enumerate() {
        if bar.i >= coords.len() || bar.j >= coords.len() {
            continue;
        }
        let a = coords[bar.i];
        let b = coords[bar.j];
        let l = ((b[0] - a[0]).powi(2) + (b[1] - a[1]).powi(2) + (b[2] - a[2]).powi(2)).sqrt();
        let extra = mass_line.get(bi).copied().unwrap_or(0.0);
        let q = (bar.wa + bar.wb) / 2.0 + extra;
        w[bar.i] += q * l / 2.0;
        w[bar.j] += q * l / 2.0;
    }
    for wl in &model.walls {
        if wl.rig == 0.0 || wl.n.len() < 4 {
            continue;
        }
        if wl.n.iter().any(|&i| i >= coords.len()) {
            continue;
        }
        let p0 = coords[wl.n[0]];
        let p1 = coords[wl.n[1]];
        let p2 = coords[wl.n[2]];
        let p3 = coords[wl.n[3]];
        let l0 = ((p1[0]-p0[0]).powi(2)+(p1[1]-p0[1]).powi(2)+(p1[2]-p0[2]).powi(2)).sqrt();
        let l1 = ((p2[0]-p3[0]).powi(2)+(p2[1]-p3[1]).powi(2)+(p2[2]-p3[2]).powi(2)).sqrt();
        let length = (l0 + l1) / 2.0;
        let c0 = [(p0[0]+p1[0])/2.0,(p0[1]+p1[1])/2.0,(p0[2]+p1[2])/2.0];
        let c1 = [(p3[0]+p2[0])/2.0,(p3[1]+p2[1])/2.0,(p3[2]+p2[2])/2.0];
        let h = ((c1[0]-c0[0]).powi(2)+(c1[1]-c0[1]).powi(2)+(c1[2]-c0[2]).powi(2)).sqrt();
        let ww = (wl.gw * wl.t * length * h / 4.0).max(0.0);
        for &n in &wl.n {
            w[n] += ww;
        }
    }
    for (i, n) in model.nodes.iter().enumerate() {
        if n.f[2] < 0.0 {
            w[i] += -n.f[2];
        }
    }
    w
}

pub fn modal_analysis(
    k: &Csr,
    fixed: &[bool],
    model: &Model,
    coords: &[[f64; 3]],
    mass_line: &[f64],
    nmodes: usize,
    tol: f64,
    max_iter: usize,
) -> Result<ModalResult, String> {
    let n = k.n;
    let weights = nodal_weights(model, coords, mass_line);
    let total_weight: f64 = weights.iter().sum();
    if !(total_weight > 1e-9) {
        return Err("No hay masa: define cargas verticales o pesos propios.".into());
    }
    let mut mass = vec![0.0f64; n];
    let mut dynamic = Vec::new();
    for i in 0..coords.len().min(model.nodes.len()) {
        let mi = weights[i] / 9.81;
        for kk in 0..3 {
            let d = 6 * i + kk;
            if d < n {
                mass[d] = mi;
                if !fixed[d] && mi > 0.0 {
                    dynamic.push(d);
                }
            }
        }
    }
    if dynamic.is_empty() {
        return Err("No hay grados de libertad dinámicos libres.".into());
    }
    let nm = nmodes.max(1).min(60).min(dynamic.len());
    let direct = DirectSolver::new(k, fixed)?;
    let mut modes: Vec<Mode> = Vec::with_capacity(nm);
    let mut iters = Vec::with_capacity(nm);
    for p in 0..nm {
        let mut x = vec![0.0f64; n];
        for (j, &d) in dynamic.iter().enumerate() {
            x[d] = 1.0 + 0.05 * ((p + 1) * (j + 1)) as f64 / dynamic.len() as f64;
        }
        orthogonalize(&mut x, &modes, &mass);
        normalize_mass(&mut x, &mass)?;
        let mut used = 0usize;
        for _ in 0..80 {
            let mut b = vec![0.0f64; n];
            for &d in &dynamic {
                b[d] = mass[d] * x[d];
            }
            let _ = (tol, max_iter);
            let mut y = direct.solve(&b)?;
            used = 0;
            orthogonalize(&mut y, &modes, &mass);
            let nn = normalize_mass(&mut y, &mass)?;
            if nn < 1e-30 {
                return Err("Sin convergencia modal: modo nulo.".into());
            }
            let mut diff = 0.0;
            for &d in &dynamic {
                diff += (y[d] - x[d]).abs();
            }
            x = y;
            if diff < 1e-10 {
                break;
            }
        }
        let mut ky = vec![0.0f64; n];
        k.matvec(&x, &mut ky);
        let mut num = 0.0;
        let mut den = 0.0;
        for &d in &dynamic {
            num += x[d] * ky[d];
            den += mass[d] * x[d] * x[d];
        }
        if !(num > 1e-12) || !(den > 1e-30) {
            return Err("El modo calculado no tiene frecuencia positiva.".into());
        }
        let lambda = num / den;
        let omega = lambda.sqrt();
        let period = 2.0 * std::f64::consts::PI / omega;
        modes.push(Mode {
            period,
            frequency: 1.0 / period,
            shape: x,
            lambda,
        });
        iters.push(used);
    }
    Ok(ModalResult {
        modes,
        total_weight,
        dynamic_dofs: dynamic.len(),
        iterations: iters,
    })
}

fn normalize_mass(v: &mut [f64], mass: &[f64]) -> Result<f64, String> {
    let mut s = 0.0;
    for i in 0..v.len() {
        s += mass[i] * v[i] * v[i];
    }
    let nn = s.sqrt();
    if nn > 1e-30 {
        for x in v.iter_mut() {
            *x /= nn;
        }
    }
    Ok(nn)
}

fn orthogonalize(v: &mut [f64], modes: &[Mode], mass: &[f64]) {
    for m in modes {
        let mut c = 0.0;
        for i in 0..v.len() {
            c += m.shape[i] * mass[i] * v[i];
        }
        for i in 0..v.len() {
            v[i] -= c * m.shape[i];
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn weight_distribution_is_half_at_each_node() {
        let model = Model {
            nodes: vec![
                crate::model::Node { x: 0.0, y: 0.0, z: 0.0, r: [1.0; 6], f: [0.0; 6] },
                crate::model::Node { x: 0.0, y: 0.0, z: 3.0, r: [0.0; 6], f: [0.0; 6] },
            ],
            bars: vec![crate::model::Bar {
                i: 0,
                j: 1,
                ty: "rect".into(),
                b: 0.3,
                h: 0.5,
                bf: 0.0,
                hf: 0.0,
                bw: 0.0,
                dm: 0.0,
                d: 0.0,
                tf: 0.0,
                tw: 0.0,
                tt: 0.0,
                pts: vec![],
                e: 25.0,
                ang: 0.0,
                div: 1,
                a1: 0.0,
                a2: 0.0,
                wa: 5.0,
                wb: 5.0,
                xa: 0.0,
                xb: 0.0,
                ya: 0.0,
                yb: 0.0,
                pza: 0.0,
                pzb: 0.0,
                pya: 0.0,
                pyb: 0.0,
                kz: 0.0,
                ky: 0.0,
                mat: "H".into(),
                auto_sw: false,
            }],
            slabs: vec![],
            area_loads: vec![],
            walls: vec![],
            plateas: vec![],
            units: None,
            app: None,
            version: None,
            self_weight: Some(false),
        };
        let w = nodal_weights(&model, &[[0.0, 0.0, 0.0], [0.0, 0.0, 3.0]], &[0.0]);
        assert!((w[0] - 7.5).abs() < 1e-12);
        assert!((w[1] - 7.5).abs() < 1e-12);
    }
}
