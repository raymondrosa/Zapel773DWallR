use crate::section::Section;

#[derive(Debug, Clone, Copy)]
pub struct Axes {
    pub length: f64,
    pub ex: [f64; 3],
    pub ey: [f64; 3],
    pub ez: [f64; 3],
}

#[derive(Debug, Clone, Copy)]
pub struct Element {
    pub i: usize,
    pub j: usize,
    pub length: f64,
    pub axes: Axes,
    pub section: Section,
    pub e: f64,
    pub release_start: bool,
    pub release_end: bool,
    pub kz_spring: f64,
    pub ky_spring: f64,
    pub bar_index: usize,
    pub wall_index: usize,
}

fn sub(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}
fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}
fn norm(a: [f64; 3]) -> f64 {
    (a[0] * a[0] + a[1] * a[1] + a[2] * a[2]).sqrt()
}
fn normalize(a: [f64; 3]) -> [f64; 3] {
    let l = norm(a);
    [a[0] / l, a[1] / l, a[2] / l]
}

pub fn axes(pi: [f64; 3], pj: [f64; 3], angle_deg: f64) -> Option<Axes> {
    let d = sub(pj, pi);
    let length = norm(d);
    if !(length > 1e-12) {
        return None;
    }
    let ex = [d[0] / length, d[1] / length, d[2] / length];
    let reference = if ex[2].abs() > 0.999 {
        [1.0, 0.0, 0.0]
    } else {
        [0.0, 0.0, 1.0]
    };
    let ey0 = normalize(cross(reference, ex));
    let ez0 = cross(ex, ey0);
    let a = angle_deg.to_radians();
    let c = a.cos();
    let s = a.sin();
    let ey = [
        c * ey0[0] + s * ez0[0],
        c * ey0[1] + s * ez0[1],
        c * ey0[2] + s * ez0[2],
    ];
    let ez = cross(ex, ey);
    Some(Axes { length, ex, ey, ez })
}

pub fn local_stiffness(e: f64, section: Section, length: f64) -> [[f64; 12]; 12] {
    let g = e / 2.4;
    let ea_l = e * section.area / length;
    let gj_l = g * section.j / length;
    let z1 = 12.0 * e * section.iz / length.powi(3);
    let z2 = 6.0 * e * section.iz / length.powi(2);
    let z3 = 4.0 * e * section.iz / length;
    let z4 = 2.0 * e * section.iz / length;
    let y1 = 12.0 * e * section.iy / length.powi(3);
    let y2 = 6.0 * e * section.iy / length.powi(2);
    let y3 = 4.0 * e * section.iy / length;
    let y4 = 2.0 * e * section.iy / length;
    let mut k = [[0.0f64; 12]; 12];
    let mut set = |i: usize, j: usize, v: f64| {
        k[i][j] = v;
        k[j][i] = v;
    };
    set(0, 0, ea_l);
    set(0, 6, -ea_l);
    set(6, 6, ea_l);
    set(3, 3, gj_l);
    set(3, 9, -gj_l);
    set(9, 9, gj_l);
    set(1, 1, z1);
    set(1, 5, z2);
    set(1, 7, -z1);
    set(1, 11, z2);
    set(5, 5, z3);
    set(5, 7, -z2);
    set(5, 11, z4);
    set(7, 7, z1);
    set(7, 11, -z2);
    set(11, 11, z3);
    set(2, 2, y1);
    set(2, 4, -y2);
    set(2, 8, -y1);
    set(2, 10, -y2);
    set(4, 4, y3);
    set(4, 8, y2);
    set(4, 10, y4);
    set(8, 8, y1);
    set(8, 10, y2);
    set(10, 10, y3);
    k
}

pub fn cond(k: &mut [[f64; 12]; 12], f: &mut [f64; 12], rel: &[usize]) {
    for &p in rel {
        if p >= 12 { continue; }
        let d = k[p][p];
        if d.abs() < 1e-12 { continue; }
        let kc: Vec<f64> = (0..12).map(|i| k[i][p]).collect();
        let kr: Vec<f64> = (0..12).map(|j| k[p][j]).collect();
        let fp = f[p];
        for i in 0..12 {
            for j in 0..12 {
                k[i][j] -= kc[i] * kr[j] / d;
            }
            f[i] -= kc[i] * fp / d;
        }
    }
}

pub fn hm(x: f64, l: f64) -> [f64; 4] {
    [1.0 - 3.0*x*x + 2.0*x*x*x, l*(x - 2.0*x*x + x*x*x), 3.0*x*x - 2.0*x*x*x, l*(x*x*x - x*x)]
}

static GP: [[f64; 2]; 4] = [
    [0.0694318442029737, 0.173927422568727],
    [0.330009478207572, 0.326072577431273],
    [0.669990521792428, 0.326072577431273],
    [0.930568155797026, 0.173927422568727],
];

pub fn add_geometric_springs(k: &mut [[f64; 12]; 12], l: f64, kz0: f64, ky0: f64) {
    if kz0.abs() < 1e-15 && ky0.abs() < 1e-15 { return; }
    for [x, w] in GP {
        let h = hm(x, l);
        let nz = [h[0], -h[1], h[2], -h[3]];
        let iy = [1usize, 5, 7, 11];
        let iz = [2usize, 4, 8, 10];
        for a in 0..4 {
            for b in 0..4 {
                k[iy[a]][iy[b]] += ky0 * l * w * h[a] * h[b];
                k[iz[a]][iz[b]] += kz0 * l * w * nz[a] * nz[b];
            }
        }
    }
}

pub fn release_dofs(start: bool, end: bool) -> Vec<usize> {
    let mut r = Vec::new();
    if start { r.push(4); r.push(5); }
    if end { r.push(10); r.push(11); }
    r
}

pub fn global_stiffness(el: &Element) -> [[f64; 12]; 12] {
    let mut kl = local_stiffness(el.e, el.section, el.length);
    add_geometric_springs(&mut kl, el.length, el.kz_spring, el.ky_spring);
    let mut dummy = [0.0f64; 12];
    cond(&mut kl, &mut dummy, &release_dofs(el.release_start, el.release_end));
    let r = [el.axes.ex, el.axes.ey, el.axes.ez];
    let mut t = [[0.0f64; 12]; 12];
    for b in 0..4 {
        for i in 0..3 {
            for j in 0..3 {
                t[3 * b + i][3 * b + j] = r[i][j];
            }
        }
    }
    let mut kt = [[0.0f64; 12]; 12];
    for i in 0..12 {
        for j in 0..12 {
            let mut s = 0.0;
            for k in 0..12 {
                s += t[k][i] * kl[k][j];
            }
            kt[i][j] = s;
        }
    }
    let mut kg = [[0.0f64; 12]; 12];
    for i in 0..12 {
        for j in 0..12 {
            let mut s = 0.0;
            for k in 0..12 {
                s += kt[i][k] * t[k][j];
            }
            kg[i][j] = s;
        }
    }
    kg
}

pub fn dofs(el: &Element) -> [usize; 12] {
    let mut d = [0usize; 12];
    for k in 0..6 {
        d[k] = 6 * el.i + k;
        d[k + 6] = 6 * el.j + k;
    }
    d
}

/// Matriz de transformación local→global (igual que la app).
pub fn transform(ax: &Axes) -> [[f64; 12]; 12] {
    let r = [ax.ex, ax.ey, ax.ez];
    let mut t = [[0.0f64; 12]; 12];
    for b in 0..4 {
        for i in 0..3 {
            for j in 0..3 {
                t[3 * b + i][3 * b + j] = r[i][j];
            }
        }
    }
    t
}


#[cfg(test)]
mod tests {
    use super::*;
    use crate::section::Section;

    #[test]
    fn axes_are_orthonormal() {
        let a = axes([0.0,0.0,0.0],[3.0,4.0,0.0],0.0).unwrap();
        assert!((a.length - 5.0).abs() < 1e-12);
        assert!((a.ex[0]*a.ey[0]+a.ex[1]*a.ey[1]+a.ex[2]*a.ey[2]).abs() < 1e-12);
        assert!((a.ex[0]*a.ez[0]+a.ex[1]*a.ez[1]+a.ex[2]*a.ez[2]).abs() < 1e-12);
    }

    #[test]
    fn cantilever_stiffness_is_symmetric() {
        let ax = axes([0.0,0.0,0.0],[0.0,0.0,3.0],0.0).unwrap();
        let el = Element {
            i: 0,
            j: 1,
            length: ax.length,
            axes: ax,
            section: Section {
                area: 0.15,
                iy: 0.003125,
                iz: 0.001125,
                j: 0.0004,
                width: 0.3,
                depth: 0.5,
            },
            e: 25e6,
            release_start: false,
            release_end: false,
            kz_spring: 0.0,
            ky_spring: 0.0,
            bar_index: usize::MAX,
            wall_index: usize::MAX,
        };
        let k = global_stiffness(&el);
        for i in 0..12 { for j in 0..12 { assert!((k[i][j]-k[j][i]).abs() < 1e-6); } }
    }
}


fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
}

fn interp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

/// Carga nodal equivalente en coordenadas locales para cargas lineales
/// qx, qy, qz y momentos pya/pza, siguiendo la formulacion de la app.
pub fn equivalent_load(bar: &crate::model::Bar, ax: Axes, t0: f64, t1: f64) -> [f64; 12] {
    let w0 = interp(bar.wa, bar.wb, t0);
    let w1 = interp(bar.wa, bar.wb, t1);
    let fa = [interp(bar.xa, bar.xb, t0), interp(bar.ya, bar.yb, t0), -w0];
    let fb = [interp(bar.xa, bar.xb, t1), interp(bar.ya, bar.yb, t1), -w1];
    let qxa = dot(fa, ax.ex);
    let qxb = dot(fb, ax.ex);
    let qya = dot(fa, ax.ey) + interp(bar.pya, bar.pyb, t0);
    let qyb = dot(fb, ax.ey) + interp(bar.pya, bar.pyb, t1);
    let qza = dot(fa, ax.ez) - interp(bar.pza, bar.pzb, t0);
    let qzb = dot(fb, ax.ez) - interp(bar.pza, bar.pzb, t1);
    let l = ax.length;
    let tf = |qa: f64, qb: f64| -> [f64;4] {
        [
            qa*l/2.0 + 3.0*(qb-qa)*l/20.0,
            qa*l*l/12.0 + (qb-qa)*l*l/30.0,
            qa*l/2.0 + 7.0*(qb-qa)*l/20.0,
            -qa*l*l/12.0 - (qb-qa)*l*l/20.0,
        ]
    };
    let y = tf(qya, qyb);
    let z = tf(qza, qzb);
    [
        l*(2.0*qxa + qxb)/6.0, y[0], z[0], 0.0, -z[1], y[1],
        l*(qxa + 2.0*qxb)/6.0, y[2], z[2], 0.0, -z[3], y[3],
    ]
}

pub fn equivalent_global(
    bar: &crate::model::Bar,
    ax: Axes,
    t0: f64,
    t1: f64,
    section: Section,
    e: f64,
    release_start: bool,
    release_end: bool,
    kz_spring: f64,
    ky_spring: f64,
) -> [f64; 12] {
    let mut f = equivalent_load(bar, ax, t0, t1);
    let mut kl = local_stiffness(e, section, ax.length);
    add_geometric_springs(&mut kl, ax.length, kz_spring, ky_spring);
    cond(&mut kl, &mut f, &release_dofs(release_start, release_end));
    let r = [ax.ex, ax.ey, ax.ez];
    let mut t = [[0.0f64; 12]; 12];
    for b in 0..4 {
        for i in 0..3 {
            for j in 0..3 {
                t[3*b+i][3*b+j] = r[i][j];
            }
        }
    }
    let mut fg = [0.0f64; 12];
    for p in 0..12 {
        let mut s = 0.0;
        for i in 0..12 {
            s += t[i][p] * f[i];
        }
        fg[p] = s;
    }
    fg
}
