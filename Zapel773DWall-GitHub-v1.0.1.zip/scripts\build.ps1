#Requires -Version 7.0
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$desktop = Join-Path $root 'desktop'
$solver = Join-Path $root 'rust-solver'

Write-Host '1/4 Copiando interfaz web...'
Copy-Item (Join-Path $root 'src\Zapel773DWall.html') (Join-Path $desktop 'app.html') -Force

Write-Host '2/4 Compilando solver Rust...'
Push-Location $solver
try {
    cargo build --release
    if ($LASTEXITCODE -ne 0) { throw 'Fallo la compilacion Rust.' }
} finally {
    Pop-Location
}

Write-Host '3/4 Empaquetando Electron...'
Push-Location $desktop
try {
    if (-not (Test-Path 'node_modules')) {
        pnpm install
    }
    pnpm run package
    if ($LASTEXITCODE -ne 0) { throw 'Fallo el empaquetado Electron.' }
} finally {
    Pop-Location
}

Write-Host '4/4 Generando ZIP portatil...'
$pkg = Join-Path $desktop 'dist\Zapel773DWall-win32-x64'
if (-not (Test-Path $pkg)) { throw "No se encontro $pkg" }
$zip = Join-Path $root 'Zapel773DWall-Escritorio.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path $pkg -DestinationPath $zip -CompressionLevel Optimal

$hash = (Get-FileHash $zip -Algorithm SHA256).Hash
Write-Host "Listo: $zip"
Write-Host "SHA-256: $hash"
