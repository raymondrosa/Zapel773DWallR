use crate::frame::{self, Element};
use crate::model::{Bar, Model};
use crate::post::ElemLoad;
use crate::section::{self, Section};

/// Idealiza muros rigidos como columna equivalente + cuatro brazos rigidos,
/// siguiendo la formulacion de la app.
pub fn add_rigid_walls(
    model: &Model,
    coords: &mut Vec<[f64; 3]>,
    fixes: &mut Vec<[bool; 6]>,
    loads: &mut Vec<[f64; 6]>,
    elements: &mut Vec<Element>,
    element_loads: &mut Vec<[f64; 12]>,
    elem_info: &mut Vec<ElemLoad>,
    warnings: &mut Vec<String>,
) {
    for (wi, w) in model.walls.iter().enumerate() {
        if w.rig == 0.0 {
            continue;
        }
        if w.n.len() < 4 {
            warnings.push(format!("Muro {}: se esperaban 4 nudos.", wi + 1));
            continue;
        }
        if w.n.iter().any(|&i| i >= coords.len()) {
            warnings.push(format!("Muro {}: nudo inexistente.", wi + 1));
            continue;
        }
        let p0 = coords[w.n[0]];
        let p1 = coords[w.n[1]];
        let p2 = coords[w.n[2]];
        let p3 = coords[w.n[3]];
        let c0 = [
            (p0[0] + p1[0]) / 2.0,
            (p0[1] + p1[1]) / 2.0,
            (p0[2] + p1[2]) / 2.0,
        ];
        let c1 = [
            (p3[0] + p2[0]) / 2.0,
            (p3[1] + p2[1]) / 2.0,
            (p3[2] + p2[2]) / 2.0,
        ];
        let l0 = ((p1[0] - p0[0]).powi(2) + (p1[1] - p0[1]).powi(2) + (p1[2] - p0[2]).powi(2)).sqrt();
        let l1 = ((p2[0] - p3[0]).powi(2) + (p2[1] - p3[1]).powi(2) + (p2[2] - p3[2]).powi(2)).sqrt();
        let length = (l0 + l1) / 2.0;
        let h = ((c1[0] - c0[0]).powi(2) + (c1[1] - c0[1]).powi(2) + (c1[2] - c0[2]).powi(2)).sqrt();
        if !(length > 1e-9 && h > 1e-9) {
            warnings.push(format!("Muro {}: geometria nula.", wi + 1));
            continue;
        }
        let i0 = coords.len();
        coords.push(c0);
        fixes.push([false; 6]);
        loads.push([0.0; 6]);
        let i1 = coords.len();
        coords.push(c1);
        fixes.push([false; 6]);
        loads.push([0.0; 6]);

        // Columna equivalente en el eje del muro.
        // La seccion t x L de la columna debe girarse con la direccion del muro:
        // ang = atan2(p1.y-p0.y, p1.x-p0.x) en grados, igual que wallGeo(w).th
        // de la app (Zapel773DWall-index.html:523).
        let th_deg = (p1[1] - p0[1])
            .atan2(p1[0] - p0[0])
            .to_degrees();
        let mut col_bar = Bar::rect(i0, i1, w.t.max(1e-6), length, w.e);
        col_bar.ang = th_deg;
        col_bar.wa = w.gw.max(0.0) * w.t.max(0.0) * length;
        col_bar.wb = col_bar.wa;
        let col_sec = match section::from_bar(&col_bar) {
            Ok(s) => s,
            Err(e) => {
                warnings.push(format!("Muro {}: {}", wi + 1, e));
                continue;
            }
        };
        if let Some(ax) = frame::axes(c0, c1, th_deg) {
            let e = w.e * 1e6;
            elements.push(Element {
                i: i0,
                j: i1,
                length: ax.length,
                axes: ax,
                section: col_sec,
                e,
                release_start: false,
                release_end: false,
                kz_spring: 0.0,
                ky_spring: 0.0,
                bar_index: usize::MAX,
                wall_index: wi,
            });
            element_loads.push(frame::equivalent_global(
                &col_bar,
                ax,
                0.0,
                1.0,
                col_sec,
                e,
                false,
                false,
                0.0,
                0.0,
            ));
            elem_info.push(ElemLoad::new(&col_bar, &ax, 0.0, 1.0));
        }

        // Brazos rigidos desde las esquinas a los extremos de la columna.
        let e_w = w.e * 1e6;
        let sec_col = col_sec;
        let sm = (sec_col.area * e_w / h)
            .max(12.0 * e_w * sec_col.iy / h.powi(3))
            .max(12.0 * e_w * sec_col.iz / h.powi(3));
        let kr = 1e4 * sm;
        let pairs = [
            (w.n[0], i0),
            (w.n[1], i0),
            (w.n[3], i1),
            (w.n[2], i1),
        ];
        for (a, b) in pairs {
            let pa = coords[a];
            let pb = coords[b];
            let la = ((pb[0] - pa[0]).powi(2) + (pb[1] - pa[1]).powi(2) + (pb[2] - pa[2]).powi(2)).sqrt();
            if !(la > 1e-9) {
                continue;
            }
            if let Some(ax) = frame::axes(pa, pb, 0.0) {
                let ia = kr * la.powi(3) / (12.0 * e_w);
                let aa = kr * la / e_w;
                elements.push(Element {
                    i: a,
                    j: b,
                    length: la,
                    axes: ax,
                    section: Section {
                        area: aa,
                        iy: ia,
                        iz: ia,
                        j: ia,
                        width: 1.0,
                        depth: 1.0,
                    },
                    e: e_w,
                    release_start: false,
                    release_end: false,
                    kz_spring: 0.0,
                    ky_spring: 0.0,
                    bar_index: usize::MAX,
                    wall_index: usize::MAX,
                });
                element_loads.push([0.0; 12]);
                elem_info.push(ElemLoad::default());
            }
        }

        if w.fix != 0.0 {
            for &n in &[w.n[0], w.n[1]] {
                for k in 0..6 {
                    fixes[n][k] = true;
                }
            }
        }
    }
}
