use crate::frame::{self, Element};
use crate::model::{Bar, Model, Platea};
use crate::section;
use crate::solver::{solve_direct, solve_pcg};
use crate::sparse::Csr;

/// Constantes por defecto de la app para matres (`DEFPL`,
/// Zapel773DWall-index.html:1248). `DEFPL.H = 8*IN = 0.2032 m`.
const DEFPL_H: f64 = 8.0 * 0.0254;
const DEFPL_KS: f64 = 20000.0;
const DEFPL_S: f64 = 0.8;
const DEFPL_FC: f64 = 28.0;

#[derive(Debug, Clone)]
pub struct MatResult {
    pub a: f64,
    pub b: f64,
    pub h: f64,
    pub ks: f64,
    pub cols: usize,
    pub qmax: f64,
    pub qmin: f64,
    pub uzmax: f64,
    pub x0: f64,
    pub y0: f64,
    pub z: f64,
    pub nx: usize,
    pub ny: usize,
    pub sx: f64,
    pub sy: f64,
    pub grid: Vec<f64>,
    // Salidas de diseno que reporta la app (`plateaCalc0`, HTML:1266-1323).
    pub p: f64,
    pub area: f64,
    pub qa: f64,
    pub q_r: f64,
    pub q_rmin: f64,
    pub ok_q: bool,
    pub ok_n: bool,
    pub vu_p: f64,
    pub ok_p: bool,
}

/// Marco local de una matre rectangular (equivalente a `esRect()` de la app,
/// Zapel773DWall-index.html:640-647): admite rectangulos rotados.
struct RectFrame {
    a: f64,
    b: f64,
    p0: [f64; 2],
    ex: [f64; 2],
    ey: [f64; 2],
}

fn es_rect(pts: &[[f64; 2]]) -> Option<RectFrame> {
    if pts.len() != 4 {
        return None;
    }
    let d = |i: usize, j: usize| -> [f64; 2] {
        [pts[j][0] - pts[i][0], pts[j][1] - pts[i][1]]
    };
    let a1 = d(0, 1);
    let b1 = d(1, 2);
    let a2 = d(2, 3);
    let b2 = d(3, 0);
    let la = (a1[0] * a1[0] + a1[1] * a1[1]).sqrt();
    let lb = (b1[0] * b1[0] + b1[1] * b1[1]).sqrt();
    let la2 = (a2[0] * a2[0] + a2[1] * a2[1]).sqrt();
    let lb2 = (b2[0] * b2[0] + b2[1] * b2[1]).sqrt();
    if la < 1e-6 || lb < 1e-6 {
        return None;
    }
    if (la - la2).abs() > 2e-3 * la.max(la2) || (lb - lb2).abs() > 2e-3 * lb.max(lb2) {
        return None;
    }
    if ((a1[0] * b1[0] + a1[1] * b1[1]) / (la * lb)).abs() > 3e-3 {
        return None;
    }
    Some(RectFrame {
        a: la,
        b: lb,
        p0: pts[0],
        ex: [a1[0] / la, a1[1] / la],
        ey: [b1[0] / lb, b1[1] / lb],
    })
}

/// `toPrecision(5)` de JS aplicado al E de la grilla: la app usa
/// `+(4.7*sqrt(fc)).toPrecision(5)` (HTML:1282-1283).
fn sig5(x: f64) -> f64 {
    if !x.is_finite() || x == 0.0 {
        return x;
    }
    let d = x.abs().log10().floor() as i32;
    let f = 10f64.powi(4 - d);
    (x * f).round() / f
}

/// Dimensiones de la columna que llega al nudo (equivalente a `columnAt()`,
/// Zapel773DWall-index.html:2262-2266). Devuelve [ancho, canto] del ultimo
/// elemento que llega verticalmente al nudo, o [0.3, 0.3].
fn column_at(model: &Model, node: usize) -> [f64; 2] {
    let mut r = [0.3, 0.3];
    let coords: Vec<[f64; 3]> = model.nodes.iter().map(|n| [n.x, n.y, n.z]).collect();
    for b in &model.bars {
        if b.i != node && b.j != node {
            continue;
        }
        if b.i >= coords.len() || b.j >= coords.len() {
            continue;
        }
        let a = coords[b.i];
        let c = coords[b.j];
        let dz = (c[2] - a[2]).abs();
        let dh = ((c[0] - a[0]).powi(2) + (c[1] - a[1]).powi(2)).sqrt();
        if dz > 0.0 && dz >= dh {
            if let Ok(sp0) = section::from_bar(b) {
                let w = if sp0.width > 0.0 { sp0.width } else { 0.3 };
                let dd = if sp0.depth > 0.0 { sp0.depth } else { 0.3 };
                r = [w, dd];
            }
        }
    }
    r
}

/// Analiza las matres del modelo con una grilla equivalente de vigas sobre
/// resortes de balasto, siguiendo la formulacion de `plateaCalc0()` de la app
/// (Zapel773DWall-index.html:1256-1323).
pub fn analyze_plateas(
    model: &Model,
    reactions: &[f64],
    warnings: &mut Vec<String>,
    self_weight: bool,
) -> Vec<serde_json::Value> {
    let mut out = Vec::new();
    for (pi, pl) in model.plateas.iter().enumerate() {
        match analyze_one(pl, model, reactions, self_weight) {
            Ok(r) => out.push(serde_json::json!({
                "index": pi + 1,
                "a": r.a,
                "b": r.b,
                "A": r.area,
                "P": r.p,
                "H": r.h,
                "ks": r.ks,
                "qa": r.qa,
                "columns": r.cols,
                "qR": r.q_r,
                "qRmin": r.q_rmin,
                "okQ": r.ok_q,
                "okN": r.ok_n,
                "vuP": r.vu_p,
                "okP": r.ok_p,
                "qmax": r.qmax,
                "qmin": r.qmin,
                "uzmax": r.uzmax,
                "x0": r.x0,
                "y0": r.y0,
                "z": r.z,
                "nx": r.nx,
                "ny": r.ny,
                "sx": r.sx,
                "sy": r.sy,
                "grid": r.grid
            })),
            Err(e) => warnings.push(format!("Matre {}: {}", pi + 1, e)),
        }
    }
    out
}

fn analyze_one(pl: &Platea, model: &Model, reactions: &[f64], self_weight: bool) -> Result<MatResult, String> {
    if pl.pts.len() < 3 {
        return Err("poligono invalido".into());
    }
    let rf = es_rect(&pl.pts).ok_or("la matre debe ser rectangular.")?;
    let a = rf.a;
    let b = rf.b;
    let h = if pl.h > 0.0 { pl.h } else { DEFPL_H };
    let ks = if pl.ks > 0.0 { pl.ks } else { DEFPL_KS };
    let s = (if pl.s > 0.0 { pl.s } else { DEFPL_S }).max(0.3);
    let fc = if pl.fc > 0.0 { pl.fc } else { DEFPL_FC };
    let qa = if pl.qa.is_finite() { pl.qa } else { 0.0 };
    let e_gpa = sig5(4.7 * fc.sqrt());
    let nx = ((a / s).round() as usize).max(2);
    let ny = ((b / s).round() as usize).max(2);
    let sx = a / nx as f64;
    let sy = b / ny as f64;
    let zn = pl.z;
    let n_nodes = (nx + 1) * (ny + 1);
    let n = n_nodes * 6;
    let id = |i: usize, j: usize| j * (nx + 1) + i;
    let mut coords: Vec<[f64; 3]> = Vec::with_capacity(n_nodes);
    for j in 0..=ny {
        for i in 0..=nx {
            let x = rf.p0[0] + rf.ex[0] * (i as f64 * sx) + rf.ey[0] * (j as f64 * sy);
            let y = rf.p0[1] + rf.ex[1] * (i as f64 * sx) + rf.ey[1] * (j as f64 * sy);
            coords.push([x, y, zn]);
        }
    }
    // Todos los nudos de la grilla tienen Ux, Uy y Rz restringidos
    // (r = [1,1,0,0,0,1] en la app).
    let mut fixed = vec![false; n];
    for k in 0..n_nodes {
        fixed[6 * k] = true;
        fixed[6 * k + 1] = true;
        fixed[6 * k + 5] = true;
    }
    // Columnas: nudos con alguna restriccion dentro del rectangulo de la matre.
    struct Col {
        node: usize,
        u: f64,
        v: f64,
        rz: f64,
        mx: f64,
        my: f64,
    }
    let mut cols: Vec<Col> = Vec::new();
    for (ni, node) in model.nodes.iter().enumerate() {
        if !node.r.iter().any(|v| *v != 0.0) {
            continue;
        }
        if reactions.len() < 6 * model.nodes.len() {
            continue;
        }
        let dx = node.x - rf.p0[0];
        let dy = node.y - rf.p0[1];
        let u = dx * rf.ex[0] + dy * rf.ex[1];
        let v = dx * rf.ey[0] + dy * rf.ey[1];
        if u < -1e-6 || u > a + 1e-6 || v < -1e-6 || v > b + 1e-6 {
            continue;
        }
        cols.push(Col {
            node: ni,
            u,
            v,
            rz: reactions[6 * ni + 2],
            mx: reactions[6 * ni + 3],
            my: reactions[6 * ni + 4],
        });
    }
    if cols.is_empty() {
        return Err("no hay apoyos dentro de la matre.".into());
    }
    // Presion analitica de contacto (app HTML:1266-1271).
    let area = a * b;
    let p: f64 = cols.iter().map(|c| c.rz).sum();
    let cx = a / 2.0;
    let cy = b / 2.0;
    let mu: f64 = cols
        .iter()
        .map(|c| c.rz * (c.v - cy) + c.mx * rf.ex[0] + c.my * rf.ex[1])
        .sum();
    let mv: f64 = cols
        .iter()
        .map(|c| -c.rz * (c.u - cx) + c.mx * rf.ey[0] + c.my * rf.ey[1])
        .sum();
    let iu = a * b * b * b / 12.0;
    let iv = b * a * a * a / 12.0;
    let q_r = p / area + mv.abs() * (a / 2.0) / iv + mu.abs() * (b / 2.0) / iu;
    let q_rmin = p / area - mv.abs() * (a / 2.0) / iv - mu.abs() * (b / 2.0) / iu;
    let qa_eff = if qa == 0.0 { 1e18 } else { qa };
    let ok_q = q_r <= qa_eff;
    let ok_n = q_rmin >= 0.0;

    // Cargas nodales en la grilla equivalente (app HTML:1284-1285).
    let mut f = vec![0.0f64; n];
    for c in &cols {
        let gi = ((c.u / sx).round() as isize).clamp(0, nx as isize) as usize;
        let gj = ((c.v / sy).round() as isize).clamp(0, ny as isize) as usize;
        let k = id(gi, gj);
        f[6 * k + 2] -= c.rz;
        f[6 * k + 3] += c.mx;
        f[6 * k + 4] += c.my;
    }

    let mut triplets: Vec<(u32, u32, f64)> = Vec::new();
    let e = e_gpa * 1e6;
    let mut elements: Vec<Element> = Vec::new();
    let mut add_bar = |i: usize, j: usize, width: f64, kz: f64| {
        let mut bar = Bar::rect(i, j, width, h, e_gpa);
        bar.kz = kz;
        if let Ok(sec) = section::from_bar(&bar) {
            let p0 = coords[i];
            let p1 = coords[j];
            if let Some(ax) = frame::axes(p0, p1, 0.0) {
                let el = Element {
                    i,
                    j,
                    length: ax.length,
                    axes: ax,
                    section: sec,
                    e,
                    release_start: false,
                    release_end: false,
                    kz_spring: bar.kz * sec.width,
                    ky_spring: 0.0,
                    bar_index: usize::MAX,
                    wall_index: usize::MAX,
                };
                // La app incluye el peso propio de la grilla equivalente
                // (barSW sobre cada viga de la grilla). Se replica para que
                // las presiones de contacto coincidan con la app.
                if self_weight {
                    let qsw = 24.0 * width * h;
                    bar.wa = qsw;
                    bar.wb = qsw;
                    let load = frame::equivalent_global(&bar, ax, 0.0, 1.0, sec, e, false, false, el.kz_spring, 0.0);
                    let dofs = frame::dofs(&el);
                    for k in 0..12 { f[dofs[k]] += load[k]; }
                }
                let kg = frame::global_stiffness(&el);
                let dofs = frame::dofs(&el);
                for aa in 0..12 {
                    for bb in 0..12 {
                        let v = kg[aa][bb];
                        if v.abs() > 1e-14 {
                            triplets.push((dofs[aa] as u32, dofs[bb] as u32, v));
                        }
                    }
                }
                elements.push(el);
            }
        }
    };
    for j in 0..=ny {
        for i in 0..nx {
            add_bar(id(i, j), id(i + 1, j), sy, ks * sy / 2.0);
        }
    }
    for j in 0..ny {
        for i in 0..=nx {
            add_bar(id(i, j), id(i, j + 1), sx, ks * sx / 2.0);
        }
    }
    let k = Csr::from_triplets(n, triplets);
    // La app resuelve con eliminacion densa; aqui se usa el solver directo
    // disperso y, si fallara, PCG (mismo resultado numerico).
    let u = match solve_direct(&k, &f, &fixed) {
        Ok(u) => u,
        Err(_) => solve_pcg(&k, &f, &fixed, 1e-10, 100000)?.u,
    };
    let mut qmax = f64::NEG_INFINITY;
    let mut qmin = f64::INFINITY;
    let mut uzmax = 0.0f64;
    let mut grid = Vec::with_capacity(n_nodes);
    for ni in 0..n_nodes {
        let q = -ks * u[6 * ni + 2];
        grid.push(q);
        qmax = qmax.max(q);
        qmin = qmin.min(q);
        uzmax = uzmax.max(u[6 * ni + 2].abs());
    }

    // Punzonamiento por columna (app HTML:1314-1321).
    let d_p = (h - 0.08).max(0.1);
    let mut vu_p = 0.0f64;
    let mut ok_p = true;
    for c in &cols {
        let cl = column_at(model, c.node);
        let b0 = 2.0 * ((cl[0] + d_p) + (cl[1] + d_p));
        let vu = 1.4 * c.rz.abs() / (b0 * d_p);
        if vu > vu_p {
            vu_p = vu;
        }
        let beta = cl[0].max(cl[1]) / cl[1].min(cl[0]).max(1e-3);
        let vc = 0.75
            * 0.33_f64
                .min(0.17 * (1.0 + 2.0 / beta))
                .min(0.083 * (2.0 + 40.0 * d_p / b0))
            * fc.sqrt()
            * 1000.0;
        if vu > vc {
            ok_p = false;
        }
    }

    let _ = &elements;
    let x0 = coords
        .iter()
        .map(|p| p[0])
        .fold(f64::INFINITY, f64::min);
    let y0 = coords
        .iter()
        .map(|p| p[1])
        .fold(f64::NEG_INFINITY, f64::min);
    let x0 = if x0.is_finite() { x0 } else { 0.0 };
    let y0 = if y0.is_finite() { y0 } else { 0.0 };
    Ok(MatResult {
        a,
        b,
        h,
        ks,
        cols: cols.len(),
        qmax,
        qmin,
        uzmax,
        x0,
        y0,
        z: zn,
        nx,
        ny,
        sx,
        sy,
        grid,
        p,
        area,
        qa,
        q_r,
        q_rmin,
        ok_q,
        ok_n,
        vu_p,
        ok_p,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{Bar, Model, Node, Platea};

    fn approx(a: f64, b: f64, tol: f64) -> bool {
        (a - b).abs() <= tol * b.abs().max(1.0)
    }

    #[test]
    fn es_rect_acepta_rectangulo_rotado() {
        let p = [[0.0, 0.0], [1.0, 1.0], [0.0, 2.0], [-1.0, 1.0]];
        let r = es_rect(&p).expect("rectangulo rotado");
        assert!(approx(r.a, 2f64.sqrt(), 1e-12));
        assert!(approx(r.b, 2f64.sqrt(), 1e-12));
    }

    #[test]
    fn es_rect_rechaza_no_rectangulo() {
        let p = [[0.0, 0.0], [2.0, 0.0], [3.0, 1.0], [0.0, 1.0]];
        assert!(es_rect(&p).is_none());
    }

    #[test]
    fn matre_centrada_presion_analitica() {
        // Matre 4x4 m, columna centrada con 100 kN: qR = P/A = 6.25 kN/m2.
        let node = |x: f64, y: f64, fix: [f64; 6], f: [f64; 6]| Node { x, y, z: 0.0, r: fix, f };
        let model = Model {
            nodes: vec![
                node(2.0, 2.0, [1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [0.0, 0.0, -100.0, 0.0, 0.0, 0.0]),
                node(2.0, 2.0, [0.0; 6], [0.0; 6]),
            ],
            bars: vec![Bar::rect(0, 1, 0.4, 0.4, 25.0)],
            slabs: vec![],
            area_loads: vec![],
            walls: vec![],
            plateas: vec![Platea {
                pts: vec![[0.0, 0.0], [4.0, 0.0], [4.0, 4.0], [0.0, 4.0]],
                z: 0.0,
                h: 0.6,
                ks: 20000.0,
                qa: 200.0,
                fc: 28.0,
                fy: 420.0,
                s: 0.5,
            }],
            units: None,
            app: None,
            version: None,
            self_weight: Some(false),
        };
        // Reaccion del analisis estatico: Fz = -100 en el nudo 0 restringido.
        let mut reactions = vec![0.0f64; 12];
        reactions[2] = 100.0;
        let mut warns = Vec::new();
        let mats = analyze_plateas(&model, &reactions, &mut warns, false);
        assert_eq!(mats.len(), 1);
        let m = &mats[0];
        assert!(approx(m["qR"].as_f64().unwrap(), 6.25, 1e-9));
        assert!(approx(m["qRmin"].as_f64().unwrap(), 6.25, 1e-9));
        assert!(m["okN"].as_bool().unwrap());
        assert_eq!(m["columns"].as_u64().unwrap(), 1);
        assert!(warns.is_empty());
    }
}
