use serde::Deserialize;

#[derive(Debug, Deserialize, Clone)]
pub struct Model {
    #[serde(rename = "N", default)]
    pub nodes: Vec<Node>,
    #[serde(rename = "B", default)]
    pub bars: Vec<Bar>,
    #[serde(rename = "LOSAS", default)]
    pub slabs: Vec<Slab>,
    #[serde(rename = "CARGAS", default)]
    pub area_loads: Vec<AreaLoad>,
    #[serde(rename = "MUROS", default)]
    pub walls: Vec<Wall>,
    #[serde(rename = "PLATEAS", default)]
    pub plateas: Vec<Platea>,
    #[serde(default)]
    pub units: Option<String>,
    #[serde(rename = "app", default)]
    pub app: Option<String>,
    #[serde(rename = "v", default)]
    pub version: Option<u32>,
    #[serde(rename = "sw", default)]
    pub self_weight: Option<bool>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct Node {
    #[serde(default)]
    pub x: f64,
    #[serde(default)]
    pub y: f64,
    #[serde(default)]
    pub z: f64,
    #[serde(default = "zero6")]
    pub r: [f64; 6],
    #[serde(default = "zero6")]
    pub f: [f64; 6],
}

fn zero6() -> [f64; 6] {
    [0.0; 6]
}
fn def_ty() -> String {
    "rect".to_string()
}
fn def_b() -> f64 {
    0.3
}
fn def_h() -> f64 {
    0.5
}
fn def_e() -> f64 {
    25.0
}
fn def_gw() -> f64 {
    24.0
}
fn def_div() -> usize {
    4
}
fn def_ang() -> f64 {
    0.0
}

#[derive(Debug, Deserialize, Clone)]
pub struct Bar {
    #[serde(default)]
    pub i: usize,
    #[serde(default)]
    pub j: usize,
    #[serde(default = "def_ty")]
    pub ty: String,
    #[serde(default = "def_b")]
    pub b: f64,
    #[serde(default = "def_h")]
    pub h: f64,
    #[serde(default)]
    pub bf: f64,
    #[serde(default)]
    pub hf: f64,
    #[serde(default)]
    pub bw: f64,
    #[serde(rename = "Dm", default)]
    pub dm: f64,
    #[serde(default)]
    pub d: f64,
    #[serde(default)]
    pub tf: f64,
    #[serde(default)]
    pub tw: f64,
    #[serde(default)]
    pub tt: f64,
    #[serde(default)]
    pub pts: Vec<[f64; 2]>,
    #[serde(rename = "E", default = "def_e")]
    pub e: f64,
    #[serde(default = "def_ang")]
    pub ang: f64,
    #[serde(default = "def_div")]
    pub div: usize,
    #[serde(default)]
    pub mat: String,
    #[serde(skip)]
    pub auto_sw: bool,
    #[serde(default)]
    pub a1: f64,
    #[serde(default)]
    pub a2: f64,
    #[serde(default)]
    pub wa: f64,
    #[serde(default)]
    pub wb: f64,
    #[serde(default)]
    pub xa: f64,
    #[serde(default)]
    pub xb: f64,
    #[serde(default)]
    pub ya: f64,
    #[serde(default)]
    pub yb: f64,
    #[serde(default)]
    pub pza: f64,
    #[serde(default)]
    pub pzb: f64,
    #[serde(default)]
    pub pya: f64,
    #[serde(default)]
    pub pyb: f64,
    #[serde(default)]
    pub kz: f64,
    #[serde(default)]
    pub ky: f64,
}

impl Model {
    pub fn validate(&self) -> Result<(), String> {
        if self.nodes.is_empty() {
            return Err("El modelo no contiene nudos (N).".into());
        }
        if self.bars.is_empty() && self.walls.is_empty() {
            return Err("El modelo no contiene barras (B) ni muros (MUROS).".into());
        }
        for (bi, bar) in self.bars.iter().enumerate() {
            if bar.i >= self.nodes.len() || bar.j >= self.nodes.len() {
                return Err(format!("Barra {}: indice de nudo fuera de rango.", bi + 1));
            }
            if bar.i == bar.j {
                return Err(format!("Barra {}: nudos inicial y final iguales.", bi + 1));
            }
        }
        Ok(())
    }
}


#[derive(Debug, Deserialize, Clone)]
pub struct Slab {
    #[serde(default)]
    pub pts: Vec<[f64; 2]>,
    #[serde(default)]
    pub z: f64,
    #[serde(default)]
    pub zs: Vec<f64>,
    #[serde(default)]
    pub t: f64,
    #[serde(default = "def_gw")]
    pub gw: f64,
    #[serde(rename = "E", default = "def_e")]
    pub e: f64,
    #[serde(default)]
    pub dia: Option<bool>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct AreaLoad {
    #[serde(default)]
    pub pts: Vec<[f64; 2]>,
    #[serde(default)]
    pub z: f64,
    #[serde(default)]
    pub zs: Vec<f64>,
    #[serde(default)]
    pub q: f64,
}

#[derive(Debug, Deserialize, Clone)]
pub struct Wall {
    #[serde(default)]
    pub n: Vec<usize>,
    #[serde(default)]
    pub t: f64,
    #[serde(default = "def_gw")]
    pub gw: f64,
    #[serde(default)]
    pub rig: f64,
    #[serde(rename = "E", default = "def_e")]
    pub e: f64,
    #[serde(default)]
    pub fix: f64,
}


impl Bar {
    pub fn rect(i: usize, j: usize, b: f64, h: f64, e: f64) -> Bar {
        Bar {
            i, j, ty: "rect".into(), b, h,
            bf: 0.0, hf: 0.0, bw: 0.0, dm: 0.0, d: 0.0,
            tf: 0.0, tw: 0.0, tt: 0.0, pts: vec![],
            e, ang: 0.0, div: 1, a1: 0.0, a2: 0.0, mat: "H".into(), auto_sw: false,
            wa: 0.0, wb: 0.0, xa: 0.0, xb: 0.0,
            ya: 0.0, yb: 0.0, pza: 0.0, pzb: 0.0,
            pya: 0.0, pyb: 0.0, kz: 0.0, ky: 0.0,
        }
    }
}


#[derive(Debug, Deserialize, Clone)]
#[allow(dead_code)]
pub struct Platea {
    #[serde(default)]
    pub pts: Vec<[f64; 2]>,
    #[serde(default)]
    pub z: f64,
    #[serde(rename = "H", default)]
    pub h: f64,
    #[serde(default)]
    pub ks: f64,
    #[serde(default)]
    pub qa: f64,
    #[serde(default)]
    pub fc: f64,
    #[serde(default)]
    pub fy: f64,
    #[serde(default)]
    pub s: f64,
}
