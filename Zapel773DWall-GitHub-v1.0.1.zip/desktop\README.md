# Escritorio

Envoltorio Electron de Zapel773DWall.

## Desarrollo

```powershell
pnpm install
pnpm run build:solver
pnpm start
```

`app.html` se copia desde `../src/Zapel773DWall.html` con el script de compilación.

## Empaquetado

```powershell
pnpm run package
```

Genera:

```text
dist/Zapel773DWall-win32-x64/
```

La carpeta es portátil y contiene `resources/zapel_solver.exe`.

## Puente Rust

- `main.js`: crea la ventana, ejecuta `resources/zapel_solver.exe` y devuelve JSON/HTML.
- `preload.js`: expone `window.ZAPEL_DESKTOP.solveRust(modelo, opciones)`.
- El límite de tiempo por corrida es 600 s.

No copies `node_modules`, `dist` ni el ejecutable dentro del repositorio; se regeneran.
