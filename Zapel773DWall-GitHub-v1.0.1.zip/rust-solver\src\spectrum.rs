use crate::modal::{self, Mode};
use crate::model::Model;
use crate::post::PostCtx;
use crate::sparse::Csr;
use crate::solver::DirectSolver;
use serde_json::json;

#[derive(Debug, Clone)]
pub struct EventSpectrum {
    pub t: Vec<f64>,
    pub sa: Vec<f64>,
    pub scale: f64,
}

impl EventSpectrum {
    pub fn new(t: Vec<f64>, sa: Vec<f64>, scale: f64) -> Self {
        let mut pairs: Vec<(f64, f64)> = t.into_iter().zip(sa).filter(|(a, b)| *a > 0.0 && b.is_finite()).collect();
        pairs.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
        EventSpectrum {
            t: pairs.iter().map(|q| q.0).collect(),
            sa: pairs.iter().map(|q| q.1.max(0.0)).collect(),
            scale: if scale > 0.0 { scale } else { 1.0 },
        }
    }
    pub fn sa(&self, t: f64) -> f64 {
        if !(t > 0.0) || self.t.is_empty() {
            return 0.0;
        }
        let n = self.t.len();
        if t <= self.t[0] {
            return self.sa[0] * self.scale;
        }
        if t >= self.t[n - 1] {
            return self.sa[n - 1] * self.scale * (self.t[n - 1] / t).powi(2);
        }
        for i in 1..n {
            if t <= self.t[i] {
                let t0 = self.t[i - 1];
                let t1 = self.t[i];
                let s0 = self.sa[i - 1].max(1e-9);
                let s1 = self.sa[i].max(1e-9);
                let f = (t / t0).ln() / (t1 / t0).ln();
                return (s0.ln() + f * (s1.ln() - s0.ln())).exp() * self.scale;
            }
        }
        0.0
    }
}

#[derive(Debug, Clone)]
pub struct Spectrum {
    pub sds: f64,
    pub sd1: f64,
    pub tl: f64,
    pub r: f64,
    pub ie: f64,
    pub damping: f64,
    pub event: Option<EventSpectrum>,
}

impl Spectrum {
    pub fn new(sds: f64, sd1: f64, tl: f64, r: f64, ie: f64) -> Self {
        Spectrum {
            sds: sds.max(1e-9),
            sd1: sd1.max(1e-9),
            tl: tl.max(0.1),
            r: r.max(1e-9),
            ie: ie.max(1e-9),
            damping: 0.05,
            event: None,
        }
    }
    pub fn event(t: Vec<f64>, sa: Vec<f64>, scale: f64, tl: f64) -> Self {
        Spectrum {
            sds: 1.0,
            sd1: 1.0,
            tl: tl.max(0.1),
            r: 1.0,
            ie: 1.0,
            damping: 0.05,
            event: Some(EventSpectrum::new(t, sa, scale)),
        }
    }
    pub fn t0(&self) -> f64 {
        0.2 * self.sd1 / self.sds
    }
    pub fn ts(&self) -> f64 {
        self.sd1 / self.sds
    }
    pub fn sa(&self, t: f64) -> f64 {
        if !(t > 0.0) {
            return 0.0;
        }
        if let Some(e) = &self.event {
            return e.sa(t);
        }
        let rr = (self.r / self.ie).max(1e-9);
        let t0 = self.t0();
        let ts = self.ts();
        if t <= t0 {
            self.sds * (0.4 + 0.6 * t / t0) / rr
        } else if t <= ts {
            self.sds / rr
        } else if t <= self.tl {
            self.sd1 / (t * rr)
        } else {
            self.sd1 * self.tl / (t * t * rr)
        }
    }
}

#[derive(Debug, Clone)]
pub struct ModeResponse {
    pub period: f64,
    pub sa: f64,
    pub gamma: f64,
    pub modal_shear: f64,
}

#[derive(Debug, Clone)]
pub struct DirectionResult {
    pub modes: Vec<ModeResponse>,
    pub u: Vec<f64>,
    pub reactions: Vec<f64>,
    pub base_shear: f64,
    pub dmax: f64,
    pub kesc: f64,
    pub meff: f64,
    pub drifts: Vec<serde_json::Value>,
}

pub struct SpectralResult {
    pub total_weight: f64,
    pub x: DirectionResult,
    pub y: DirectionResult,
}

pub fn rho_cqc(ta: f64, tb: f64, damping: f64) -> f64 {
    if !(ta > 0.0) || !(tb > 0.0) {
        return 0.0;
    }
    if (ta - tb).abs() < 1e-9 {
        return 1.0;
    }
    let r = ta / tb;
    let s = damping * damping;
    let num = 8.0 * s * (1.0 + r) * r.powf(1.5);
    let den = (1.0 - r * r).powi(2) + 4.0 * s * r * (1.0 + r).powi(2);
    if den.abs() < 1e-30 {
        0.0
    } else {
        num / den
    }
}

#[allow(clippy::too_many_arguments)]
pub fn spectral_analysis(
    k: &Csr,
    fixed: &[bool],
    model: &Model,
    coords: &[[f64; 3]],
    modes: &[Mode],
    mass_line: &[f64],
    sp: &Spectrum,
    base_load: &[f64],
    ecc_pct: f64,
    elf_v: f64,
    cd: f64,
    riesgo: usize,
    ctx: &PostCtx,
) -> Result<SpectralResult, String> {
    let n = k.n;
    let weights = modal::nodal_weights(model, coords, mass_line);
    let total_weight: f64 = weights.iter().sum();
    if !(total_weight > 1e-9) {
        return Err("No hay peso sísmico: define cargas verticales o pesos propios.".into());
    }
    let mut mass = vec![0.0f64; n];
    let mut dynamic = Vec::new();
    for i in 0..coords.len().min(model.nodes.len()) {
        let mi = weights[i] / 9.81;
        for kk in 0..3 {
            let d = 6 * i + kk;
            if d < n {
                mass[d] = mi;
                if !fixed[d] && mi > 0.0 {
                    dynamic.push(d);
                }
            }
        }
    }
    if dynamic.is_empty() {
        return Err("No hay grados de libertad dinámicos libres.".into());
    }
    if modes.is_empty() {
        return Err("No hay modos para la respuesta espectral.".into());
    }
    let direct = DirectSolver::new(k, fixed)?;
    let x = direction(&direct, k, model, coords, &weights, modes, &mass, &dynamic, sp, 0, base_load, ecc_pct, elf_v, cd, riesgo, ctx)?;
    let y = direction(&direct, k, model, coords, &weights, modes, &mass, &dynamic, sp, 1, base_load, ecc_pct, elf_v, cd, riesgo, ctx)?;
    Ok(SpectralResult { total_weight, x, y })
}

type Levels = Vec<(f64, Vec<usize>, f64, Vec<usize>)>;

fn levels_of(model: &Model, coords: &[[f64; 3]], weights: &[f64]) -> Levels {
    // (z, todos los nudos, peso del nivel, nudos con peso)
    let mut levels: Levels = Vec::new();
    for i in 0..coords.len().min(model.nodes.len()) {
        if weights.get(i).copied().unwrap_or(0.0) <= 1e-9 {
            continue;
        }
        let z = coords[i][2];
        if let Some(l) = levels.iter_mut().find(|l| (l.0 - z).abs() <= 1e-3) {
            l.2 += weights[i];
            l.3.push(i);
        } else {
            levels.push((z, Vec::new(), weights[i], vec![i]));
        }
    }
    levels.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    for l in levels.iter_mut() {
        l.1 = (0..coords.len().min(model.nodes.len()))
            .filter(|&i| (coords[i][2] - l.0).abs() < 1e-3)
            .collect();
    }
    levels
}

struct SignResult {
    u: Vec<f64>,
    r: Vec<f64>,
    mode_f: Vec<Vec<f64>>,
    shears: Vec<f64>,
    responses_u: Vec<Vec<f64>>,
}

#[allow(clippy::too_many_arguments)]
fn direction(
    direct: &DirectSolver,
    k: &Csr,
    model: &Model,
    coords: &[[f64; 3]],
    weights: &[f64],
    modes: &[Mode],
    mass: &[f64],
    dynamic: &[usize],
    sp: &Spectrum,
    dir: usize,
    base_load: &[f64],
    ecc_pct: f64,
    elf_v: f64,
    cd: f64,
    riesgo: usize,
    ctx: &PostCtx,
) -> Result<DirectionResult, String> {
    let n = k.n;
    let base_u = direct.solve(base_load)?;
    let mut base_ku = vec![0.0f64; n];
    k.matvec(&base_u, &mut base_ku);
    let mut base_r = vec![0.0f64; n];
    for d in 0..n {
        base_r[d] = base_ku[d] - base_load[d];
    }
    let levels = levels_of(model, coords, weights);
    let ext = {
        let (mut lo, mut hi) = (f64::INFINITY, f64::NEG_INFINITY);
        for nd in &model.nodes {
            let q = if dir == 0 { nd.y } else { nd.x };
            lo = lo.min(q);
            hi = hi.max(q);
        }
        (hi - lo).max(0.0)
    };
    let ecc = ecc_pct.max(5.0) / 100.0 * ext;
    let one = |sign: f64| -> Result<SignResult, String> {
        let mut responses_u: Vec<Vec<f64>> = Vec::with_capacity(modes.len());
        let mut responses_r: Vec<Vec<f64>> = Vec::with_capacity(modes.len());
        let mut shears: Vec<f64> = Vec::with_capacity(modes.len());
        let mut mode_f: Vec<Vec<f64>> = Vec::with_capacity(modes.len());
        for mode in modes {
            let mut gamma = 0.0;
            for &d in dynamic {
                if d % 6 == dir {
                    gamma += mass[d] * mode.shape[d];
                }
            }
            let sa = sp.sa(mode.period);
            let modal_shear = (gamma * gamma * sa * 9.81).abs();
            let mut f = vec![0.0f64; n];
            for &d in dynamic {
                f[d] = mass[d] * mode.shape[d] * gamma * sa * 9.81;
            }
            // Torsion accidental: igual que torsCorr de la app (incluye la
            // correccion en la direccion de la fuerza, no solo la perpendicular).
            if ecc > 0.0 {
                for (_, _all_nodes, wl, wnodes) in &levels {
                    if !(*wl > 0.0) {
                        continue;
                    }
                    let mut xm = 0.0;
                    let mut ym = 0.0;
                    let mut fq = 0.0;
                    for &i in wnodes {
                        xm += weights[i] * model.nodes[i].x;
                        ym += weights[i] * model.nodes[i].y;
                        fq += f[6 * i + dir];
                    }
                    xm /= wl;
                    ym /= wl;
                    let mut j = 0.0;
                    for &i in wnodes {
                        let q = &model.nodes[i];
                        j += weights[i] * ((q.x - xm).powi(2) + (q.y - ym).powi(2));
                    }
                    if j <= 1e-9 || fq.abs() <= 1e-12 {
                        continue;
                    }
                    let alpha = sign * fq * ecc / j;
                    for &i in wnodes {
                        let q = &model.nodes[i];
                        let rx = q.x - xm;
                        let ry = q.y - ym;
                        if dir == 0 {
                            f[6 * i] -= weights[i] * alpha * ry;
                            f[6 * i + 1] += weights[i] * alpha * rx;
                        } else {
                            f[6 * i + 1] -= weights[i] * alpha * rx;
                            f[6 * i] += weights[i] * alpha * ry;
                        }
                    }
                }
            }
            let sol_u = direct.solve(&f)?;
            let mut ku = vec![0.0f64; n];
            k.matvec(&sol_u, &mut ku);
            let mut r = vec![0.0f64; n];
            for d in 0..n {
                r[d] = ku[d] - f[d];
            }
            // La app incluye la deformada gravitatoria en cada respuesta modal;
            // se replica para que el CQC, el dmax y las derivas coincidan con
            // la app (el factor 85% del ELF se aplica despues a todo el vector).
            let mut uf = vec![0.0f64; n];
            let mut rf = vec![0.0f64; n];
            for d in 0..n {
                uf[d] = base_u[d] + sol_u[d];
                rf[d] = base_r[d] + r[d];
            }
            responses_u.push(uf);
            responses_r.push(rf);
            shears.push(modal_shear);
            mode_f.push(f);
        }
        let nm = modes.len();
        let mut u2 = vec![0.0f64; n];
        let mut r2 = vec![0.0f64; n];
        let vmax = shears.iter().cloned().fold(0.0f64, f64::max).max(1e-12);
        for i in 0..nm {
            for j in 0..nm {
                if shears[i] < 0.02 * vmax || shears[j] < 0.02 * vmax {
                    continue;
                }
                let a = rho_cqc(modes[i].period, modes[j].period, sp.damping);
                if a == 0.0 {
                    continue;
                }
                for d in 0..n {
                    u2[d] += a * responses_u[i][d] * responses_u[j][d];
                    r2[d] += a * responses_r[i][d] * responses_r[j][d];
                }
            }
        }
        let mut u = vec![0.0f64; n];
        let mut r = vec![0.0f64; n];
        for d in 0..n {
            u[d] = u2[d].max(0.0).sqrt();
            r[d] = r2[d].max(0.0).sqrt();
        }
        Ok(SignResult { u, r, mode_f, shears, responses_u })
    };
    let a_sign = one(1.0)?;
    let b_sign = if ecc > 0.0 { Some(one(-1.0)?) } else { None };
    let mut u = a_sign.u.clone();
    let mut r = a_sign.r.clone();
    if let Some(b) = &b_sign {
        for d in 0..n {
            if b.u[d].abs() > u[d].abs() { u[d] = b.u[d]; }
            if b.r[d].abs() > r[d].abs() { r[d] = b.r[d]; }
        }
    }
    // Escalado del cortante modal al 85% del ELF (ASCE 7-16 12.9.4.2).
    let shears = &a_sign.shears;
    let vmod = shears.iter().map(|v| v * v).sum::<f64>().sqrt();
    let mut kesc = 1.0f64;
    if sp.event.is_none() && elf_v > 0.0 && vmod > 1e-9 && vmod < 0.85 * elf_v {
        kesc = 0.85 * elf_v / vmod;
    }
    if (kesc - 1.0).abs() > 1e-12 {
        for d in 0..n { u[d] *= kesc; r[d] *= kesc; }
    }
    // dmax dinamico (CQC sin deformada gravitatoria) para diagnostico.
    // La app define dmax como la mayor componente escalada de u.
    // La app define dmax modal como la mayor componente de u (no la norma 3D).
    let mut dmax = 0.0f64;
    for v in &u {
        if v.abs() > dmax { dmax = v.abs(); }
    }
    let da_factor = match riesgo {
        1 | 2 => 0.02,
        3 => 0.015,
        _ => 0.01,
    };
    let drift_table = |sr: &SignResult, kesc: f64| -> Vec<(f64, f64, f64, f64, f64, f64)> {
        let mut out = Vec::new();
        let nm = modes.len();
        for i in 1..levels.len() {
            let hs = (levels[i].0 - levels[i - 1].0).max(1e-6);
            let vmax = sr.shears.iter().cloned().fold(0.0f64, f64::max).max(1e-12);
            let mut drm = vec![0.0f64; nm];
            for mi in 0..nm {
                // La app descarta los modos con cortante < 2% del maximo.
                if sr.shears[mi] < 0.02 * vmax { continue; }
                let a = avg(&sr.responses_u[mi], &levels[i].1, dir);
                let b = avg(&sr.responses_u[mi], &levels[i - 1].1, dir);
                drm[mi] = a - b;
            }
            let mut sdr = 0.0f64;
            for ai in 0..nm {
                for bi in 0..nm {
                    sdr += rho_cqc(modes[ai].period, modes[bi].period, sp.damping) * drm[ai] * drm[bi];
                }
            }
            let dr_raw = sdr.max(0.0).sqrt();
            let dr = dr_raw * kesc;
            let dd = cd / sp.ie.max(1e-9) * dr;
            let mut vm = vec![0.0f64; nm];
            for mi in 0..nm {
                if sr.shears[mi] < 0.02 * vmax { continue; }
                let mut s = 0.0;
                for &d in dynamic {
                    if d % 6 != dir { continue; }
                    let node = d / 6;
                    if coords[node][2] >= levels[i].0 - 1e-6 {
                        s += sr.mode_f[mi][d];
                    }
                }
                vm[mi] = s;
            }
            let mut v2 = 0.0f64;
            for ai in 0..nm {
                for bi in 0..nm {
                    v2 += rho_cqc(modes[ai].period, modes[bi].period, sp.damping) * vm[ai] * vm[bi];
                }
            }
            let vx = v2.max(0.0).sqrt() * kesc;
            let pab: f64 = levels[i..].iter().map(|l| l.2).sum();
            let theta = pab * dd / (vx.max(1e-9) * hs * cd.max(1e-9));
            out.push((levels[i].0, dr, dd, da_factor * hs, theta, vx));
        }
        out
    };
    let ta = drift_table(&a_sign, kesc);
    let tb = b_sign.as_ref().map(|b| drift_table(b, kesc));
    let mut drifts = Vec::with_capacity(ta.len());
    for (i, q) in ta.iter().enumerate() {
        let mut row = *q;
        if let Some(tb) = &tb {
            if let Some(r2) = tb.get(i) {
                if r2.1 > row.1 { row.1 = r2.1; }
                if r2.2 > row.2 { row.2 = r2.2; }
                if r2.4 > row.4 { row.4 = r2.4; }
                if r2.5 > row.5 { row.5 = r2.5; }
            }
        }
        drifts.push(json!({"z": row.0, "dr": row.1, "dd": row.2, "da": row.3,
            "theta": row.4, "V": row.5, "ok": row.2 <= row.3 + 0.0005, "ok2": row.4 <= 0.1}));
    }
    // Masa efectiva como la app: denominador sobre GDL dinamicos y solo
    // modos activos (cortante >= 2% del maximo).
    let mt_dir: f64 = dynamic.iter().filter(|d| *d % 6 == dir).map(|d| mass[*d]).sum();
    let vmax2 = shears.iter().cloned().fold(0.0f64, f64::max).max(1e-12);
    let mut gsum = 0.0f64;
    for (mi, m) in modes.iter().enumerate() {
        if shears[mi] < 0.02 * vmax2 { continue; }
        let g: f64 = m.shape.iter().enumerate().filter(|(i, _)| i % 6 == dir)
            .map(|(i, v)| mass[i] * v).sum();
        gsum += g * g;
    }
    let meff = if mt_dir > 1e-12 { gsum / mt_dir } else { 0.0 };
    let modes_out = modes.iter().map(|m| {
        let gamma: f64 = m.shape.iter().enumerate().filter(|(i, _)| i % 6 == dir)
            .map(|(i, v)| mass[i] * v).sum();
        let sa = sp.sa(m.period);
        ModeResponse { period: m.period, sa, gamma, modal_shear: (gamma * gamma * sa * 9.81).abs() }
    }).collect();
    Ok(DirectionResult { modes: modes_out, u, reactions: r, base_shear: vmod * kesc, dmax, kesc, meff, drifts })
}

fn avg(u: &[f64], nodes: &[usize], dir: usize) -> f64 {
    let mut s = 0.0;
    let mut c = 0;
    for &i in nodes {
        s += u[6 * i + dir];
        c += 1;
    }
    if c > 0 { s / c as f64 } else { 0.0 }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn spectrum_is_positive_and_continuous_at_ts() {
        let sp = Spectrum::new(0.7333333, 0.4266667, 8.0, 8.0, 1.0);
        let ts = sp.ts();
        let a = sp.sa(ts - 1e-9);
        let b = sp.sa(ts + 1e-9);
        assert!(a > 0.0 && b > 0.0);
        assert!((a - b).abs() < 1e-5);
        assert!((sp.sa(ts) - sp.sds / sp.r).abs() < 1e-9);
    }

    #[test]
    fn cqc_diagonal_is_one() {
        assert!((rho_cqc(0.5, 0.5, 0.05) - 1.0).abs() < 1e-12);
    }
}
