use crate::model::Model;

pub fn poly_area(p: &[[f64; 2]]) -> f64 {
    let mut a = 0.0;
    for i in 0..p.len() {
        let q = p[i];
        let r = p[(i + 1) % p.len()];
        a += q[0] * r[1] - r[0] * q[1];
    }
    a.abs() / 2.0
}

fn point_in_poly(p: &[[f64; 2]], x: f64, y: f64) -> bool {
    let mut c = false;
    let n = p.len();
    for i in 0..n {
        let a = p[i];
        let b = p[(i + 1) % n];
        if ((a[1] > y) != (b[1] > y))
            && x < (b[0] - a[0]) * (y - a[1]) / ((b[1] - a[1]) + 1e-30) + a[0]
        {
            c = !c;
        }
    }
    c
}

fn dist_seg(x: f64, y: f64, ax: f64, ay: f64, bx: f64, by: f64) -> f64 {
    let dx = bx - ax;
    let dy = by - ay;
    let l2 = dx * dx + dy * dy;
    let mut t = if l2 > 0.0 {
        ((x - ax) * dx + (y - ay) * dy) / l2
    } else {
        0.0
    };
    t = t.max(0.0).min(1.0);
    ((x - ax - t * dx).powi(2) + (y - ay - t * dy).powi(2)).sqrt()
}

fn beams_at_level(bars: &[crate::model::Bar], coords: &[[f64; 3]], z: f64) -> Vec<usize> {
    let mut out = Vec::new();
    for (i, b) in bars.iter().enumerate() {
        if b.i >= coords.len() || b.j >= coords.len() {
            continue;
        }
        if (coords[b.i][2] - z).abs() < 1e-6 && (coords[b.j][2] - z).abs() < 1e-6 {
            out.push(i);
        }
    }
    out
}

/// Reparte una presion q sobre el poligono P entre las vigas del mismo nivel.
fn distribute_area(
    bars: &[crate::model::Bar],
    coords: &[[f64; 3]],
    z: f64,
    pts: &[[f64; 2]],
    q: f64,
    add: &mut [f64],
) -> f64 {
    if pts.len() < 3 || !(q > 0.0) {
        return 0.0;
    }
    let a = poly_area(pts);
    if !(a > 1e-9) {
        return 0.0;
    }
    let bs = beams_at_level(bars, coords, z);
    if bs.is_empty() {
        return 0.0;
    }
    let mut x0 = f64::INFINITY;
    let mut y0 = f64::INFINITY;
    let mut x1 = f64::NEG_INFINITY;
    let mut y1 = f64::NEG_INFINITY;
    for p in pts {
        x0 = x0.min(p[0]);
        y0 = y0.min(p[1]);
        x1 = x1.max(p[0]);
        y1 = y1.max(p[1]);
    }
    let step = (a / 40000.0).sqrt().max(0.02);
    let mut acc = vec![0.0f64; bs.len()];
    let mut y = y0 + step / 2.0;
    while y < y1 {
        let mut x = x0 + step / 2.0;
        while x < x1 {
            if point_in_poly(pts, x, y) {
                let mut best = f64::INFINITY;
                let mut bi = None;
                for (t, &b) in bs.iter().enumerate() {
                    let bar = &bars[b];
                    let d = dist_seg(
                        x,
                        y,
                        coords[bar.i][0],
                        coords[bar.i][1],
                        coords[bar.j][0],
                        coords[bar.j][1],
                    );
                    if d < best {
                        best = d;
                        bi = Some(t);
                    }
                }
                if let Some(t) = bi {
                    acc[t] += step * step;
                }
            }
            x += step;
        }
        y += step;
    }
    let tot: f64 = acc.iter().sum();
    if !(tot > 0.0) {
        return 0.0;
    }
    let esc = a / tot;
    for (t, &b) in bs.iter().enumerate() {
        if acc[t] <= 0.0 {
            continue;
        }
        let bar = &bars[b];
        let l = ((coords[bar.j][0] - coords[bar.i][0]).powi(2)
            + (coords[bar.j][1] - coords[bar.i][1]).powi(2)
            + (coords[bar.j][2] - coords[bar.i][2]).powi(2))
        .sqrt();
        if l > 1e-9 {
            add[b] += q * acc[t] * esc / l;
        }
    }
    a
}

/// Reparte una carga lineal q a lo largo de A-B entre las vigas del nivel.
fn distribute_line(
    bars: &[crate::model::Bar],
    coords: &[[f64; 3]],
    z: f64,
    a: [f64; 2],
    b: [f64; 2],
    q: f64,
    add: &mut [f64],
) -> f64 {
    if !(q > 0.0) {
        return 0.0;
    }
    let bs = beams_at_level(bars, coords, z);
    if bs.is_empty() {
        return 0.0;
    }
    let l = ((b[0] - a[0]).powi(2) + (b[1] - a[1]).powi(2)).sqrt();
    if !(l > 1e-9) {
        return 0.0;
    }
    let m = ((l / 0.05).ceil() as usize).max(2);
    let ds = l / m as f64;
    let mut acc = vec![0.0f64; bs.len()];
    for k in 0..m {
        let t = (k as f64 + 0.5) / m as f64;
        let x = a[0] + (b[0] - a[0]) * t;
        let y = a[1] + (b[1] - a[1]) * t;
        let mut best = f64::INFINITY;
        let mut bi = None;
        for (tt, &bb) in bs.iter().enumerate() {
            let bar = &bars[bb];
            let d = dist_seg(
                x,
                y,
                coords[bar.i][0],
                coords[bar.i][1],
                coords[bar.j][0],
                coords[bar.j][1],
            );
            if d < best {
                best = d;
                bi = Some(tt);
            }
        }
        if let Some(tt) = bi {
            acc[tt] += q * ds;
        }
    }
    for (tt, &bb) in bs.iter().enumerate() {
        if acc[tt] <= 0.0 {
            continue;
        }
        let bar = &bars[bb];
        let lb = ((coords[bar.j][0] - coords[bar.i][0]).powi(2)
            + (coords[bar.j][1] - coords[bar.i][1]).powi(2)
            + (coords[bar.j][2] - coords[bar.i][2]).powi(2))
        .sqrt();
        if lb > 1e-9 {
            add[bb] += acc[tt] / lb;
        }
    }
    l
}

fn det3(m: [[f64; 3]; 3]) -> f64 {
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
}

/// Cota z por vertice, igual que `slabZs()` de la app: usa zs[k] si es finito y
/// en caso contrario la cota z de la superficie.
fn zs_of_verts(zs: &[f64], n: usize, z: f64) -> Vec<f64> {
    let fallback = if z.is_finite() { z } else { 0.0 };
    (0..n)
        .map(|k| {
            zs.get(k)
                .copied()
                .filter(|v| v.is_finite())
                .unwrap_or(fallback)
        })
        .collect()
}

/// Ajuste z = a + b*x + c*y por minimos cuadrados, igual que `fitPlaneZ()`
/// de la app (Zapel773DWall-index.html:448-454).
fn fit_plane(pts: &[[f64; 2]], z: &[f64]) -> (f64, f64, f64) {
    let n = pts.len();
    let mut sx = 0.0;
    let mut sy = 0.0;
    let mut sz = 0.0;
    let mut sxx = 0.0;
    let mut sxy = 0.0;
    let mut syy = 0.0;
    let mut sxz = 0.0;
    let mut syz = 0.0;
    for k in 0..n {
        let x = pts[k][0];
        let y = pts[k][1];
        let zz = z[k];
        sx += x;
        sy += y;
        sz += zz;
        sxx += x * x;
        sxy += x * y;
        syy += y * y;
        sxz += x * zz;
        syz += y * zz;
    }
    if n < 3 {
        return (if n > 0 { sz / n as f64 } else { 0.0 }, 0.0, 0.0);
    }
    let m = [[n as f64, sx, sy], [sx, sxx, sxy], [sy, sxy, syy]];
    let rhs = [sz, sxz, syz];
    let d = det3(m);
    if !(d.abs() > 1e-12) {
        return (sz / n as f64, 0.0, 0.0);
    }
    let col = |j: usize| -> f64 {
        let mut mm = m;
        for i in 0..3 {
            mm[i][j] = rhs[i];
        }
        det3(mm) / d
    };
    (col(0), col(1), col(2))
}

/// Distancia punto-segmento en 3D, igual que `dSeg3()` de la app
/// (Zapel773DWall-index.html:463-465).
fn dist_seg3(x: f64, y: f64, z: f64, a: &[f64; 3], b: &[f64; 3]) -> f64 {
    let dx = b[0] - a[0];
    let dy = b[1] - a[1];
    let dz = b[2] - a[2];
    let l2 = dx * dx + dy * dy + dz * dz;
    let mut t = if l2 > 0.0 {
        ((x - a[0]) * dx + (y - a[1]) * dy + (z - a[2]) * dz) / l2
    } else {
        0.0
    };
    t = t.max(0.0).min(1.0);
    ((x - a[0] - t * dx).powi(2) + (y - a[1] - t * dy).powi(2) + (z - a[2] - t * dz).powi(2))
        .sqrt()
}

/// Reparte una presion q sobre una superficie cuyo plano es z = a + b*x + c*y
/// (losa o carga de area inclinada), replicando `reparteLosa()` de la app
/// (Zapel773DWall-index.html:469-490):
///  - candidatas: barras con sus dos extremos en el plano de la superficie,
///    con tolerancia max(0.06, 0.02*diagonal_en_planta);
///  - muestreo en planta con paso max(0.02, sqrt(A_planta/40000)), asignando
///    cada punto a la barra candidata mas cercana EN 3D;
///  - la carga repartida se multiplica por sqrt(1+b^2+c^2) (area real).
/// Devuelve el area real de la superficie (>0) o -1/0 si no se pudo repartir.
fn distribute_tilted(
    bars: &[crate::model::Bar],
    coords: &[[f64; 3]],
    pts: &[[f64; 2]],
    q: f64,
    pa: f64,
    pb: f64,
    pc: f64,
    add: &mut [f64],
) -> f64 {
    if pts.len() < 3 || !(q > 0.0) {
        return 0.0;
    }
    let a2 = poly_area(pts);
    if !(a2 > 1e-9) {
        return 0.0;
    }
    let sec = (1.0 + pb * pb + pc * pc).sqrt();
    let mut x0 = f64::INFINITY;
    let mut y0 = f64::INFINITY;
    let mut x1 = f64::NEG_INFINITY;
    let mut y1 = f64::NEG_INFINITY;
    for p in pts {
        x0 = x0.min(p[0]);
        y0 = y0.min(p[1]);
        x1 = x1.max(p[0]);
        y1 = y1.max(p[1]);
    }
    let tol = (0.02 * ((x1 - x0).powi(2) + (y1 - y0).powi(2)).sqrt()).max(0.06);
    let mut cand: Vec<usize> = Vec::new();
    for (k, b) in bars.iter().enumerate() {
        if b.i >= coords.len() || b.j >= coords.len() {
            continue;
        }
        let a = coords[b.i];
        let c = coords[b.j];
        if (pa + pb * a[0] + pc * a[1] - a[2]).abs() < tol
            && (pa + pb * c[0] + pc * c[1] - c[2]).abs() < tol
        {
            cand.push(k);
        }
    }
    if cand.is_empty() {
        return -1.0;
    }
    let step = (a2 / 40000.0).sqrt().max(0.02);
    let mut acc = vec![0.0f64; cand.len()];
    let mut y = y0 + step / 2.0;
    while y < y1 {
        let mut x = x0 + step / 2.0;
        while x < x1 {
            if point_in_poly(pts, x, y) {
                let z = pa + pb * x + pc * y;
                let mut best = f64::INFINITY;
                let mut bi: Option<usize> = None;
                for (t, &bk) in cand.iter().enumerate() {
                    let bar = &bars[bk];
                    let d = dist_seg3(x, y, z, &coords[bar.i], &coords[bar.j]);
                    if d < best {
                        best = d;
                        bi = Some(t);
                    }
                }
                if let Some(t) = bi {
                    acc[t] += step * step;
                }
            }
            x += step;
        }
        y += step;
    }
    let tot: f64 = acc.iter().sum();
    if !(tot > 0.0) {
        return -1.0;
    }
    let esc = a2 / tot;
    for (t, &bk) in cand.iter().enumerate() {
        if !(acc[t] > 0.0) {
            continue;
        }
        let bar = &bars[bk];
        let l = ((coords[bar.j][0] - coords[bar.i][0]).powi(2)
            + (coords[bar.j][1] - coords[bar.i][1]).powi(2)
            + (coords[bar.j][2] - coords[bar.i][2]).powi(2))
        .sqrt();
        if l > 1e-9 {
            add[bk] += q * sec * acc[t] * esc / l;
        }
    }
    a2 * sec
}

#[derive(Debug, Clone)]
pub struct AddedLoads {
    /// Carga total para el analisis estatico.
    pub total: Vec<f64>,
    /// Peso propio de losas.
    pub surface: Vec<f64>,
    /// Cargas de area (sin peso propio de losa).
    pub area: Vec<f64>,
    /// Peso de muros sin rigidez.
    pub wall: Vec<f64>,
}

/// Carga lineal adicional [kN/m] sobre cada barra por losas, cargas de area y
/// muros sin rigidez. Devuelve tambien avisos de elementos no soportados.
pub fn added_line_loads(model: &Model, coords: &[[f64; 3]]) -> (AddedLoads, Vec<String>) {
    let mut surface = vec![0.0f64; model.bars.len()];
    let mut area = vec![0.0f64; model.bars.len()];
    let mut wall_line = vec![0.0f64; model.bars.len()];
    let mut warnings = Vec::new();
    for (i, s) in model.slabs.iter().enumerate() {
        if s.pts.len() < 3 {
            continue;
        }
        let q = s.gw * s.t;
        if !(q > 0.0) {
            continue;
        }
        let zs = zs_of_verts(&s.zs, s.pts.len(), s.z);
        let (pa, pb, pc) = fit_plane(&s.pts, &zs);
        let a = if pb.abs() < 1e-9 && pc.abs() < 1e-9 {
            distribute_area(&model.bars, coords, zs[0], &s.pts, q, &mut surface)
        } else {
            distribute_tilted(&model.bars, coords, &s.pts, q, pa, pb, pc, &mut surface)
        };
        if a <= 0.0 {
            if pb.abs() < 1e-9 && pc.abs() < 1e-9 {
                warnings.push(format!(
                    "Losa {}: no hay vigas en su nivel que reciban el peso propio.",
                    i + 1
                ));
            } else {
                warnings.push(format!(
                    "Losa {}: no hay vigas en su plano inclinado que reciban el peso propio (revisa las vigas de borde siguiendo la pendiente).",
                    i + 1
                ));
            }
        }
    }
    for (i, c) in model.area_loads.iter().enumerate() {
        if c.pts.len() < 3 || !(c.q > 0.0) {
            continue;
        }
        let zs = zs_of_verts(&c.zs, c.pts.len(), c.z);
        let (pa, pb, pc) = fit_plane(&c.pts, &zs);
        let a = if pb.abs() < 1e-9 && pc.abs() < 1e-9 {
            distribute_area(&model.bars, coords, zs[0], &c.pts, c.q, &mut area)
        } else {
            distribute_tilted(&model.bars, coords, &c.pts, c.q, pa, pb, pc, &mut area)
        };
        if a <= 0.0 {
            if pb.abs() < 1e-9 && pc.abs() < 1e-9 {
                warnings.push(format!(
                    "Carga de area {}: no hay vigas en su nivel que la reciban.",
                    i + 1
                ));
            } else {
                warnings.push(format!(
                    "Carga de area {}: no hay vigas en su plano inclinado que la reciban.",
                    i + 1
                ));
            }
        }
    }
    for (_i, w) in model.walls.iter().enumerate() {
        if w.rig != 0.0 {
            // Los muros rigidos se agregan como elementos equivalentes en walls.rs.
            continue;
        }
        if w.n.len() < 2 || w.n[0] >= coords.len() || w.n[1] >= coords.len() {
            continue;
        }
        let p0 = coords[w.n[0]];
        let p1 = coords[w.n[1]];
        let h = if w.n.len() >= 4 && w.n[2] < coords.len() && w.n[3] < coords.len() {
            let h0 = ((coords[w.n[3]][0] - p0[0]).powi(2)
                + (coords[w.n[3]][1] - p0[1]).powi(2)
                + (coords[w.n[3]][2] - p0[2]).powi(2))
            .sqrt();
            let h1 = ((coords[w.n[2]][0] - p1[0]).powi(2)
                + (coords[w.n[2]][1] - p1[1]).powi(2)
                + (coords[w.n[2]][2] - p1[2]).powi(2))
            .sqrt();
            (h0 + h1) / 2.0
        } else {
            0.0
        };
        let q = (w.gw.max(0.0) * w.t.max(0.0) * h).max(0.0);
        if q > 0.0 {
            let z = (p0[2] + p1[2]) / 2.0;
            distribute_line(
                &model.bars,
                coords,
                z,
                [p0[0], p0[1]],
                [p1[0], p1[1]],
                q,
                &mut wall_line,
            );
        }
    }
    let total = (0..model.bars.len())
        .map(|i| surface[i] + area[i] + wall_line[i])
        .collect();
    (AddedLoads { total, surface, area, wall: wall_line }, warnings)
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rectangle_area() {
        let p = [[0.0, 0.0], [4.0, 0.0], [4.0, 3.0], [0.0, 3.0]];
        assert!((poly_area(&p) - 12.0).abs() < 1e-12);
    }

    #[test]
    fn fit_plane_sobre_plano_inclinado() {
        // z = 0.3*y  (plano de una rampa)
        let p = [[0.0, 0.0], [4.0, 0.0], [4.0, 3.0], [0.0, 3.0]];
        let z = [0.0, 0.0, 0.9, 0.9];
        let (a, b, c) = fit_plane(&p, &z);
        assert!(a.abs() < 1e-12);
        assert!(b.abs() < 1e-12);
        assert!((c - 0.3).abs() < 1e-12);
    }

    #[test]
    fn reparto_inclinado_conserva_la_carga_total() {
        // Losa inclinada 4x3 m con z = 0.3*y y cuatro vigas de borde en su plano.
        let pts = [[0.0, 0.0], [4.0, 0.0], [4.0, 3.0], [0.0, 3.0]];
        let z = [0.0, 0.0, 0.9, 0.9];
        let coords = [
            [0.0, 0.0, 0.0],
            [4.0, 0.0, 0.0],
            [4.0, 3.0, 0.9],
            [0.0, 3.0, 0.9],
        ];
        let bars = vec![
            crate::model::Bar::rect(0, 1, 0.3, 0.5, 25.0),
            crate::model::Bar::rect(1, 2, 0.3, 0.5, 25.0),
            crate::model::Bar::rect(2, 3, 0.3, 0.5, 25.0),
            crate::model::Bar::rect(3, 0, 0.3, 0.5, 25.0),
        ];
        let q = 2.0; // kN/m2
        let (a, b, c) = fit_plane(&pts, &z);
        let mut add = vec![0.0f64; bars.len()];
        let area = distribute_tilted(&bars, &coords, &pts, q, a, b, c, &mut add);
        let sec = (1.0 + b * b + c * c).sqrt();
        assert!((area - 12.0 * sec).abs() < 1e-9);
        // carga total repartida = suma(add[bi]*L_bi) = q * area_real
        let mut total = 0.0;
        for (i, bar) in bars.iter().enumerate() {
            let l = ((coords[bar.j][0] - coords[bar.i][0]).powi(2)
                + (coords[bar.j][1] - coords[bar.i][1]).powi(2)
                + (coords[bar.j][2] - coords[bar.i][2]).powi(2))
            .sqrt();
            total += add[i] * l;
        }
        assert!((total - q * area).abs() < 1e-6);
    }
}
