//! Postproceso de barras y muros: desplazamientos en estaciones, fuerzas internas,
//! deformada maxima y tensiones de muro. Replica exactamente la formulacion del
//! nucleo de la app (funcion analyze de Zapel773DWall-index.html).

use crate::frame::{self, Axes, Element};
use crate::model::Bar;

/// Componentes locales de la carga distribuida de un elemento, en los extremos
/// de su tramo (igual que `qxa..qzb` de la app).
#[derive(Debug, Clone, Copy, Default)]
pub struct ElemLoad {
    pub qxa: f64,
    pub qxb: f64,
    pub qya: f64,
    pub qyb: f64,
    pub qza: f64,
    pub qzb: f64,
    /// Carga nodal equivalente local sin condensar (fo de la app).
    pub fo: [f64; 12],
}

impl ElemLoad {
    pub fn new(bar: &Bar, ax: &Axes, t0: f64, t1: f64) -> ElemLoad {
        let w0 = interp(bar.wa, bar.wb, t0);
        let w1 = interp(bar.wa, bar.wb, t1);
        let fa = [
            interp(bar.xa, bar.xb, t0),
            interp(bar.ya, bar.yb, t0),
            -w0,
        ];
        let fb = [
            interp(bar.xa, bar.xb, t1),
            interp(bar.ya, bar.yb, t1),
            -w1,
        ];
        let qxa = dot(fa, ax.ex);
        let qxb = dot(fb, ax.ex);
        let qya = dot(fa, ax.ey) + interp(bar.pya, bar.pyb, t0);
        let qyb = dot(fb, ax.ey) + interp(bar.pya, bar.pyb, t1);
        let qza = dot(fa, ax.ez) - interp(bar.pza, bar.pzb, t0);
        let qzb = dot(fb, ax.ez) - interp(bar.pza, bar.pzb, t1);
        ElemLoad {
            qxa,
            qxb,
            qya,
            qyb,
            qza,
            qzb,
            fo: frame::equivalent_load(bar, *ax, t0, t1),
        }
    }
}

fn interp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

#[derive(Debug, Clone, Copy)]
pub struct Station {
    pub p: [f64; 3],
    pub d: [f64; 3],
    pub n: f64,
    pub vy: f64,
    pub vz: f64,
    pub t: f64,
    pub my: f64,
    pub mz: f64,
    pub sy: f64,
    pub sz: f64,
}

pub struct PostCtx<'a> {
    pub coords: &'a [[f64; 3]],
    pub elements: &'a [Element],
    pub loads: &'a [ElemLoad],
}

impl<'a> PostCtx<'a> {
    /// Estaciones de un elemento (13 por tramo, como la app).
    pub fn stations(&self, ei: usize, u: &[f64]) -> Vec<Station> {
        let el = &self.elements[ei];
        let q = &self.loads[ei];
        let l = el.length;
        if !(l > 1e-12) {
            return Vec::new();
        }
        let mut ko = frame::local_stiffness(el.e, el.section, l);
        frame::add_geometric_springs(&mut ko, l, el.kz_spring, el.ky_spring);
        let mut kc = ko;
        let mut fc = q.fo;
        frame::cond(
            &mut kc,
            &mut fc,
            &frame::release_dofs(el.release_start, el.release_end),
        );
        let t = frame::transform(&el.axes);
        let dofs = frame::dofs(el);
        let mut ue = [0.0f64; 12];
        for (k, &d) in dofs.iter().enumerate() {
            ue[k] = u[d];
        }
        let mut ul = [0.0f64; 12];
        for i in 0..12 {
            let mut s = 0.0;
            for j in 0..12 {
                s += t[i][j] * ue[j];
            }
            ul[i] = s;
        }
        // Recuperacion de GDL liberados (articulaciones) con la rigidez sin
        // condensar, igual que la app.
        let rel = frame::release_dofs(el.release_start, el.release_end);
        if !rel.is_empty() {
            self.recover_released(&ko, &q.fo, &rel, &mut ul);
        }
        let mut fl = [0.0f64; 12];
        for i in 0..12 {
            let mut s = 0.0;
            for j in 0..12 {
                s += kc[i][j] * ul[j];
            }
            fl[i] = s - fc[i];
        }
        let a = self.coords[el.i];
        let mut out = Vec::with_capacity(13);
        let mut integ = [0.0f64; 4];
        let mut pw = [0.0f64; 2];
        let mut ps = [0.0f64; 2];
        let hstep = l / 12.0;
        for m in 0..=12 {
            let x = m as f64 / 12.0;
            let s = l * x;
            let nn = frame::hm(x, l);
            let v = nn[0] * ul[1] + nn[1] * ul[5] + nn[2] * ul[7] + nn[3] * ul[11];
            let w = nn[0] * ul[2] - nn[1] * ul[4] + nn[2] * ul[8] - nn[3] * ul[10];
            let uu = ul[0] * (1.0 - x) + ul[6] * x;
            let mut d = [
                el.axes.ex[0] * uu + el.axes.ey[0] * v + el.axes.ez[0] * w,
                el.axes.ex[1] * uu + el.axes.ey[1] * v + el.axes.ez[1] * w,
                el.axes.ex[2] * uu + el.axes.ey[2] * v + el.axes.ez[2] * w,
            ];
            if m == 0 {
                d = [u[6 * el.i], u[6 * el.i + 1], u[6 * el.i + 2]];
            } else if m == 12 {
                d = [u[6 * el.j], u[6 * el.j + 1], u[6 * el.j + 2]];
            }
            let sy = -el.ky_spring * v;
            let sz = -el.kz_spring * w;
            let wy = q.qya + (q.qyb - q.qya) * x + sy;
            let wz = q.qza + (q.qzb - q.qza) * x + sz;
            if m > 0 {
                let a1 = integ[0] + (pw[0] + wy) / 2.0 * hstep;
                let b1 = integ[2] + (pw[1] + wz) / 2.0 * hstep;
                integ[1] += (integ[0] + a1) / 2.0 * hstep;
                integ[3] += (integ[2] + b1) / 2.0 * hstep;
                integ[0] = a1;
                integ[2] = b1;
                let _ = ps;
            }
            pw = [wy, wz];
            ps = [sy, sz];
            let rec = Station {
                p: [
                    a[0] + el.axes.ex[0] * s,
                    a[1] + el.axes.ex[1] * s,
                    a[2] + el.axes.ex[2] * s,
                ],
                d,
                n: -(fl[0] + q.qxa * s + (q.qxb - q.qxa) * s * s / (2.0 * l)),
                vy: fl[1] + integ[0],
                vz: fl[2] + integ[2],
                t: -fl[3],
                my: fl[4] + fl[2] * s + integ[3],
                mz: -fl[5] + fl[1] * s + integ[1],
                sy,
                sz,
            };
            out.push(rec);
        }
        out
    }

    fn recover_released(
        &self,
        ko: &[[f64; 12]; 12],
        fo: &[f64; 12],
        rel: &[usize],
        ul: &mut [f64; 12],
    ) {
        let n = rel.len();
        if n == 0 || n > 4 {
            return;
        }
        let mut a = [[0.0f64; 4]; 4];
        let mut b = [0.0f64; 4];
        let idx: Vec<usize> = (0..12).filter(|k| !rel.contains(k)).collect();
        for (i, &p) in rel.iter().enumerate() {
            for (j, &q) in rel.iter().enumerate() {
                a[i][j] = ko[p][q];
            }
            let mut rhs = fo[p];
            for &k in &idx {
                rhs -= ko[p][k] * ul[k];
            }
            b[i] = rhs;
        }
        // Eliminacion gaussiana con pivoteo parcial.
        for col in 0..n {
            let mut piv = col;
            for r in (col + 1)..n {
                if a[r][col].abs() > a[piv][col].abs() {
                    piv = r;
                }
            }
            if a[piv][col].abs() < 1e-14 {
                return;
            }
            a.swap(col, piv);
            b.swap(col, piv);
            for r in (col + 1)..n {
                let f = a[r][col] / a[col][col];
                for c in col..n {
                    a[r][c] -= f * a[col][c];
                }
                b[r] -= f * b[col];
            }
        }
        let mut x = [0.0f64; 4];
        for i in (0..n).rev() {
            let mut s = b[i];
            for j in (i + 1)..n {
                s -= a[i][j] * x[j];
            }
            x[i] = s / a[i][i];
        }
        for (i, &p) in rel.iter().enumerate() {
            ul[p] = x[i];
        }
    }

    /// Deformada maxima sobre todas las estaciones (definicion de la app).
    pub fn dmax(&self, u: &[f64]) -> f64 {
        let mut dm = 1e-12f64;
        for ei in 0..self.elements.len() {
            let el = &self.elements[ei];
            if el.bar_index == usize::MAX && el.wall_index == usize::MAX {
                continue; // brazos rigidos de muro: la app los omite
            }
            for st in self.stations(ei, u) {
                let d = (st.d[0] * st.d[0] + st.d[1] * st.d[1] + st.d[2] * st.d[2]).sqrt();
                if d > dm {
                    dm = d;
                }
            }
        }
        dm
    }
}
