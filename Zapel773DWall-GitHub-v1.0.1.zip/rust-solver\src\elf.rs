use crate::modal;
use crate::model::Model;
use crate::post::PostCtx;
use crate::solver::DirectSolver;
use crate::sparse::Csr;
use serde_json::json;

#[derive(Debug, Clone)]
pub struct Settings {
    pub sds: f64,
    pub sd1: f64,
    pub tl: f64,
    pub r: f64,
    pub ie: f64,
    pub ct: f64,
    pub x: f64,
    pub ecc: f64,
    pub cd: f64,
    pub riesgo: usize,
}

#[derive(Debug, Clone)]
struct Level {
    z: f64,
    weight: f64,
    /// Todos los nudos de la cota (para promediar desplazamientos), como la app.
    nodes: Vec<usize>,
    /// Nudos con peso (para repartir fuerzas).
    wnodes: Vec<usize>,
}

pub fn analyze(
    model: &Model,
    coords: &[[f64; 3]],
    k: &Csr,
    fixed: &[bool],
    base_f: &[f64],
    mass_line: &[f64],
    s: &Settings,
    ctx: &PostCtx,
) -> Result<serde_json::Value, String> {
    let weights = modal::nodal_weights(model, coords, mass_line);
    let total: f64 = weights.iter().sum();
    if !(total > 1e-9) {
        return Err("No hay peso sismico: define cargas verticales o pesos propios.".into());
    }
    // Niveles con la misma tolerancia que la app (1e-3 m).
    let mut levels: Vec<Level> = Vec::new();
    for (i, w) in weights.iter().enumerate() {
        if i >= model.nodes.len() {
            continue;
        }
        let z = coords[i][2];
        if *w > 1e-9 {
            if let Some(l) = levels.iter_mut().find(|l| (l.z - z).abs() <= 1e-3) {
                l.weight += *w;
                l.wnodes.push(i);
            } else {
                levels.push(Level { z, weight: *w, nodes: Vec::new(), wnodes: vec![i] });
            }
        }
    }
    levels.sort_by(|a, b| a.z.partial_cmp(&b.z).unwrap());
    if levels.len() < 2 {
        return Err("No hay niveles con peso para ELF.".into());
    }
    for l in levels.iter_mut() {
        l.nodes = (0..model.nodes.len())
            .filter(|&i| (coords[i][2] - l.z).abs() < 1e-3)
            .collect();
    }
    let z0 = levels[0].z;
    let hn = levels[levels.len() - 1].z - z0;
    let w_total: f64 = levels.iter().map(|l| l.weight).sum();
    let ct = if s.ct > 0.0 { s.ct } else { 0.0466 };
    let xx = if s.x > 0.0 { s.x } else { 0.9 };
    let ta = ct * hn.powf(xx);
    let sd1 = s.sd1.max(1e-9);
    let cu = interp(&[0.1, 0.15, 0.2, 0.3, 0.4], &[1.7, 1.6, 1.5, 1.4, 1.4], sd1);
    let pat = |expo: f64| -> Vec<f64> {
        levels.iter().map(|l| l.weight * (l.z - z0).max(0.0).powf(expo)).collect()
    };
    let direct = DirectSolver::new(k, fixed)?;
    let mut solve_case = |fv: &[f64], dir: char, e: f64| -> Result<Vec<f64>, String> {
        let mut f = base_f.to_vec();
        apply_levels(&mut f, &levels, &weights, fv, dir, e, model);
        direct.solve(&f)
    };
    let p1 = pat(1.0);
    let u1 = solve_case(&p1, 'X', 0.0)?;
    let t1 = rayleigh(&levels, &p1, &u1);
    let kk = (1.0 + (t1 - 0.5) / 2.0).max(1.0).min(2.0);
    let fp = pat(kk);
    let u2 = solve_case(&fp, 'X', 0.0)?;
    let tcalc = rayleigh(&levels, &fp, &u2);
    let t = tcalc.min(cu * ta).max(0.01);
    let t0 = 0.2 * sd1 / s.sds.max(1e-9);
    let rr = (s.r / s.ie).max(1e-9);
    // La app (sismoCalc) usa SDS/(R/Ie) hasta T0 y SD1/(T·R/Ie) para todo T>T0.
    let mut cs = if t <= t0 {
        s.sds / rr
    } else {
        let mut c = sd1 / (t * rr);
        if t > s.tl {
            c = sd1 * s.tl / (t * t * rr);
        }
        c
    };
    cs = cs.max(0.044 * s.sds * s.ie).max(0.01);
    let vbase = cs * w_total;
    let sumfp: f64 = fp.iter().sum::<f64>().max(1e-9);
    let sh: Vec<f64> = fp.iter().map(|q| q / sumfp * vbase).collect();
    let ext = |dir: char| -> f64 {
        let (mut a, mut b) = (f64::INFINITY, f64::NEG_INFINITY);
        for n in &model.nodes {
            let q = if dir == 'X' { n.y } else { n.x };
            a = a.min(q);
            b = b.max(q);
        }
        (b - a).max(0.0)
    };
    let mut cases = Vec::new();
    let mut case_u: Vec<Vec<f64>> = Vec::new();
    let mut best_d = 0.0f64;
    let mut best_dtop = 0.0f64;
    for (dir, sign) in [('X', 1.0), ('X', -1.0), ('Y', 1.0), ('Y', -1.0)] {
        let e = sign * (s.ecc.max(5.0) / 100.0) * ext(dir);
        let u = solve_case(&sh, dir, e)?;
        let dtop = levels
            .last()
            .map(|l| avg_disp(&u, &l.nodes, dir).abs())
            .unwrap_or(0.0);
        let d = ctx.dmax(&u);
        if dtop > best_dtop {
            best_dtop = dtop;
            best_d = d;
        }
        cases.push(json!({"dir": dir.to_string(), "sign": sign, "ecc": e, "dmax": d,
            "dtop": dtop,
            "u": (0..model.nodes.len()).flat_map(|ni| u[6*ni..6*ni+6].iter().copied()).collect::<Vec<f64>>()}));
        case_u.push(u);
    }
    let mut tab = Vec::new();
    let mut acc = vec![0.0f64; levels.len()];
    let mut above = 0.0;
    for i in (0..levels.len()).rev() {
        acc[i] = above;
        above += levels[i].weight;
    }
    let da_factor = match s.riesgo {
        1 | 2 => 0.02,
        3 => 0.015,
        _ => 0.01,
    };
    let cd = if s.cd > 0.0 { s.cd } else { 5.5 };
    for i in 1..levels.len() {
        let h = (levels[i].z - levels[i - 1].z).max(1e-6);
        let mut dr = 0.0f64;
        for (ci, c) in cases.iter().enumerate() {
            let dir = if c["dir"] == "X" { 'X' } else { 'Y' };
            let a = avg_disp(&case_u[ci], &levels[i].nodes, dir).abs();
            let b = avg_disp(&case_u[ci], &levels[i - 1].nodes, dir).abs();
            dr = dr.max((a - b).abs());
        }
        let da = da_factor * h;
        let vx: f64 = sh[i..].iter().sum();
        let ddis = cd / s.ie * dr;
        let theta = acc[i] * ddis / (vx.max(1e-9) * h * cd);
        tab.push(json!({"z": levels[i].z, "w": levels[i].weight, "F": sh[i], "V": vx,
            "dr": dr, "dd": ddis, "da": da, "theta": theta,
            "ok": ddis <= da + 0.0005, "ok2": theta <= 0.1}));
    }
    Ok(json!({
        "method": "ELF",
        "T": t, "Ta": ta, "Cu": cu, "T1": t1, "Tcalc": tcalc, "k": kk,
        "Cs": cs, "V": vbase, "W": w_total, "hn": hn,
        "SDS": s.sds, "SD1": s.sd1, "R": s.r, "Ie": s.ie, "Cd": cd, "riesgo": s.riesgo,
        "levels": levels.iter().map(|l| json!({"z": l.z, "w": l.weight})).collect::<Vec<_>>(),
        "forces": sh,
        "cases": cases,
        "table": tab,
        "dmax": best_d
    }))
}

fn interp(xs: &[f64], ys: &[f64], x: f64) -> f64 {
    if x <= xs[0] {
        return ys[0];
    }
    if x >= xs[xs.len() - 1] {
        return ys[ys.len() - 1];
    }
    for i in 1..xs.len() {
        if x <= xs[i] {
            let t = (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
            return ys[i - 1] + (ys[i] - ys[i - 1]) * t;
        }
    }
    ys[ys.len() - 1]
}

fn apply_levels(
    f: &mut [f64],
    levels: &[Level],
    weights: &[f64],
    fv: &[f64],
    dir: char,
    e: f64,
    model: &Model,
) {
    for (li, l) in levels.iter().enumerate() {
        let force = fv.get(li).copied().unwrap_or(0.0);
        if !(force > 0.0) || !(l.weight > 0.0) {
            continue;
        }
        let mut xm = 0.0;
        let mut ym = 0.0;
        for &i in &l.wnodes {
            xm += weights[i] * model.nodes[i].x;
            ym += weights[i] * model.nodes[i].y;
        }
        xm /= l.weight;
        ym /= l.weight;
        let mut j = 0.0;
        for &i in &l.wnodes {
            let n = &model.nodes[i];
            j += weights[i] * ((n.x - xm).powi(2) + (n.y - ym).powi(2));
        }
        let alpha = if j > 1e-9 { force * e / j } else { 0.0 };
        for &i in &l.wnodes {
            let n = &model.nodes[i];
            let rx = n.x - xm;
            let ry = n.y - ym;
            let fk = force * weights[i] / l.weight;
            if dir == 'X' {
                f[6 * i] += fk - weights[i] * alpha * ry;
                f[6 * i + 1] += weights[i] * alpha * rx;
            } else {
                f[6 * i + 1] += fk - weights[i] * alpha * rx;
                f[6 * i] += weights[i] * alpha * ry;
            }
        }
    }
}

fn avg_disp(u: &[f64], nodes: &[usize], dir: char) -> f64 {
    let axis = if dir == 'X' { 0 } else { 1 };
    let mut s = 0.0;
    let mut c = 0;
    for &i in nodes {
        s += u[6 * i + axis];
        c += 1;
    }
    if c > 0 { s / c as f64 } else { 0.0 }
}

fn rayleigh(levels: &[Level], fv: &[f64], u: &[f64]) -> f64 {
    let mut s1 = 0.0;
    let mut s2 = 0.0;
    for (i, l) in levels.iter().enumerate() {
        let d = avg_disp(u, &l.nodes, 'X');
        s1 += l.weight * d * d;
        s2 += fv.get(i).copied().unwrap_or(0.0).abs() * d.abs();
    }
    if s1 > 0.0 && s2 > 0.0 {
        2.0 * std::f64::consts::PI * (s1 / (9.81 * s2)).sqrt()
    } else {
        0.0
    }
}
