# Validación del modelo completo · Zapel773DWall

**Ficha resumida.** La verificación completa del proyecto (metodología, oráculo, suites diferenciales y
bugs de la app) está en **[`VALIDACION-FINAL.md`](VALIDACION-FINAL.md)**. Este documento conserva sólo el
caso del modelo completo.

## Artefactos

| Dato | Valor |
|---|---|
| Modelo | `Zapel773DWall-modelo-completo.json` |
| SHA-256 del modelo | `3B323D6FAAE542FF57AEEC1F577DDAB845B17D526885C01DE73366DE6ADDD022` |
| Núcleo nativo | `rust-solver\target\release\zapel_solver.exe` |
| SHA-256 del núcleo | `D6BEB78BF9C4BBEDEC4D39C5209A3E56F3D1F5FC26CAC65496CBF2928E087609` (1.034.923 B) |
| Informes | `Informe-Rust-Estatico.html`, `Informe-Rust-ELF.html`, `Informe-Rust-Sismo.html`, `Informe-Rust-Viento.html` |

## Estado del modelo

- 408 nudos, 496 barras, 88 muros, 4 losas, 4 cargas de área, 76 apoyos.
- Una sola componente conectada; 10 pares de nudos separados por menos de 1 cm, sin componentes aisladas.
- 12.882 GDL; al subdividir barras, muros y membranas el cálculo usa 2.424 elementos y 2.147 nudos internos.
- Matriz global: **107.473 no-cero**, resuelta con **LDLᵀ disperso + reordenamiento RCM**.

La app densa **no puede** analizar este modelo (límite `MAX_DOF = 9.000` GDL en escritorio, `index.html:411`).
Por eso la validación del modelo completo se hace con el núcleo nativo, se comprueba el equilibrio global y la
paridad app↔Rust se valida en los modelos medianos de `tools/diff.js` y `tools/verify/sismo.js`
(ver `VALIDACION-FINAL.md` §2).

## Análisis estático

- dmax (máximo real, incluye nudos internos de muros/membranas): **0,04722 m** (1,8591 in).
- dmax en los 408 nudos del modelo: 0,01372 m (la diferencia es el hallazgo A1: la app omite los brazos
  rígidos; ver `VALIDACION-FINAL.md` §6).
- Equilibrio vertical: **ΣRz = −ΣFz = 104.839,03 kN**.
- Peso sísmico con `fA = 0,25`: **88.619,69 kN** (19.922,50 kip).
- Residual relativo 0; residual libre máximo 6,47e-5; sin advertencias.
- Tensiones de muro exportadas: 88 muros; presiones y momentos de matres disponibles.

## Fuerza lateral equivalente (ELF)

- T = **0,6883 s**; Ta = 0,5017 s; T1 = 0,6884 s; Tcalc = 0,6883 s; Cu = 1,4; k = 1,0942.
- Cs = **0,07749**; V = **6.867,07 kN** (1.543,78 kip); W = **88.619,69 kN**; hn = 14,021 m.
- dmax = **0,1233 m**; Cd = 5,5; categoría de riesgo 1; sin advertencias.
- 9 niveles sísmicos (incluye el nivel base; 8 entrepisos), con derivas `dr`, `dd`, `da` y `θ` por nivel.
- Nota: el modelo tiene dos cotas por losa (p. ej. 11,25 y 11,50 ft); el ELF las trata como niveles
  independientes igual que la app (tolerancia 1e-3 m) y por eso esas capas de 0,076 m salen con `da` pequeña.

## Sismo modal espectral (10 modos, CQC)

- SDS = 0,7333; SD1 = 0,4267; R = 8; Ie = 1; Cd = 5,5; excentricidad 5 %; fA = 0,25.
- Dirección X: V = **5.837,0 kN**, dmax escalado **1,8459 m** (72,6726 in), `kesc` = **11,6327**, 8 derivas.
- Dirección Y: V = **5.837,0 kN**, dmax escalado 1,6135 m (63,5246 in), `kesc` = 11,5620, 8 derivas.
- dmax sin escalar (referencia): **0,1587 m**. Masa modal efectiva: **33,77 %**. Peso total: 88.619,69 kN.
- **Advertencia:** participación modal insuficiente; el cortante se escala ×11,63 para alcanzar el 85 % del
  ELF (ASCE 7-16 12.9.4.2) y los desplazamientos/derivas escalados **no son representativos**. Para este
  modelo debe usarse **ELF** (o aumentar modos y verificar convergencia de participación). El aviso está
  destacado en `Informe-Rust-Sismo.html`.

## Viento (ASCE 7-22, direccional)

- V = 165 mph; exposición C; qh = **63,6695 psf**.
- Cortante basal X = **477,58 kN**; Y = **612,21 kN**; momento de vuelco = **4.243,79 kN·m**.
- 4 casos (±X, ±Y); 8 niveles con `Kz`, `pN`, `FX`, `FY`.
- Derivas por entrepiso: 8 valores absolutos en metros, **incluida la primera**, con `da = dz/400`
  (envolvente máxima ≈ 0,001041 m en el tercer nivel).
- dmax de la envolvente: 0,04701 m; sin advertencias.

## Conclusión del modelo completo

- Equilibrio global correcto (ΣRz = −ΣFz = 104.839,03 kN) y resultados coherentes entre estático, ELF y viento.
- El modelo es resoluble y estable con el núcleo disperso (12.882 GDL en ≈4 s estático; ≈4,7 s ELF; ≈2 s viento; ≈3 s modal de 10 modos).
- **Limitación de diseño:** el modal del modelo completo no es representativo por participación insuficiente;
  usar ELF. El resto de subsistemas está validado contra la app en los modelos medianos (1.066/1.066 métricas
  sísmicas y 54/54 fixtures estáticos, ver `VALIDACION-FINAL.md`).
