# Ejemplos

- `modelo-completo.json`: modelo de validación de 408 nudos, 496 barras, 88 muros y 4 losas.

Abre el archivo desde **Archivo → Abrir** en la app de escritorio, o desde el selector de archivos de la versión web.

Los análisis con el solver denso de la app pueden exceder el límite de JavaScript; para ese modelo usa los botones Rust en escritorio.
