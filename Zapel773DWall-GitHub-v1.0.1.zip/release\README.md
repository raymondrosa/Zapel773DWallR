# Release

Este directorio contiene las instrucciones y sumas de verificación del paquete portátil.

El ZIP de Windows (`Zapel773DWall-Escritorio.zip`) **no se versiona en Git** porque supera el límite cómodo de archivos del repositorio. Se adjunta a una **GitHub Release**.

## Crear una release

```powershell
git tag v1.0.1
git push origin v1.0.1

gh release create v1.0.1 ..\Zapel773DWall-Escritorio.zip `
  --title "Zapel773DWall v1.0.1" `
  --notes-file ..\RELEASE_NOTES.md
```

También se puede hacer desde la interfaz web:

1. **Releases → Draft a new release**.
2. Etiqueta `v1.0.1`.
3. Adjuntar el ZIP.
4. Publicar.

## Verificación

El archivo `SHA256SUMS.txt` contiene la suma del ZIP generado localmente. Para verificar:

```powershell
Get-FileHash .\Zapel773DWall-Escritorio.zip -Algorithm SHA256
```
