use crate::model::Model;
use serde_json::json;

#[derive(Debug, Clone)]
pub struct Settings {
    pub v: f64,
    pub exp: String,
    pub kzt: f64,
    pub kd: f64,
    pub ke: f64,
    pub g: f64,
    pub cpw: f64,
    pub cpl: f64,
    pub gcpi: f64,
    pub techo: bool,
    pub norma: String,
    pub evento: String,
}

impl Default for Settings {
    fn default() -> Self {
        Settings {
            v: 165.0,
            exp: "C".into(),
            kzt: 1.0,
            kd: 0.85,
            ke: 1.0,
            g: 0.85,
            cpw: 0.8,
            cpl: -0.5,
            gcpi: 0.18,
            techo: true,
            norma: "asce22".into(),
            evento: "diseno".into(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct Level {
    pub z: f64,
    pub prev: f64,
    pub dz: f64,
    pub nodes: Vec<usize>,
    pub x0: f64,
    pub x1: f64,
    pub y0: f64,
    pub y1: f64,
    pub bx: f64,
    pub by: f64,
    pub kz: f64,
    pub qz: f64,
    pub pw: f64,
    pub pl: f64,
    pub pn: f64,
    pub fx: f64,
    pub fy: f64,
}

#[derive(Debug, Clone)]
pub struct Prepared {
    pub base: f64,
    pub h: f64,
    pub qh: f64,
    pub levels: Vec<Level>,
    pub roof_f: f64,
    pub settings: Settings,
}

fn kz_viento(zft: f64, exp: &str) -> f64 {
    let (a, zg) = match exp {
        "B" => (7.0, 1200.0),
        "D" => (11.5, 700.0),
        _ => (9.5, 900.0),
    };
    let zz = zft.max(15.0).min(zg);
    2.01 * (zz / zg).powf(2.0 / a)
}

pub fn prepare(model: &Model, s: &Settings) -> Result<Prepared, String> {
    if !(s.v > 0.0) {
        return Err("Define una velocidad basica de viento V mayor que cero.".into());
    }
    let mut zs: Vec<f64> = model.nodes.iter().map(|n| (n.z * 1e4).round() / 1e4).collect();
    zs.sort_by(|a, b| a.partial_cmp(b).unwrap());
    zs.dedup_by(|a, b| (*a - *b).abs() < 1e-9);
    if zs.len() < 2 {
        return Err("No hay niveles con nodos para calcular el viento.".into());
    }
    let base = zs[0];
    let h = zs[zs.len() - 1] - base;
    if !(h > 0.0) {
        return Err("La altura del edificio es nula.".into());
    }
    let hft = h * 3.28084;
    let qh = 0.00256 * kz_viento(hft, &s.exp) * s.kzt * s.kd * s.ke * s.v * s.v;
    let mut levels = Vec::new();
    for i in 1..zs.len() {
        let z = zs[i];
        let prev = zs[i - 1];
        let nodes: Vec<usize> = model
            .nodes
            .iter()
            .enumerate()
            .filter(|(_, n)| (n.z - z).abs() < 1e-3)
            .map(|(j, _)| j)
            .collect();
        if nodes.is_empty() {
            continue;
        }
        let xs: Vec<f64> = nodes.iter().map(|&k| model.nodes[k].x).collect();
        let ys: Vec<f64> = nodes.iter().map(|&k| model.nodes[k].y).collect();
        let x0 = xs.iter().cloned().fold(f64::INFINITY, f64::min);
        let x1 = xs.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let y0 = ys.iter().cloned().fold(f64::INFINITY, f64::min);
        let y1 = ys.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let bx = (x1 - x0).max(1e-6);
        let by = (y1 - y0).max(1e-6);
        let zft = (((z + prev) / 2.0 - base) * 3.28084).max(15.0);
        let kz = kz_viento(zft, &s.exp);
        let qz = 0.00256 * kz * s.kzt * s.kd * s.ke * s.v * s.v;
        let pw = qz * s.g * s.cpw - qh * s.g * s.gcpi;
        let pl = qh * s.g * s.cpl - qh * s.g * s.gcpi;
        let pn = pw - pl;
        let fx = pn * 0.0478803 * by * (z - prev);
        let fy = pn * 0.0478803 * bx * (z - prev);
        levels.push(Level { z, prev, dz: z - prev, nodes, x0, x1, y0, y1, bx, by, kz, qz, pw, pl, pn, fx, fy });
    }
    if levels.is_empty() {
        return Err("No hay niveles con nodos para calcular el viento.".into());
    }
    let top = levels.last().unwrap();
    let p_roof = qh * s.g * (-0.7) - qh * s.gcpi;
    let roof_f = p_roof * 0.0478803 * top.bx * top.by;
    Ok(Prepared { base, h, qh, levels, roof_f, settings: s.clone() })
}

#[derive(Debug, Clone)]
pub struct CaseMeta {
    pub base_shear: f64,
}

/// Agrega al vector de cargas f las fuerzas del caso indicado y devuelve
/// el cortante basal resultante en la direccion del viento.
pub fn apply_case(model: &Model, p: &Prepared, dir: char, sign: f64, f: &mut [f64]) -> CaseMeta {
    let mut vs = 0.0;
    for l in &p.levels {
        let force = if dir == 'X' { l.fx } else { l.fy } * sign;
        let axis = if dir == 'X' { 0 } else { 1 };
        let (lo, hi) = if axis == 0 { (l.x0, l.x1) } else { (l.y0, l.y1) };
        let tol = (0.02 * (hi - lo).abs()).max(0.001);
        let mut face: Vec<usize> = l
            .nodes
            .iter()
            .copied()
            .filter(|&i| {
                let q = if axis == 0 { model.nodes[i].x } else { model.nodes[i].y };
                if sign > 0.0 { q <= lo + tol } else { q >= hi - tol }
            })
            .collect();
        if face.is_empty() {
            face = l.nodes.clone();
        }
        let add = force / face.len() as f64;
        for i in face {
            f[6 * i + axis] += add;
            vs += add;
        }
    }
    if p.settings.techo && p.roof_f != 0.0 {
        if let Some(top) = p.levels.last() {
            let add = -p.roof_f / top.nodes.len() as f64;
            for &i in &top.nodes {
                f[6 * i + 2] += add;
            }
        }
    }
    CaseMeta { base_shear: vs }
}

pub fn summary(p: &Prepared) -> serde_json::Value {
    json!({
        "V": p.settings.v,
        "exposure": p.settings.exp,
        "norma": p.settings.norma,
        "evento": p.settings.evento,
        "h": p.h,
        "hn": p.h,
        "qh": p.qh,
        "roofF": p.roof_f,
        "levels": p.levels.iter().map(|l| json!({
            "z": l.z, "prev": l.prev, "dz": l.dz, "Bx": l.bx, "By": l.by,
            "kz": l.kz, "qz": l.qz, "pW": l.pw, "pL": l.pl, "pN": l.pn,
            "FX": l.fx, "FY": l.fy
        })).collect::<Vec<_>>(),
        "Vbase": p.levels.iter().map(|l| l.fx).sum::<f64>(),
        "Mbase": p.levels.iter().map(|l| l.fx * (l.z - p.base)).sum::<f64>(),
        "techo": p.settings.techo
    })
}
