#[derive(Debug, Clone)]
pub struct Csr {
    pub n: usize,
    pub row_ptr: Vec<usize>,
    pub col: Vec<u32>,
    pub vals: Vec<f64>,
}

impl Csr {
    pub fn from_triplets(n: usize, mut t: Vec<(u32, u32, f64)>) -> Self {
        t.retain(|(r, c, v)| (*r as usize) < n && (*c as usize) < n && v.abs() > 1e-14);
        t.sort_unstable_by(|a, b| (a.0, a.1).cmp(&(b.0, b.1)));
        let mut row_ptr = vec![0usize; n + 1];
        let mut col = Vec::with_capacity(t.len());
        let mut vals = Vec::with_capacity(t.len());
        let mut last: Option<(u32, u32)> = None;
        for (r, c, v) in t {
            if let Some((lr, lc)) = last {
                if lr == r && lc == c {
                    if let Some(x) = vals.last_mut() {
                        *x += v;
                    }
                    continue;
                }
            }
            row_ptr[(r as usize) + 1] += 1;
            col.push(c);
            vals.push(v);
            last = Some((r, c));
        }
        for i in 0..n {
            row_ptr[i + 1] += row_ptr[i];
        }
        Csr { n, row_ptr, col, vals }
    }

    pub fn nnz(&self) -> usize {
        self.vals.len()
    }

    pub fn matvec(&self, x: &[f64], y: &mut [f64]) {
        y.fill(0.0);
        for i in 0..self.n {
            let a = self.row_ptr[i];
            let b = self.row_ptr[i + 1];
            let mut s = 0.0;
            for k in a..b {
                s += self.vals[k] * x[self.col[k] as usize];
            }
            y[i] = s;
        }
    }

    pub fn diagonal(&self) -> Vec<f64> {
        let mut d = vec![0.0; self.n];
        for i in 0..self.n {
            for k in self.row_ptr[i]..self.row_ptr[i + 1] {
                if self.col[k] as usize == i {
                    d[i] = self.vals[k];
                    break;
                }
            }
        }
        d
    }
}
