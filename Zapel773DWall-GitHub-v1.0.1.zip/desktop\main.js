const { app, BrowserWindow, Menu, dialog, shell, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');

// Los modelos grandes (miles de GDL) con análisis modal pueden tardar minutos.
const SOLVER_TIMEOUT_MS = 600000;

// Memoria ampliada para modelos grandes dentro del proceso de renderizado.
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=8192');
app.commandLine.appendSwitch('disable-hang-monitor');
app.commandLine.appendSwitch('disable-renderer-backgrounding');

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const w = BrowserWindow.getAllWindows()[0];
    if (w) {
      if (w.isMinimized()) w.restore();
      w.focus();
    }
  });
}

let win = null;

// Rutas donde puede estar el solver, en orden de preferencia:
// 1) empaquetado: resources/zapel_solver.exe (copiado con --extra-resource)
// 2) desarrollo: build de cargo en rust-solver/target/release
function solverCandidates() {
  const list = [];
  if (process.resourcesPath) list.push(path.join(process.resourcesPath, 'zapel_solver.exe'));
  list.push(path.join(__dirname, '..', 'rust-solver', 'target', 'release', 'zapel_solver.exe'));
  return list;
}

function solverPath() {
  const cands = solverCandidates();
  const found = cands.find((p) => fs.existsSync(p));
  return found || cands[cands.length - 1];
}

let solverCache = null;

// Versionado del solver: SHA-256 y fecha del binario que realmente se ejecuta.
function solverInfo() {
  const exe = solverPath();
  if (!fs.existsSync(exe)) {
    return { exists: false, path: exe, candidates: solverCandidates(), sha256: '', size: 0, mtime: '' };
  }
  const st = fs.statSync(exe);
  if (solverCache && solverCache.path === exe && solverCache.mtimeMs === st.mtime.getTime()) return solverCache;
  let sha256 = '';
  try {
    sha256 = crypto.createHash('sha256').update(fs.readFileSync(exe)).digest('hex').toUpperCase();
  } catch (_) {}
  solverCache = { exists: true, path: exe, sha256, size: st.size, mtime: st.mtime.toISOString(), mtimeMs: st.mtime.getTime() };
  console.log('[zapel] solver nativo: ' + exe + ' · sha256=' + sha256 + ' · ' + st.size + ' B · ' + solverCache.mtime);
  return solverCache;
}

const DONATION_URL = 'https://www.paypal.com/ncp/payment/BPBZKAY3U24CQ';
ipcMain.handle('open-external', async (_event, url) => {
  if (url !== DONATION_URL) return { ok: false, error: 'URL no permitida.' };
  await shell.openExternal(DONATION_URL);
  return { ok: true };
});

ipcMain.handle('rust-solve', async (_event, model, options) => {
  const info = solverInfo();
  if (!info.exists) {
    throw new Error(
      'No se encontro zapel_solver.exe.\n' +
      'Compila el nucleo nativo (pnpm run build:solver, o cargo build --release en rust-solver).\n' +
      'Rutas buscadas:\n' + info.candidates.join('\n')
    );
  }
  const exe = info.path;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zapel-rust-'));
  const input = path.join(dir, 'modelo.json');
  const output = path.join(dir, 'resultado.json');
  const report = path.join(dir, 'informe.html');
  try {
    fs.writeFileSync(input, JSON.stringify(model));
    return await new Promise((resolve, reject) => {
      const o = options || {};
      const args = [input, '--out', output];
      // Formato de salida comun:
      if (o.report) { args.push('--report'); args.push(report); }
      if (o.sismo) args.push('--sismo');
      if (o.viento) args.push('--viento');
      if (o.elf) args.push('--elf');
      if (o.modal) args.push('--modal');
      if (o.techo === false) args.push('--no-techo');
      // Opciones con valor: se envian tambien cuando valen 0.
      const opt = (flag, key) => {
        const v = o[key];
        if (v !== undefined && v !== null) { args.push(flag); args.push(String(v)); }
      };
      opt('--modes', 'modes');
      opt('--sds', 'sds');
      opt('--sd1', 'sd1');
      opt('--tl', 'tl');
      opt('--r', 'r');
      opt('--ie', 'ie');
      opt('--fA', 'fA');
      opt('--cd', 'cd');
      opt('--riesgo', 'riesgo');
      opt('--ct', 'ct');
      opt('--x', 'x');
      opt('--ecc', 'ecc');
      opt('--v', 'v');
      opt('--exp', 'exp');
      opt('--kzt', 'kzt');
      opt('--kd', 'kd');
      opt('--ke', 'ke');
      opt('--g', 'g');
      opt('--cpw', 'cpw');
      opt('--cpl', 'cpl');
      opt('--gcpi', 'gcpi');
      opt('--norma', 'norma');
      opt('--evento', 'evento');
      if (o.eventT && o.eventSa) {
        args.push('--event-json');
        args.push(JSON.stringify({ T: o.eventT, Sa: o.eventSa, scale: o.eventScale || 1 }));
      }
      const p = spawn(exe, args, { windowsHide: true });
      let err = '';
      let out = '';
      let settled = false;
      let timedOut = false;
      let timer = null;
      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        fn(value);
      };
      timer = setTimeout(() => {
        timedOut = true;
        try { p.kill(); } catch (_) {}
        finish(reject, new Error('El solver Rust excedio ' + Math.round(SOLVER_TIMEOUT_MS / 1000) + ' s y se cancelo.'));
      }, SOLVER_TIMEOUT_MS);
      p.stdout.on('data', (d) => { out += d.toString(); });
      p.stderr.on('data', (d) => { err += d.toString(); });
      p.on('error', (e) => finish(reject, e));
      p.on('close', (code) => {
        if (timedOut) return;
        if (code !== 0) {
          let detail = err.trim();
          try {
            const j = JSON.parse(out.trim());
            if (j && j.error) detail = j.error;
          } catch (_) {}
          if (!detail) detail = out.trim();
          if (/Opcion desconocida|opci[oó]n desconocida/i.test(detail)) {
            detail += ' (el zapel_solver.exe es anterior al contrato de opciones actual, sha256=' + info.sha256.slice(0, 12) + '; recompilalo con pnpm run build:solver)';
          }
          return finish(reject, new Error(detail || ('Solver Rust termino con codigo ' + code)));
        }
        try {
          const j = JSON.parse(fs.readFileSync(output, 'utf8'));
          if (o.report && fs.existsSync(report)) j.reportHtml = fs.readFileSync(report, 'utf8');
          if (j && typeof j === 'object' && !j.solver_info) {
            j.solver_info = { version: j.solver_version || null, sha256: info.sha256, size: info.size, mtime: info.mtime, path: info.path };
          }
          finish(resolve, j);
        } catch (e) {
          finish(reject, e);
        }
      });
    });
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}
  }
});


function guiaPath() {
  const p = path.join(__dirname, '..', 'Guia_Rapida_Zapel773DWall.md');
  return fs.existsSync(p) ? p : null;
}

function buildMenu() {
  const template = [
    {
      label: 'Archivo',
      submenu: [
        {
          label: 'Abrir modelo…',
          accelerator: 'CmdOrCtrl+O',
          click: () => {
            if (win) win.webContents.executeJavaScript("document.querySelector('#fo')?.click();").catch(() => {});
          }
        },
        { type: 'separator' },
        { role: 'quit', label: 'Salir' }
      ]
    },
    {
      label: 'Ver',
      submenu: [
        { role: 'reload', label: 'Recargar' },
        { role: 'forceReload', label: 'Forzar recarga' },
        { role: 'toggleDevTools', label: 'Herramientas de desarrollo' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Zoom 100%' },
        { role: 'zoomIn', label: 'Acercar' },
        { role: 'zoomOut', label: 'Alejar' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Pantalla completa' }
      ]
    },
    {
      label: 'Ayuda',
      submenu: [
        {
          label: 'Abrir guía rápida',
          click: () => {
            const p = guiaPath();
            if (p) shell.openPath(p);
            else dialog.showMessageBox({ message: 'No se encontró Guia_Rapida_Zapel773DWall.md junto a la aplicación.' });
          }
        },
        {
          label: 'Acerca de Zapel773DWall',
          click: () => {
            dialog.showMessageBox(win, {
              type: 'info',
              title: 'Zapel773DWall',
              message: 'Zapel773DWall',
              detail: 'Análisis estructural 3D de muros, losas y matres.\nVersión de escritorio (Electron).\n\nLa interfaz y el modelo son los mismos de la versión web.'
            });
          }
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function createWindow() {
  win = new BrowserWindow({
    width: 1500,
    height: 950,
    minWidth: 1100,
    minHeight: 700,
    title: 'Zapel773DWall',
    backgroundColor: '#eef2f7',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.once('ready-to-show', () => {
    win.maximize();
    win.show();
  });

  win.loadFile(path.join(__dirname, 'app.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  win.webContents.on('did-fail-load', (_e, code, desc) => {
    dialog.showErrorBox('Zapel773DWall', 'No se pudo cargar la interfaz.\n' + desc + ' (' + code + ')');
  });

  win.on('closed', () => { win = null; });
}

app.whenReady().then(() => {
  buildMenu();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
