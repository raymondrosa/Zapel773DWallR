const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('ZAPEL_DESKTOP', {
  isDesktop: true,
  electron: process.versions.electron,
  chrome: process.versions.chrome,
  platform: process.platform,
  solveRust: (model, options) => ipcRenderer.invoke('rust-solve', model, options),
  openExternal: (url) => ipcRenderer.invoke('open-external', url)
});
