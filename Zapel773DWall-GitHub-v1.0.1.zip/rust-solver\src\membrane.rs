use crate::model::{Model, Slab};

#[derive(Debug, Clone)]
pub struct MembraneElement {
    pub k: [[f64; 9]; 9],
    pub dof: [usize; 9],
    pub bd: [[f64; 6]; 3],
    pub centroid: [f64; 3],
    pub slab: usize,
    pub ex: [f64; 3],
    pub ey: [f64; 3],
}

#[derive(Debug, Clone, Copy)]
struct Plane {
    a: f64,
    b: f64,
    c: f64,
}

#[derive(Debug, Clone)]
struct Frame {
    p0: [f64; 3],
    ex: [f64; 3],
    ey: [f64; 3],
    pts2: Vec<[f64; 2]>,
}

fn det3(m: [[f64; 3]; 3]) -> f64 {
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
}

fn fit_plane(pts: &[[f64; 2]], z: &[f64]) -> Plane {
    let n = pts.len();
    let mut sx = 0.0;
    let mut sy = 0.0;
    let mut sz = 0.0;
    let mut sxx = 0.0;
    let mut sxy = 0.0;
    let mut syy = 0.0;
    let mut sxz = 0.0;
    let mut syz = 0.0;
    for i in 0..n {
        let x = pts[i][0];
        let y = pts[i][1];
        let zz = z[i];
        sx += x;
        sy += y;
        sz += zz;
        sxx += x * x;
        sxy += x * y;
        syy += y * y;
        sxz += x * zz;
        syz += y * zz;
    }
    if n < 3 {
        return Plane { a: if n > 0 { sz / n as f64 } else { 0.0 }, b: 0.0, c: 0.0 };
    }
    let m = [[n as f64, sx, sy], [sx, sxx, sxy], [sy, sxy, syy]];
    let rhs = [sz, sxz, syz];
    let d = det3(m);
    if d.abs() <= 1e-12 {
        return Plane { a: sz / n as f64, b: 0.0, c: 0.0 };
    }
    let col = |j: usize| -> f64 {
        let mut mm = m;
        for i in 0..3 {
            mm[i][j] = rhs[i];
        }
        det3(mm) / d
    };
    Plane { a: col(0), b: col(1), c: col(2) }
}

fn slab_zs(s: &Slab) -> Vec<f64> {
    s.pts
        .iter()
        .enumerate()
        .map(|(i, _)| s.zs.get(i).copied().filter(|v| v.is_finite()).unwrap_or(s.z))
        .collect()
}

fn frame(s: &Slab) -> Option<Frame> {
    let p = &s.pts;
    if p.len() < 3 {
        return None;
    }
    let z = slab_zs(s);
    let pl = fit_plane(p, &z);
    let mut n = [-pl.b, -pl.c, 1.0];
    let ln = (n[0] * n[0] + n[1] * n[1] + n[2] * n[2]).sqrt();
    n = [n[0] / ln, n[1] / ln, n[2] / ln];
    let p0 = [p[0][0], p[0][1], pl.a + pl.b * p[0][0] + pl.c * p[0][1]];
    let mut d = None;
    for k in 1..p.len() {
        let dx = p[k][0] - p[0][0];
        let dy = p[k][1] - p[0][1];
        if (dx * dx + dy * dy).sqrt() > 1e-9 {
            d = Some([dx, dy, pl.b * dx + pl.c * dy]);
            break;
        }
    }
    let d = d?;
    let dl = (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).sqrt();
    let ex = [d[0] / dl, d[1] / dl, d[2] / dl];
    let ey = [
        n[1] * ex[2] - n[2] * ex[1],
        n[2] * ex[0] - n[0] * ex[2],
        n[0] * ex[1] - n[1] * ex[0],
    ];
    let pts2 = p
        .iter()
        .enumerate()
        .map(|(_k, q)| {
            let zz = pl.a + pl.b * q[0] + pl.c * q[1];
            let v = [q[0] - p0[0], q[1] - p0[1], zz - p0[2]];
            [
                v[0] * ex[0] + v[1] * ex[1] + v[2] * ex[2],
                v[0] * ey[0] + v[1] * ey[1] + v[2] * ey[2],
            ]
        })
        .collect();
    Some(Frame { p0, ex, ey, pts2 })
}

fn tri_poly2(p: &[[f64; 2]]) -> Vec<[usize; 3]> {
    let n = p.len();
    if n < 3 {
        return vec![];
    }
    let mut idx: Vec<usize> = (0..n).collect();
    let mut area = 0.0;
    for i in 0..n {
        let a = p[i];
        let b = p[(i + 1) % n];
        area += a[0] * b[1] - b[0] * a[1];
    }
    if area < 0.0 {
        idx.reverse();
    }
    let cr = |a: usize, b: usize, c: usize| -> f64 {
        (p[b][0] - p[a][0]) * (p[c][1] - p[a][1])
            - (p[b][1] - p[a][1]) * (p[c][0] - p[a][0])
    };
    let inside = |q: usize, a: usize, b: usize, c: usize| -> bool {
        cr(a, b, q) >= -1e-12 && cr(b, c, q) >= -1e-12 && cr(c, a, q) >= -1e-12
    };
    let mut out = Vec::new();
    let mut guard = 0;
    while idx.len() > 3 && guard < n * n + 8 {
        guard += 1;
        let mut ear = false;
        for i in 0..idx.len() {
            let m = idx.len();
            let a = idx[(i + m - 1) % m];
            let b = idx[i];
            let c = idx[(i + 1) % m];
            if cr(a, b, c) <= 1e-12 {
                continue;
            }
            let mut ok = true;
            for &j in &idx {
                if j == a || j == b || j == c {
                    continue;
                }
                if inside(j, a, b, c) {
                    ok = false;
                    break;
                }
            }
            if ok {
                out.push([a, b, c]);
                idx.remove(i);
                ear = true;
                break;
            }
        }
        if !ear {
            break;
        }
    }
    if idx.len() == 3 && cr(idx[0], idx[1], idx[2]) > 1e-12 {
        out.push([idx[0], idx[1], idx[2]]);
    }
    out
}

fn find_node(coords: &[[f64; 3]], p: [f64; 3]) -> Option<usize> {
    coords
        .iter()
        .position(|q| ((q[0] - p[0]).powi(2) + (q[1] - p[1]).powi(2) + (q[2] - p[2]).powi(2)).sqrt() < 1e-5)
}

/// Agrega los elementos de membrana de diafragma de las losas.
pub fn add_membranes(
    model: &Model,
    coords: &mut Vec<[f64; 3]>,
    fixes: &mut Vec<[bool; 6]>,
    loads: &mut Vec<[f64; 6]>,
    mem: &mut Vec<MembraneElement>,
    warnings: &mut Vec<String>,
) {
    for (si, s) in model.slabs.iter().enumerate() {
        if s.dia == Some(false) {
            continue;
        }
        let Some(f) = frame(s) else {
            warnings.push(format!("Losa {}: no se pudo definir su plano; no aporta diafragma.", si + 1));
            continue;
        };
        let tris = tri_poly2(&f.pts2);
        if tris.is_empty() {
            warnings.push(format!("Losa {}: no se pudo triangular; no aporta diafragma.", si + 1));
            continue;
        }
        let z = slab_zs(s);
        let mut bidx = Vec::with_capacity(s.pts.len());
        let mut matched = 0;
        for (k, p) in s.pts.iter().enumerate() {
            let q = [p[0], p[1], z[k]];
            if let Some(idx) = find_node(coords, q) {
                if idx < model.nodes.len() {
                    matched += 1;
                }
                bidx.push(idx);
            } else {
                coords.push(q);
                fixes.push([false; 6]);
                loads.push([0.0; 6]);
                bidx.push(coords.len() - 1);
            }
        }
        if matched < 3 {
            warnings.push(format!(
                "Losa {}: el diafragma requiere al menos 3 vertices conectados a nudos.",
                si + 1
            ));
            continue;
        }
        let t = if s.t > 0.0 { s.t } else { 0.10 };
        let e = if s.e > 0.0 { s.e * 1e6 } else { 25.0e6 };
        let nu = 0.2;
        let d = e / (1.0 - nu * nu);
        let dm = [[d, d * nu, 0.0], [d * nu, d, 0.0], [0.0, 0.0, d * (1.0 - nu) / 2.0]];
        for tr in tris {
            let lp = [f.pts2[tr[0]], f.pts2[tr[1]], f.pts2[tr[2]]];
            let cx = (lp[0][0] + lp[1][0] + lp[2][0]) / 3.0;
            let cy = (lp[0][1] + lp[1][1] + lp[2][1]) / 3.0;
            let cp = [
                f.p0[0] + f.ex[0] * cx + f.ey[0] * cy,
                f.p0[1] + f.ex[1] * cx + f.ey[1] * cy,
                f.p0[2] + f.ex[2] * cx + f.ey[2] * cy,
            ];
            let ci = if let Some(idx) = find_node(coords, cp) {
                idx
            } else {
                coords.push(cp);
                fixes.push([false; 6]);
                loads.push([0.0; 6]);
                coords.len() - 1
            };
            let corners = [
                (bidx[tr[0]], lp[0]),
                (bidx[tr[1]], lp[1]),
                (bidx[tr[2]], lp[2]),
            ];
            let center = (ci, [cx, cy]);
            let subs = [
                (corners[0], corners[1], center),
                (corners[1], corners[2], center),
                (corners[2], corners[0], center),
            ];
            for (a, b, c) in subs {
                let x1 = a.1[0];
                let y1 = a.1[1];
                let x2 = b.1[0];
                let y2 = b.1[1];
                let x3 = c.1[0];
                let y3 = c.1[1];
                let ar = ((x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)).abs() / 2.0;
                if !(ar > 1e-9) {
                    continue;
                }
                let b1 = y2 - y3;
                let b2 = y3 - y1;
                let b3 = y1 - y2;
                let c1 = x3 - x2;
                let c2 = x1 - x3;
                let c3 = x2 - x1;
                let bm = [
                    [b1, 0.0, b2, 0.0, b3, 0.0],
                    [0.0, c1, 0.0, c2, 0.0, c3],
                    [c1, b1, c2, b2, c3, b3],
                ];
                let mut k = [[0.0f64; 6]; 6];
                for r in 0..6 {
                    for ss in 0..6 {
                        let mut sum = 0.0;
                        for u in 0..3 {
                            for v in 0..3 {
                                sum += bm[u][r] / (2.0 * ar) * dm[u][v] * bm[v][ss] / (2.0 * ar);
                            }
                        }
                        k[r][ss] = sum * t * ar;
                    }
                }
                let mut tm = [[0.0f64; 6]; 9];
                for r in 0..3 {
                    tm[3 * r][2 * r] = f.ex[0];
                    tm[3 * r + 1][2 * r] = f.ex[1];
                    tm[3 * r + 2][2 * r] = f.ex[2];
                    tm[3 * r][2 * r + 1] = f.ey[0];
                    tm[3 * r + 1][2 * r + 1] = f.ey[1];
                    tm[3 * r + 2][2 * r + 1] = f.ey[2];
                }
                let mut kg = [[0.0f64; 9]; 9];
                for r in 0..9 {
                    for ss in 0..9 {
                        let mut sum = 0.0;
                        for u in 0..6 {
                            for v in 0..6 {
                                sum += tm[r][u] * k[u][v] * tm[ss][v];
                            }
                        }
                        kg[r][ss] = sum;
                    }
                }
                let nodes = [a.0, b.0, c.0];
                let mut dof = [0usize; 9];
                for (nn, &node) in nodes.iter().enumerate() {
                    dof[3 * nn] = 6 * node;
                    dof[3 * nn + 1] = 6 * node + 1;
                    dof[3 * nn + 2] = 6 * node + 2;
                }
                let mut bd = [[0.0f64; 6]; 3];
                for r in 0..3 {
                    for cc in 0..6 {
                        let mut s = 0.0;
                        for u in 0..3 {
                            s += dm[r][u] * bm[u][cc] / (2.0 * ar);
                        }
                        bd[r][cc] = s;
                    }
                }
                let cen = [
                    (coords[a.0][0] + coords[b.0][0] + coords[c.0][0]) / 3.0,
                    (coords[a.0][1] + coords[b.0][1] + coords[c.0][1]) / 3.0,
                    (coords[a.0][2] + coords[b.0][2] + coords[c.0][2]) / 3.0,
                ];
                mem.push(MembraneElement { k: kg, dof, bd, centroid: cen, slab: si, ex: f.ex, ey: f.ey });
            }
        }
    }
}
