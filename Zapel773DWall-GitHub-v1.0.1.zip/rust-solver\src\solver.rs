use crate::sparse::Csr;

pub struct CgResult {
    pub u: Vec<f64>,
    pub iterations: usize,
    pub residual_relative: f64,
}

pub fn solve_pcg(
    k: &Csr,
    f: &[f64],
    fixed: &[bool],
    tol: f64,
    max_iter: usize,
) -> Result<CgResult, String> {
    let n = k.n;
    if f.len() != n || fixed.len() != n {
        return Err("Dimensiones inconsistentes en el solver.".into());
    }
    let free: Vec<usize> = (0..n).filter(|&i| !fixed[i]).collect();
    let mut u = vec![0.0f64; n];
    if free.is_empty() {
        return Ok(CgResult { u, iterations: 0, residual_relative: 0.0 });
    }
    let diag = k.diagonal();
    for &i in &free {
        if !(diag[i].is_finite()) || diag[i].abs() < 1e-14 {
            return Err(format!(
                "Diagonal de rigidez nula en el GDL {} (posible mecanismo o nudo sin rigidez).",
                i
            ));
        }
    }
    let mut r = f.to_vec();
    for &i in &free {
        r[i] = f[i];
    }
    let bnorm = free.iter().map(|&i| f[i] * f[i]).sum::<f64>().sqrt();
    if bnorm < 1e-30 {
        return Ok(CgResult { u, iterations: 0, residual_relative: 0.0 });
    }
    let mut z = vec![0.0f64; n];
    for &i in &free {
        z[i] = r[i] / diag[i];
    }
    let mut p = z.clone();
    let mut ap = vec![0.0f64; n];
    let mut rz = dot_free(&r, &z, &free);
    let mut res = (dot_free(&r, &r, &free)).sqrt() / bnorm;
    if res < tol {
        return Ok(CgResult { u, iterations: 0, residual_relative: res });
    }
    let limit = max_iter.max(1000).min(500_000);
    let mut it = 0usize;
    while it < limit {
        it += 1;
        k.matvec(&p, &mut ap);
        let pap = dot_free(&p, &ap, &free);
        if !(pap.is_finite()) || pap <= 0.0 {
            return Err("El sistema no es definido positivo; revisa apoyos y conexiones.".into());
        }
        let alpha = rz / pap;
        for &i in &free {
            u[i] += alpha * p[i];
            r[i] -= alpha * ap[i];
        }
        res = (dot_free(&r, &r, &free)).sqrt() / bnorm;
        if res < tol {
            break;
        }
        for &i in &free {
            z[i] = r[i] / diag[i];
        }
        let rz_new = dot_free(&r, &z, &free);
        if !(rz_new.is_finite()) || rz.abs() < 1e-300 {
            return Err("El solver se estancó; el modelo puede ser inestable.".into());
        }
        let beta = rz_new / rz;
        for &i in &free {
            p[i] = z[i] + beta * p[i];
        }
        rz = rz_new;
    }
    if res > tol * 100.0 {
        return Err(format!(
            "El solver no convergió (residual relativo {:.3e}). Prueba más iteraciones o revisa la estabilidad.",
            res
        ));
    }
    Ok(CgResult { u, iterations: it, residual_relative: res })
}

fn dot_free(a: &[f64], b: &[f64], free: &[usize]) -> f64 {
    let mut s = 0.0;
    for &i in free {
        s += a[i] * b[i];
    }
    s
}


#[cfg(test)]
mod tests {
    use super::*;
    use crate::sparse::Csr;

    #[test]
    fn solves_diagonal_system() {
        let tri = vec![(0,0,2.0),(1,1,4.0),(2,2,8.0)];
        let k = Csr::from_triplets(3, tri);
        let f = vec![2.0, 8.0, 16.0];
        let fixed = vec![false, false, false];
        let r = solve_pcg(&k, &f, &fixed, 1e-12, 100).unwrap();
        assert!((r.u[0] - 1.0).abs() < 1e-12);
        assert!((r.u[1] - 2.0).abs() < 1e-12);
        assert!((r.u[2] - 2.0).abs() < 1e-12);
    }

    #[test]
    fn respects_fixed_dofs() {
        let tri = vec![(0,0,1.0),(1,1,1.0),(0,1,-1.0),(1,0,-1.0)];
        let k = Csr::from_triplets(2, tri);
        let f = vec![10.0, 0.0];
        let fixed = vec![true, false];
        let r = solve_pcg(&k, &f, &fixed, 1e-12, 100).unwrap();
        assert_eq!(r.u[0], 0.0);
        assert!((r.u[1]).abs() < 1e-12);
    }
}

/// Factorizacion directa reutilizable para analisis modal y estatico.
pub struct DirectSolver {
    ldl: Option<sprs_ldl::LdlNumeric<f64, usize>>,
    free: Vec<usize>,
    n: usize,
}

impl DirectSolver {
    pub fn new(k: &Csr, fixed: &[bool]) -> Result<Self, String> {
        let n = k.n;
        let mut free_index = vec![usize::MAX; n];
        let mut free = Vec::new();
        for i in 0..n {
            if !fixed[i] {
                free_index[i] = free.len();
                free.push(i);
            }
        }
        let nf = free.len();
        if nf == 0 {
            return Ok(DirectSolver { ldl: None, free, n });
        }
        let mut tri = sprs::TriMat::<f64>::new((nf, nf));
        for &i in &free {
            let ri = free_index[i];
            for p in k.row_ptr[i]..k.row_ptr[i + 1] {
                let j = k.col[p] as usize;
                let rj = free_index[j];
                if rj != usize::MAX {
                    tri.add_triplet(ri, rj, k.vals[p]);
                }
            }
        }
        let csc = tri.to_csc();
        let ldl = sprs_ldl::Ldl::new()
            .check_symmetry(sprs::SymmetryCheck::DontCheckSymmetry)
            .fill_in_reduction(sprs::FillInReduction::ReverseCuthillMcKee)
            .numeric(csc.view())
            .map_err(|e| format!("Factorizacion LDLT fallida: {:?}", e))?;
        Ok(DirectSolver { ldl: Some(ldl), free, n })
    }

    pub fn solve(&self, f: &[f64]) -> Result<Vec<f64>, String> {
        let mut u = vec![0.0f64; self.n];
        let Some(ldl) = &self.ldl else { return Ok(u); };
        let rhs: Vec<f64> = self.free.iter().map(|&i| f[i]).collect();
        let sol = ldl.solve(&rhs);
        if sol.len() != self.free.len() {
            return Err("El solver directo devolvio un vector de tamano incorrecto.".into());
        }
        for (idx, &i) in self.free.iter().enumerate() {
            u[i] = sol[idx];
        }
        Ok(u)
    }
}

pub fn solve_direct(k: &Csr, f: &[f64], fixed: &[bool]) -> Result<Vec<f64>, String> {
    DirectSolver::new(k, fixed)?.solve(f)
}

pub fn solve_static(
    k: &Csr,
    f: &[f64],
    fixed: &[bool],
    tol: f64,
    max_iter: usize,
) -> Result<CgResult, String> {
    match solve_direct(k, f, fixed) {
        Ok(u) => Ok(CgResult { u, iterations: 0, residual_relative: 0.0 }),
        Err(e) => {
            eprintln!("Solver directo no disponible, usando PCG: {}", e);
            solve_pcg(k, f, fixed, tol, max_iter)
        }
    }
}
